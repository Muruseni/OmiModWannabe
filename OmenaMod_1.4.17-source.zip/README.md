# OmenaMod 1.4.17

Minecraft 1.8.9 Forge/Lunar client-side mod for Pit Classic.

## 1.4.17
- Right-clicking colour selectors cycles backwards; left-click continues to cycle forwards.
- Added a coloured one-time welcome message after joining a server connection.
- `/omenamod` opens the OmenaMod menu; `/omenamod <Key>` changes the menu keybind. Existing `/blw`, `/bl`, and `/blacklist` aliases remain available.
- Added Overall Settings to the main menu with a configurable menu key and a global OmenaMod sound-volume multiplier.
- Global sound volume multiplies existing per-alert volumes rather than replacing them; 100% is normal and 50% halves the configured sound volume.
- Moved Blacklist Settings controls/list panels down to stop the command/help text being covered by buttons.
- No detection, equipment parsing, Mystic matching, Friend server-command behavior, or additional networking was added.
