package com.example.blacklistedlobbywatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

/** Stores positions and user-selected scales for optional/list-specific HUDs. */
public class IndependentHudPositionManager {
    private static final long MAX_CONFIG_BYTES = 32768L;
    private static final int MAX_ABSOLUTE_COORDINATE = 100000;
    private static final float MIN_SCALE = 0.50F;
    private static final float MAX_SCALE = 2.50F;

    private final File file;
    private final Map<String, int[]> positions = new LinkedHashMap<String, int[]>();
    private final Map<String, Float> scales = new LinkedHashMap<String, Float>();

    public IndependentHudPositionManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher_extra_huds.properties");
    }

    public void load() {
        positions.clear();
        scales.clear();
        if (!file.exists()) return;
        if (!file.isFile() || file.length() > MAX_CONFIG_BYTES) return;

        FileInputStream input = null;
        try {
            Properties properties = new Properties();
            input = new FileInputStream(file);
            properties.load(input);
            for (String property : properties.stringPropertyNames()) {
                if (property.startsWith("position.") && property.endsWith(".x")) {
                    String rawKey = property.substring("position.".length(), property.length() - 2);
                    String key = normalizeKey(rawKey);
                    if (key.isEmpty()) continue;
                    String xValue = properties.getProperty("position." + rawKey + ".x");
                    String yValue = properties.getProperty("position." + rawKey + ".y");
                    Integer x = parseCoordinate(xValue);
                    Integer y = parseCoordinate(yValue);
                    if (x != null && y != null) positions.put(key, new int[]{x.intValue(), y.intValue()});
                } else if (property.startsWith("scale.")) {
                    String key = normalizeKey(property.substring("scale.".length()));
                    if (key.isEmpty()) continue;
                    Float scale = parseScale(properties.getProperty(property));
                    if (scale != null) scales.put(key, scale);
                }
            }
        } catch (Exception ignored) {
            positions.clear();
            scales.clear();
        } finally {
            if (input != null) try { input.close(); } catch (Exception ignored) { }
        }
    }

    public void save() {
        FileOutputStream output = null;
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return;
            Properties properties = new Properties();
            for (Map.Entry<String, int[]> entry : positions.entrySet()) {
                int[] p = entry.getValue();
                if (p == null || p.length < 2) continue;
                properties.setProperty("position." + entry.getKey() + ".x", Integer.toString(p[0]));
                properties.setProperty("position." + entry.getKey() + ".y", Integer.toString(p[1]));
            }
            for (Map.Entry<String, Float> entry : scales.entrySet()) {
                properties.setProperty("scale." + entry.getKey(), Float.toString(clampScale(entry.getValue().floatValue())));
            }
            output = new FileOutputStream(file);
            properties.store(output, "OmenaMod extra HUD positions and scales");
        } catch (Exception ignored) {
        } finally {
            if (output != null) try { output.close(); } catch (Exception ignored) { }
        }
    }

    public boolean hasPosition(String key) { return positions.containsKey(normalizeKey(key)); }
    public int getX(String key, int fallback) { int[] p=positions.get(normalizeKey(key)); return p==null?fallback:p[0]; }
    public int getY(String key, int fallback) { int[] p=positions.get(normalizeKey(key)); return p==null?fallback:p[1]; }

    public void setPosition(String key, int x, int y) {
        String normalized = normalizeKey(key);
        if (normalized.isEmpty()) return;
        if (Math.abs((long)x) > MAX_ABSOLUTE_COORDINATE || Math.abs((long)y) > MAX_ABSOLUTE_COORDINATE) return;
        positions.put(normalized, new int[]{x, y});
    }

    public float getScale(String key) {
        Float v=scales.get(normalizeKey(key));
        return v==null?1.0F:clampScale(v.floatValue());
    }
    public void setScale(String key,float scale){String normalized=normalizeKey(key);if(normalized.isEmpty())return;scales.put(normalized,Float.valueOf(clampScale(scale)));}
    public float minScale(){return MIN_SCALE;} public float maxScale(){return MAX_SCALE;}

    private Integer parseCoordinate(String value) {
        try { int parsed=Integer.parseInt(value==null?"":value.trim()); if(parsed<-MAX_ABSOLUTE_COORDINATE||parsed>MAX_ABSOLUTE_COORDINATE)return null; return Integer.valueOf(parsed); }
        catch (NumberFormatException ignored) { return null; }
    }
    private Float parseScale(String value){try{float f=Float.parseFloat(value==null?"":value.trim());if(Float.isNaN(f)||Float.isInfinite(f))return null;return Float.valueOf(clampScale(f));}catch(Exception ignored){return null;}}
    private float clampScale(float f){return Math.max(MIN_SCALE,Math.min(MAX_SCALE,f));}

    private String normalizeKey(String key) {
        if (key == null) return "";
        String normalized = key.trim().toLowerCase(Locale.ROOT);
        StringBuilder safe = new StringBuilder();
        for (int i = 0; i < normalized.length() && safe.length() < 48; i++) {
            char c = normalized.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == ':') safe.append(c);
        }
        return safe.toString();
    }
}
