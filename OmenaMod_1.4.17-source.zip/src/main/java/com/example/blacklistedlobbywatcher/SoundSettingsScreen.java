package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** Draggable discrete sound sliders for one Blacklist-style list. */
public class SoundSettingsScreen extends GuiScreen {
    private static final int BACK=0, JOIN_PREVIEW=1, LEAVE_PREVIEW=2, RESET=3;
    private static final int SLIDER_W=150, SLIDER_H=12;
    private final GuiScreen parent; private final LobbyWatcher watcher; private final SoundSettingsManager sounds; private final String listName; private int dragging;
    public SoundSettingsScreen(GuiScreen parent,LobbyWatcher watcher,String listName){this.parent=parent;this.watcher=watcher;this.sounds=watcher.getSoundSettingsManager();this.listName=listName==null?"Blacklist":listName;}
    @Override public void func_73866_w_(){int cx=field_146294_l/2,top=Math.max(48,field_146295_m/2-84);field_146292_n.add(new GuiButton(JOIN_PREVIEW,cx+62,top+36,58,18,"Preview"));field_146292_n.add(new GuiButton(LEAVE_PREVIEW,cx+62,top+98,58,18,"Preview"));field_146292_n.add(new GuiButton(RESET,cx-100,top+132,95,20,"Reset sounds"));field_146292_n.add(new GuiButton(BACK,cx+5,top+132,95,20,"Back"));}
    @Override public void func_73863_a(int mx,int my,float pt){if(dragging!=0)update(dragging,mx);OmenaUi.background(field_146294_l,field_146295_m);int cx=field_146294_l/2,top=Math.max(48,field_146295_m/2-84);center("\u00A7b\u00A7l"+listName+" Sounds",top-28);center("\u00A77Drag the bars to choose a sound. Volume is separate.",top-12);field_146289_q.func_78276_b("\u00A7fJoin / detected: \u00A7b"+SoundChoice.labelFor(sounds.getJoinSound(listName)),cx-100,top+8,0xFFFFFF);slider(cx-100,top+36,sounds.getJoinSound(listName));field_146289_q.func_78276_b("\u00A7fLeave: \u00A7b"+SoundChoice.labelFor(sounds.getLeaveSound(listName)),cx-100,top+70,0xFFFFFF);slider(cx-100,top+98,sounds.getLeaveSound(listName));super.func_73863_a(mx,my,pt);}
    private void slider(int x,int y,String id){Gui.func_73734_a(x,y+4,x+SLIDER_W,y+8,0xFF555555);int idx=SoundChoice.indexOf(id),max=Math.max(1,SoundChoice.size()-1);int px=x+Math.round(SLIDER_W*(idx/(float)max));Gui.func_73734_a(x,y+4,px,y+8,0xFF33AADD);Gui.func_73734_a(px-3,y,px+3,y+SLIDER_H,0xFFFFFFFF);}
    @Override protected void func_73864_a(int mx,int my,int mb){if(mb==0){int x=field_146294_l/2-100,top=Math.max(48,field_146295_m/2-84);if(inside(mx,my,x,top+36)){dragging=1;update(1,mx);return;}if(inside(mx,my,x,top+98)){dragging=2;update(2,mx);return;}}super.func_73864_a(mx,my,mb);}
    @Override protected void func_146273_a(int mx,int my,int mb,long t){if(dragging!=0&&mb==0){update(dragging,mx);return;}super.func_146273_a(mx,my,mb,t);}
    @Override protected void func_146286_b(int mx,int my,int state){if(dragging!=0&&state==0){update(dragging,mx);dragging=0;sounds.save();return;}super.func_146286_b(mx,my,state);}
    @Override protected void func_146284_a(GuiButton b){if(b.field_146127_k==JOIN_PREVIEW)watcher.previewJoinPing(listName);else if(b.field_146127_k==LEAVE_PREVIEW)watcher.previewLeavePing(listName);else if(b.field_146127_k==RESET){sounds.setJoinSound(listName,SoundChoice.DEFAULT_ID);sounds.setLeaveSound(listName,SoundChoice.DEFAULT_ID);sounds.save();}else if(b.field_146127_k==BACK){sounds.save();field_146297_k.func_147108_a(parent);}}
    @Override public void func_146281_b(){dragging=0;sounds.save();}private boolean inside(int mx,int my,int x,int y){return mx>=x-4&&mx<=x+SLIDER_W+4&&my>=y-4&&my<=y+SLIDER_H+4;}private void update(int which,int mx){int x=field_146294_l/2-100,c=Math.max(x,Math.min(x+SLIDER_W,mx)),max=Math.max(1,SoundChoice.size()-1),idx=Math.round(((c-x)/(float)SLIDER_W)*max);String id=SoundChoice.idAt(idx);if(which==1)sounds.setJoinSound(listName,id);else sounds.setLeaveSound(listName,id);}private void center(String s,int y){field_146289_q.func_78276_b(s,(field_146294_l-field_146289_q.func_78256_a(s))/2,y,0xFFFFFF);}
}
