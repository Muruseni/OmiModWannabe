package com.example.blacklistedlobbywatcher;
import net.minecraft.client.gui.Gui;import net.minecraft.client.gui.GuiButton;import net.minecraft.client.gui.GuiScreen;
public class CustomRuleAlertsSettingsScreen extends GuiScreen{
 private final GuiScreen parent;private final CustomItemRuleManager manager;private final CustomItemRuleManager.Rule rule;
 public CustomRuleAlertsSettingsScreen(GuiScreen p,CustomItemRuleManager m,CustomItemRuleManager.Rule r){parent=p;manager=m;rule=r;}
 @Override public void func_73866_w_(){int cx=field_146294_l/2,top=Math.max(68,field_146295_m/2-42);field_146292_n.add(new GuiButton(1,cx-105,top,210,20,"Ping: "+on(rule.ping)));field_146292_n.add(new GuiButton(2,cx-105,top+28,210,20,"Chat alert: "+on(rule.chat)));field_146292_n.add(new GuiButton(0,cx-105,top+64,210,20,"Back"));}
 @Override public void func_73863_a(int x,int y,float p){OmenaUi.background(field_146294_l,field_146295_m);center("\u00A7d\u00A7l"+rule.name+" Alerts",30);center("\u00A77Applies when this complete custom-item rule matches.",46);super.func_73863_a(x,y,p);}
 @Override protected void func_146284_a(GuiButton b){if(b.field_146127_k==0){manager.save();field_146297_k.func_147108_a(parent);return;}if(b.field_146127_k==1)rule.ping=!rule.ping;else if(b.field_146127_k==2)rule.chat=!rule.chat;manager.save();field_146292_n.clear();func_73866_w_();}
 private String on(boolean v){return v?"ON":"OFF";}private void center(String s,int y){field_146289_q.func_78276_b(s,(field_146294_l-field_146289_q.func_78256_a(s))/2,y,0xFFFFFF);}
}
