package com.example.blacklistedlobbywatcher;

import java.io.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

/** Optional client-only alert cooldowns. Disabled by default. */
public class AlertThrottleManager {
    private static final long COOLDOWN_MS=5000L;
    private final File file; private final Properties values=new Properties();
    private final Map<String,Long> lastPing=new HashMap<String,Long>(),lastChat=new HashMap<String,Long>();
    public AlertThrottleManager(File dir){file=new File(dir,"omenamod_alert_throttle.properties");}
    public void load(){values.clear();if(!file.exists()||!file.isFile()||file.length()>64L*1024L)return;FileInputStream in=null;try{in=new FileInputStream(file);Properties p=new Properties();p.load(in);for(Object k:p.keySet()){String key=String.valueOf(k),v=p.getProperty(key);if((key.endsWith(".ping")||key.endsWith(".chat"))&&("true".equalsIgnoreCase(v)||"false".equalsIgnoreCase(v)))values.setProperty(key,v.toLowerCase(Locale.ROOT));}}catch(Exception ignored){values.clear();}finally{if(in!=null)try{in.close();}catch(Exception ignored){}}}
    public void save(){FileOutputStream out=null;try{File p=file.getParentFile();if(p!=null&&!p.exists())p.mkdirs();out=new FileOutputStream(file);values.store(out,"OmenaMod alert throttles");}catch(Exception ignored){}finally{if(out!=null)try{out.close();}catch(Exception ignored){}}}
    public boolean isPingThrottle(String scope){return Boolean.parseBoolean(values.getProperty(k(scope,"ping"),"false"));} public boolean isChatThrottle(String scope){return Boolean.parseBoolean(values.getProperty(k(scope,"chat"),"false"));}
    public void setPingThrottle(String scope,boolean v){values.setProperty(k(scope,"ping"),Boolean.toString(v));save();} public void setChatThrottle(String scope,boolean v){values.setProperty(k(scope,"chat"),Boolean.toString(v));save();}
    public boolean allowPing(String scope,String eventKey,boolean localThrottle){return allow(lastPing,"p|"+scope+"|"+eventKey,isPingThrottle(scope)||localThrottle);} public boolean allowChat(String scope,String eventKey,boolean localThrottle){return allow(lastChat,"c|"+scope+"|"+eventKey,isChatThrottle(scope)||localThrottle);}
    private boolean allow(Map<String,Long> map,String key,boolean throttled){if(!throttled)return true;long now=System.currentTimeMillis();Long last=map.get(key);if(last!=null&&now-last<COOLDOWN_MS)return false;map.put(key,now);return true;}
    private String k(String scope,String kind){return "scope."+EnchantRegistry.id(scope==null?"unknown":scope)+"."+kind;}
}
