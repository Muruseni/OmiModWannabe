package com.example.blacklistedlobbywatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

/** Local UI mirror of Pit Classic friends plus client-only display/alert preferences. */
public class FriendListManager {
    private static final long MAX_CONFIG_BYTES = 65536L;
    private static final int MAX_FRIENDS = 1000;
    private final File file;
    private final List<String> friends = new ArrayList<String>();
    private boolean hudEnabled;
    private boolean ffHudEnabled;
    private boolean joinPingEnabled;
    private boolean leavePingEnabled;
    private boolean joinChatEnabled;
    private boolean leaveChatEnabled;
    private int joinVolume = 50;
    private int leaveVolume = 50;
    private String joinSound = SoundChoice.DEFAULT_ID;
    private String leaveSound = SoundChoice.DEFAULT_ID;
    private final java.util.Map<String,Boolean> gearShown = new java.util.HashMap<String,Boolean>();

    public FriendListManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher_friends.properties");
    }

    public void load() {
        friends.clear();
        hudEnabled = false;
        ffHudEnabled = false;
        joinPingEnabled = false;
        leavePingEnabled = false;
        joinChatEnabled = false;
        leaveChatEnabled = false;
        joinVolume = 50;
        leaveVolume = 50;
        joinSound = SoundChoice.DEFAULT_ID;
        leaveSound = SoundChoice.DEFAULT_ID;
        gearShown.clear();
        if (!file.exists() || !file.isFile() || file.length() > MAX_CONFIG_BYTES) return;
        FileInputStream in = null;
        try {
            Properties p = new Properties();
            in = new FileInputStream(file);
            p.load(in);
            hudEnabled = parseBool(p.getProperty("hud"), false);
            ffHudEnabled = parseBool(p.getProperty("ffHud"), false);
            joinPingEnabled = parseBool(p.getProperty("joinPing"), false);
            leavePingEnabled = parseBool(p.getProperty("leavePing"), false);
            joinChatEnabled = parseBool(p.getProperty("joinChat"), false);
            leaveChatEnabled = parseBool(p.getProperty("leaveChat"), false);
            joinVolume = parseVolume(p.getProperty("joinVolume"), 50);
            leaveVolume = parseVolume(p.getProperty("leaveVolume"), 50);
            joinSound = SoundChoice.sanitize(p.getProperty("joinSound"));
            leaveSound = SoundChoice.sanitize(p.getProperty("leaveSound"));
            String entries = p.getProperty("friends", "");
            if (!entries.isEmpty()) {
                String[] split = entries.split(",");
                for (String s : split) addInternal(s);
            }
            for (String f : friends) {
                String gv = p.getProperty("gear." + f.toLowerCase(Locale.ROOT));
                if ("false".equalsIgnoreCase(gv)) gearShown.put(f.toLowerCase(Locale.ROOT), Boolean.FALSE);
                else if ("true".equalsIgnoreCase(gv)) gearShown.put(f.toLowerCase(Locale.ROOT), Boolean.TRUE);
            }
        } catch (Exception e) {
            friends.clear();
            System.err.println("[BlacklistedLobbyWatcher] Could not parse friend config; using defaults.");
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignored) { }
        }
    }

    public void save() {
        FileOutputStream out = null;
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            Properties p = new Properties();
            p.setProperty("hud", Boolean.toString(hudEnabled));
            p.setProperty("ffHud", Boolean.toString(ffHudEnabled));
            p.setProperty("joinPing", Boolean.toString(joinPingEnabled));
            p.setProperty("leavePing", Boolean.toString(leavePingEnabled));
            p.setProperty("joinChat", Boolean.toString(joinChatEnabled));
            p.setProperty("leaveChat", Boolean.toString(leaveChatEnabled));
            p.setProperty("joinVolume", Integer.toString(joinVolume));
            p.setProperty("leaveVolume", Integer.toString(leaveVolume));
            p.setProperty("joinSound", SoundChoice.sanitize(joinSound));
            p.setProperty("leaveSound", SoundChoice.sanitize(leaveSound));
            StringBuilder b = new StringBuilder();
            for (String f : friends) { if (b.length() > 0) b.append(','); b.append(f); }
            p.setProperty("friends", b.toString());
            for (String f : friends) p.setProperty("gear." + f.toLowerCase(Locale.ROOT), Boolean.toString(isGearShown(f)));
            out = new FileOutputStream(file);
            p.store(out, "Blacklisted Lobby Watcher Pit Classic friend-list mirror");
        } catch (Exception e) {
            System.err.println("[BlacklistedLobbyWatcher] Could not save friend config.");
        } finally {
            if (out != null) try { out.close(); } catch (Exception ignored) { }
        }
    }

    private boolean addInternal(String name) {
        if (!BlacklistManager.isValidPlayerName(name) || friends.size() >= MAX_FRIENDS || contains(name)) return false;
        friends.add(name.trim());
        return true;
    }

    public boolean add(String name) { boolean c = addInternal(name); if (c) save(); return c; }
    public boolean remove(String name) {
        if (name == null) return false;
        String n = name.trim().toLowerCase(Locale.ROOT);
        for (int i = friends.size() - 1; i >= 0; i--) {
            if (friends.get(i).toLowerCase(Locale.ROOT).equals(n)) { friends.remove(i); save(); return true; }
        }
        return false;
    }
    public boolean contains(String name) {
        if (name == null) return false;
        String n = name.trim().toLowerCase(Locale.ROOT);
        for (String f : friends) if (f.toLowerCase(Locale.ROOT).equals(n)) return true;
        return false;
    }
    public List<String> getFriends() { return Collections.unmodifiableList(new ArrayList<String>(friends)); }
    public boolean isGearShown(String name) { if (name == null) return true; Boolean v=gearShown.get(name.toLowerCase(Locale.ROOT)); return v==null||v.booleanValue(); }
    public void setGearShown(String name, boolean shown) { if(name==null)return; gearShown.put(name.toLowerCase(Locale.ROOT),Boolean.valueOf(shown)); save(); }

    private boolean parseBool(String v, boolean d) { if (v == null) return d; if ("true".equalsIgnoreCase(v)) return true; if ("false".equalsIgnoreCase(v)) return false; return d; }
    private int parseVolume(String v, int d) { try { return clampVolume(Integer.parseInt(v == null ? "" : v.trim())); } catch (Exception ignored) { return d; } }
    private int clampVolume(int v) { return Math.max(0, Math.min(100, v)); }
    public boolean isHudEnabled() { return hudEnabled; }
    public boolean isFfHudEnabled() { return ffHudEnabled; }
    public boolean isJoinPingEnabled() { return joinPingEnabled; }
    public boolean isLeavePingEnabled() { return leavePingEnabled; }
    public boolean isJoinChatEnabled() { return joinChatEnabled; }
    public boolean isLeaveChatEnabled() { return leaveChatEnabled; }
    public void setHudEnabled(boolean v) { hudEnabled=v; save(); }
    public void setFfHudEnabled(boolean v) { ffHudEnabled=v; save(); }
    public void setJoinPingEnabled(boolean v) { joinPingEnabled=v; save(); }
    public void setLeavePingEnabled(boolean v) { leavePingEnabled=v; save(); }
    public void setJoinChatEnabled(boolean v) { joinChatEnabled=v; save(); }
    public void setLeaveChatEnabled(boolean v) { leaveChatEnabled=v; save(); }
    public int getJoinVolume() { return joinVolume; }
    public int getLeaveVolume() { return leaveVolume; }
    public float getJoinVolumeFloat() { return 0.5F * (joinVolume / 50.0F); }
    public float getLeaveVolumeFloat() { return 0.5F * (leaveVolume / 50.0F); }
    public void setJoinVolume(int v) { joinVolume = clampVolume(v); }
    public void setLeaveVolume(int v) { leaveVolume = clampVolume(v); }
    public String getJoinSound() { return SoundChoice.sanitize(joinSound); }
    public String getLeaveSound() { return SoundChoice.sanitize(leaveSound); }
    public void setJoinSound(String id) { joinSound = SoundChoice.sanitize(id); }
    public void setLeaveSound(String id) { leaveSound = SoundChoice.sanitize(id); }
    public void resetSoundSettings() { joinVolume = 50; leaveVolume = 50; joinSound = SoundChoice.DEFAULT_ID; leaveSound = SoundChoice.DEFAULT_ID; save(); }
}
