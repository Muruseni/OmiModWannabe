package com.example.blacklistedlobbywatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Properties;

/** Stores client-only join/leave ping volumes independently for each list. */
public class SoundSettingsManager {
    private static final int DEFAULT_VOLUME = 50;
    private static final long MAX_CONFIG_BYTES = 64L * 1024L;
    private static final String PRIMARY = "Blacklist";

    private final File file;
    private final Properties values = new Properties();

    public SoundSettingsManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher_sound.properties");
    }

    public void load() {
        values.clear();
        if (!file.exists()) return;
        if (!file.isFile() || file.length() > MAX_CONFIG_BYTES) {
            System.err.println("[OmenaMod] Ignoring oversized or invalid sound config.");
            return;
        }
        FileInputStream input = null;
        try {
            Properties loaded = new Properties();
            input = new FileInputStream(file);
            loaded.load(input);

            // Preserve the confirmed-working 1.2.2/1.2.6 Blacklist slider values.
            if ("2".equals(loaded.getProperty("format"))) {
                setJoinVolume(PRIMARY, parseVolume(loaded.getProperty("joinVolume"), DEFAULT_VOLUME));
                setLeaveVolume(PRIMARY, parseVolume(loaded.getProperty("leaveVolume"), DEFAULT_VOLUME));
            }
            for (Object rawKey : loaded.keySet()) {
                String key = String.valueOf(rawKey);
                if (!key.startsWith("list.")) continue;
                String value = loaded.getProperty(key);
                if (key.endsWith(".joinSound") || key.endsWith(".leaveSound")) {
                    values.setProperty(key, SoundChoice.sanitize(value));
                } else {
                    try { values.setProperty(key, Integer.toString(clamp(Integer.parseInt(value.trim())))); }
                    catch (Exception ignored) { }
                }
            }
        } catch (Exception e) {
            values.clear();
            System.err.println("[OmenaMod] Could not parse sound config; using 50% defaults.");
        } finally {
            if (input != null) try { input.close(); } catch (Exception ignored) { }
        }
    }

    public void save() {
        FileOutputStream output = null;
        File temp = new File(file.getParentFile(), file.getName() + ".tmp");
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return;
            values.setProperty("format", "3");
            output = new FileOutputStream(temp);
            values.store(output, "OmenaMod per-list sound settings");
            output.flush();
            output.close();
            output = null;
            try {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            temp.delete();
            System.err.println("[OmenaMod] Could not save sound config.");
        } finally {
            if (output != null) try { output.close(); } catch (Exception ignored) { }
        }
    }

    public int getJoinVolume(String listName) { return getVolume(listName, "joinVolume"); }
    public int getLeaveVolume(String listName) { return getVolume(listName, "leaveVolume"); }
    public void setJoinVolume(String listName, int value) { values.setProperty(key(listName, "joinVolume"), Integer.toString(clamp(value))); }
    public void setLeaveVolume(String listName, int value) { values.setProperty(key(listName, "leaveVolume"), Integer.toString(clamp(value))); }
    public String getJoinSound(String listName) { return SoundChoice.sanitize(values.getProperty(key(listName, "joinSound"))); }
    public String getLeaveSound(String listName) { return SoundChoice.sanitize(values.getProperty(key(listName, "leaveSound"))); }
    public void setJoinSound(String listName, String id) { values.setProperty(key(listName, "joinSound"), SoundChoice.sanitize(id)); }
    public void setLeaveSound(String listName, String id) { values.setProperty(key(listName, "leaveSound"), SoundChoice.sanitize(id)); }
    public float getJoinVolumeFloat(String listName) { return 0.9F * (getJoinVolume(listName) / 50.0F); }
    public float getLeaveVolumeFloat(String listName) { return 0.9F * (getLeaveVolume(listName) / 50.0F); }
    public void resetDefaults(String listName) {
        values.remove(key(listName, "joinVolume"));
        values.remove(key(listName, "leaveVolume"));
        values.remove(key(listName, "joinSound"));
        values.remove(key(listName, "leaveSound"));
    }

    // Backward-compatible Blacklist methods.
    public int getJoinVolume() { return getJoinVolume(PRIMARY); }
    public int getLeaveVolume() { return getLeaveVolume(PRIMARY); }
    public void setJoinVolume(int value) { setJoinVolume(PRIMARY, value); }
    public void setLeaveVolume(int value) { setLeaveVolume(PRIMARY, value); }
    public float getJoinVolumeFloat() { return getJoinVolumeFloat(PRIMARY); }
    public float getLeaveVolumeFloat() { return getLeaveVolumeFloat(PRIMARY); }
    public void resetDefaults() { resetDefaults(PRIMARY); }

    private int getVolume(String listName, String kind) {
        return parseVolume(values.getProperty(key(listName, kind)), DEFAULT_VOLUME);
    }
    private int parseVolume(String value, int fallback) {
        try { return clamp(Integer.parseInt(value == null ? "" : value.trim())); }
        catch (Exception ignored) { return fallback; }
    }
    private int clamp(int value) { return Math.max(0, Math.min(100, value)); }
    private String key(String listName, String kind) {
        String safe = listName == null || "Blacklist".equalsIgnoreCase(listName.trim()) ? PRIMARY : listName.trim();
        if (!PRIMARY.equalsIgnoreCase(safe) && !AdditionalListManager.isValidListName(safe)) safe = PRIMARY;
        return "list." + safe.toLowerCase(Locale.ROOT) + "." + kind;
    }
}
