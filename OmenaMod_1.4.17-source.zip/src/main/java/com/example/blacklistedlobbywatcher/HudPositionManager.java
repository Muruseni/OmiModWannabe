package com.example.blacklistedlobbywatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/** Stores the HUD position separately from the blacklist JSON for backward compatibility. */
public class HudPositionManager {
    private static final int DEFAULT_X = 7;
    private static final int DEFAULT_Y = 7;
    private static final long MAX_CONFIG_BYTES = 4096L;
    private static final int MAX_ABSOLUTE_COORDINATE = 100000;

    private final File file;
    private int x = DEFAULT_X;
    private int y = DEFAULT_Y;
    private boolean hudEnabled = true;

    public HudPositionManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher_hud.properties");
    }

    public void load() {
        x = DEFAULT_X;
        y = DEFAULT_Y;
        hudEnabled = true;
        if (!file.exists()) return;
        if (!file.isFile() || file.length() > MAX_CONFIG_BYTES) {
            System.err.println("[BlacklistedLobbyWatcher] Ignoring oversized or invalid HUD config.");
            return;
        }

        FileInputStream input = null;
        try {
            Properties properties = new Properties();
            input = new FileInputStream(file);
            properties.load(input);
            x = parseCoordinate(properties.getProperty("x"), DEFAULT_X);
            y = parseCoordinate(properties.getProperty("y"), DEFAULT_Y);
            hudEnabled = parseBoolean(properties.getProperty("enabled"), true);
        } catch (Exception e) {
            x = DEFAULT_X;
            y = DEFAULT_Y;
            hudEnabled = true;
            System.err.println("[BlacklistedLobbyWatcher] Could not parse HUD config; using defaults.");
        } finally {
            if (input != null) {
                try { input.close(); } catch (Exception ignored) { }
            }
        }
    }

    public void save() {
        FileOutputStream output = null;
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                System.err.println("[BlacklistedLobbyWatcher] Could not create HUD config directory.");
                return;
            }

            Properties properties = new Properties();
            properties.setProperty("x", Integer.toString(x));
            properties.setProperty("y", Integer.toString(y));
            properties.setProperty("enabled", Boolean.toString(hudEnabled));

            output = new FileOutputStream(file);
            properties.store(output, "Blacklisted Lobby Watcher HUD position");
        } catch (Exception e) {
            System.err.println("[BlacklistedLobbyWatcher] Could not save HUD config.");
        } finally {
            if (output != null) {
                try { output.close(); } catch (Exception ignored) { }
            }
        }
    }

    private int parseCoordinate(String value, int fallback) {
        if (value == null) return fallback;
        try {
            int parsed = Integer.parseInt(value.trim());
            if (parsed < -MAX_ABSOLUTE_COORDINATE || parsed > MAX_ABSOLUTE_COORDINATE) return fallback;
            return parsed;
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }


    private boolean parseBoolean(String value, boolean fallback) {
        if (value == null) return fallback;
        String normalized = value.trim();
        if ("true".equalsIgnoreCase(normalized)) return true;
        if ("false".equalsIgnoreCase(normalized)) return false;
        return fallback;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public boolean isHudEnabled() {
        return hudEnabled;
    }

    public void setHudEnabled(boolean hudEnabled) {
        this.hudEnabled = hudEnabled;
    }
}
