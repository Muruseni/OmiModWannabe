package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Blacklist/list manager with one permanent Blacklist panel and one selectable extra-list panel. */
public class BlacklistSettingsScreen extends GuiScreen {
    private static final int BUTTON_BACK = 0;
    private static final int BUTTON_SETTINGS = 1;
    private static final int BUTTON_ADD_LIST = 2;
    private static final int BUTTON_PRIMARY_HUD = 10;
    private static final int BUTTON_PRIMARY_SORT = 11;
    private static final int BUTTON_SECONDARY_HUD = 20;
    private static final int BUTTON_SECONDARY_SORT = 21;
    private static final int BUTTON_EXTRA_BASE = 100;

    private static final int SORT_A_TO_Z = 0;
    private static final int SORT_Z_TO_A = 1;
    private static final int SORT_ADDED_OLDEST = 2;
    private static final int SORT_ADDED_NEWEST = 3;
    private static final int SORT_MODE_COUNT = 4;

    private static final int ROW_HEIGHT = 14;
    private static final int REMOVE_AREA_WIDTH = 20;
    private static final int GEAR_AREA_WIDTH = 28;
    private static final int SCROLLBAR_WIDTH = 5;
    private static final int WHEEL_ROWS = 3;

    private final GuiScreen parent;
    private final BlacklistManager blacklistManager;
    private final LobbyWatcher lobbyWatcher;
    private final AdditionalListManager additionalListManager;
    private final PlayerGearDisplayManager gearDisplayManager;

    private String selectedExtraList;
    private int primarySortMode = SORT_A_TO_Z;
    private int secondarySortMode = SORT_A_TO_Z;
    private int primaryScrollRow;
    private int secondaryScrollRow;
    private int draggingPanel;
    private int scrollbarGrabOffset;
    private int lastMouseX;
    private int lastMouseY;

    public BlacklistSettingsScreen(GuiScreen parent, BlacklistManager blacklistManager, LobbyWatcher lobbyWatcher) {
        this.parent = parent;
        this.blacklistManager = blacklistManager;
        this.lobbyWatcher = lobbyWatcher;
        this.additionalListManager = lobbyWatcher.getAdditionalListManager();
        this.gearDisplayManager = lobbyWatcher.getPlayerGearDisplayManager();
        List<String> names = additionalListManager.getListNames();
        if (!names.isEmpty()) selectedExtraList = names.get(0);
    }

    @Override
    public void func_73866_w_() {
        List<String> extras = additionalListManager.getListNames();
        normalizeSelectedExtra(extras);

        int centerX = this.field_146294_l / 2;
        int controlsLeft = Math.max(10, centerX - 145);
        this.field_146292_n.add(new GuiButton(BUTTON_SETTINGS, controlsLeft, 103, 140, 20, "Settings"));
        this.field_146292_n.add(new GuiButton(BUTTON_ADD_LIST, controlsLeft + 150, 103, 140, 20,
                additionalListManager.isAtCapacity() ? "Add List (5/5)" : "Add List"));

        Panel primary = getPrimaryPanel(extras);
        this.field_146292_n.add(new GuiButton(BUTTON_PRIMARY_HUD,
                primary.right - 72, 128, 72, 18, primaryHudLabel()));
        this.field_146292_n.add(new GuiButton(BUTTON_PRIMARY_SORT,
                primary.left, 149, primary.width, 18, sortLabel(primarySortMode)));

        if (!extras.isEmpty()) {
            Panel secondary = getSecondaryPanel(extras);
            this.field_146292_n.add(new GuiButton(BUTTON_SECONDARY_HUD,
                    secondary.right - 72, 128, 72, 18, secondaryHudLabel()));
            this.field_146292_n.add(new GuiButton(BUTTON_SECONDARY_SORT,
                    secondary.left, 149, secondary.width, 18, sortLabel(secondarySortMode)));

            if (extras.size() > 1) {
                int totalWidth = primary.width + 10 + secondary.width;
                int buttonGap = 4;
                int available = totalWidth - buttonGap * (extras.size() - 1);
                int buttonWidth = Math.max(45, available / extras.size());
                int x = primary.left;
                int y = getSelectorY(extras);
                for (int i = 0; i < extras.size(); i++) {
                    String name = extras.get(i);
                    this.field_146292_n.add(new GuiButton(BUTTON_EXTRA_BASE + i, x, y, buttonWidth, 18,
                            name.equalsIgnoreCase(selectedExtraList) ? "[" + name + "]" : name));
                    x += buttonWidth + buttonGap;
                }
            }
        }

        this.field_146292_n.add(new GuiButton(BUTTON_BACK, centerX - 50, this.field_146295_m - 26, 100, 20, "Back"));
        clampScrolls(extras);
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        lastMouseX = mouseX;
        lastMouseY = mouseY;
        List<String> extras = additionalListManager.getListNames();
        normalizeSelectedExtra(extras);
        if (draggingPanel != 0) updateScrollbarDrag(draggingPanel, mouseY, extras);

        OmenaUi.background(this.field_146294_l,this.field_146295_m);
        drawCentered("\u00A7b\u00A7lPlayer Lists", 14, 0xFFFFFF);
        drawCentered("\u00A77Manage Blacklist and your custom lists", 27, 0xFFFFFF);

        int commandsLeft = getPrimaryPanel(extras).left;
        Panel commandPanel=getPrimaryPanel(extras); int commandRight=extras.isEmpty()?commandPanel.right:getSecondaryPanel(extras).right;
        OmenaUi.softPanel(commandsLeft-6,34,commandRight+6,98);
        int y = 39;
        this.field_146289_q.func_78276_b("\u00A7bCommands", commandsLeft, y, 0xFFFFFF);
        y += 12;
        this.field_146289_q.func_78276_b("\u00A77/blw add <name>  |  /blw remove <name>", commandsLeft, y, 0xFFFFFF);
        y += 10;
        this.field_146289_q.func_78276_b("\u00A77/blw list  |  /blw check  |  /blw clear", commandsLeft, y, 0xFFFFFF);
        y += 10;
        this.field_146289_q.func_78276_b("\u00A77/blw createlist <name>  |  /blw lists", commandsLeft, y, 0xFFFFFF);
        y += 10;
        this.field_146289_q.func_78276_b("\u00A77/blw addto/removefrom <list> <name>", commandsLeft, y, 0xFFFFFF);
        this.field_146289_q.func_78276_b("\u00A77[G] beside a player toggles base gear label in that list HUD.", commandsLeft, y + 10, 0xFFFFFF);

        Panel primary = getPrimaryPanel(extras);
        List<String> primaryEntries = getSortedPrimaryEntries();
        clampPrimary(primaryEntries.size(), extras);
        drawPanel(primary, "Blacklist", primaryEntries, primaryScrollRow, mouseX, mouseY, true, extras);

        if (!extras.isEmpty() && selectedExtraList != null) {
            Panel secondary = getSecondaryPanel(extras);
            List<String> secondaryEntries = getSortedSecondaryEntries();
            clampSecondary(secondaryEntries.size(), extras);
            drawPanel(secondary, selectedExtraList, secondaryEntries, secondaryScrollRow, mouseX, mouseY, false, extras);
        }

        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    private void drawPanel(Panel panel, String name, List<String> entries, int scrollRow,
                           int mouseX, int mouseY, boolean primary, List<String> extras) {
        String count = "\u00A7b" + name + " \u00A77(" + entries.size() + ")";
        this.field_146289_q.func_78276_b(count, panel.left, 132, 0xFFFFFF);

        int top = getListTop();
        int bottom = getListBottom(extras);
        OmenaUi.panel(panel.left, top, panel.right, bottom);

        if (entries.isEmpty()) {
            String empty = primary ? "\u00A7eNo players on blacklist." : "\u00A7eThis list is empty.";
            this.field_146289_q.func_78276_b(empty, panel.left + 7, top + 8, 0xFFFFFF);
            return;
        }

        int visibleRows = getVisibleRows(extras);
        int end = Math.min(entries.size(), scrollRow + visibleRows);
        for (int index = scrollRow; index < end; index++) {
            int visibleIndex = index - scrollRow;
            int rowTop = top + visibleIndex * ROW_HEIGHT;
            int rowBottom = Math.min(bottom, rowTop + ROW_HEIGHT);
            boolean hovered = mouseX >= panel.left && mouseX < panel.right - SCROLLBAR_WIDTH
                    && mouseY >= rowTop && mouseY < rowBottom;
            if (hovered) Gui.func_73734_a(panel.left + 1, rowTop, panel.right - SCROLLBAR_WIDTH - 1, rowBottom, 0x403F3F3F);

            String player = entries.get(index);
            this.field_146289_q.func_78276_b("\u00A7c" + player, panel.left + 7, rowTop + 3, 0xFFFFFF);

            String targetList = primary ? "Blacklist" : name;
            int removeLeft = panel.right - SCROLLBAR_WIDTH - REMOVE_AREA_WIDTH;
            int removeRight = panel.right - SCROLLBAR_WIDTH;
            int gearLeft = removeLeft - GEAR_AREA_WIDTH;
            boolean gearShown = gearDisplayManager.isShown(targetList, player);
            boolean gearHovered = mouseX >= gearLeft && mouseX < removeLeft && mouseY >= rowTop && mouseY < rowBottom;
            if (gearHovered) Gui.func_73734_a(gearLeft, rowTop + 1, removeLeft, rowBottom - 1, 0x60444488);
            this.field_146289_q.func_78276_b(gearShown ? "\u00A7a[G]" : "\u00A77[ ]", gearLeft + 3, rowTop + 3, 0xFFFFFF);
            boolean removeHovered = mouseX >= removeLeft && mouseX < removeRight && mouseY >= rowTop && mouseY < rowBottom;
            if (removeHovered) Gui.func_73734_a(removeLeft, rowTop + 1, removeRight, rowBottom - 1, 0x60AA0000);
            this.field_146289_q.func_78276_b(removeHovered ? "\u00A7f\u00A7lX" : "\u00A7c\u00A7lX",
                    removeLeft + 6, rowTop + 3, 0xFFFFFF);
        }
        drawScrollbar(panel, entries.size(), scrollRow, extras);
    }

    private void drawScrollbar(Panel panel, int entryCount, int scrollRow, List<String> extras) {
        int visibleRows = getVisibleRows(extras);
        if (entryCount <= visibleRows) return;
        int trackLeft = panel.right - SCROLLBAR_WIDTH;
        int trackTop = getListTop();
        int trackBottom = getListBottom(extras);
        Gui.func_73734_a(trackLeft, trackTop, trackLeft + SCROLLBAR_WIDTH, trackBottom, 0x80444444);
        int thumbHeight = getScrollbarThumbHeight(entryCount, extras);
        int thumbTop = getScrollbarThumbTop(entryCount, scrollRow, extras);
        Gui.func_73734_a(trackLeft, thumbTop, trackLeft + SCROLLBAR_WIDTH, thumbTop + thumbHeight, 0xFFAAAAAA);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0) {
            List<String> extras = additionalListManager.getListNames();
            Panel primary = getPrimaryPanel(extras);
            List<String> primaryEntries = getSortedPrimaryEntries();
            if (handlePanelClick(1, primary, primaryEntries, primaryScrollRow, mouseX, mouseY, extras)) return;

            if (!extras.isEmpty() && selectedExtraList != null) {
                Panel secondary = getSecondaryPanel(extras);
                List<String> secondaryEntries = getSortedSecondaryEntries();
                if (handlePanelClick(2, secondary, secondaryEntries, secondaryScrollRow, mouseX, mouseY, extras)) return;
            }
        }
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    private boolean handlePanelClick(int panelId, Panel panel, List<String> entries, int scrollRow,
                                     int mouseX, int mouseY, List<String> extras) {
        int top = getListTop();
        int bottom = getListBottom(extras);
        if (mouseY >= top && mouseY < bottom && mouseX >= panel.left && mouseX < panel.right - SCROLLBAR_WIDTH) {
            int row = (mouseY - top) / ROW_HEIGHT;
            int index = scrollRow + row;
            int removeLeft = panel.right - SCROLLBAR_WIDTH - REMOVE_AREA_WIDTH;
            int removeRight = panel.right - SCROLLBAR_WIDTH;
            int gearLeft = removeLeft - GEAR_AREA_WIDTH;
            if (index >= 0 && index < entries.size() && mouseX >= gearLeft && mouseX < removeLeft) {
                String player = entries.get(index);
                String target = panelId == 1 ? "Blacklist" : selectedExtraList;
                gearDisplayManager.setShown(target, player, !gearDisplayManager.isShown(target, player));
                return true;
            }
            if (mouseX >= removeLeft && mouseX < removeRight && index >= 0 && index < entries.size()) {
                if (panelId == 1) blacklistManager.remove(entries.get(index));
                else additionalListManager.removePlayer(selectedExtraList, entries.get(index));
                clampScrolls(extras);
                return true;
            }
        }

        if (entries.size() > getVisibleRows(extras)
                && mouseX >= panel.right - SCROLLBAR_WIDTH && mouseX < panel.right
                && mouseY >= top && mouseY < bottom) {
            int thumbTop = getScrollbarThumbTop(entries.size(), scrollRow, extras);
            int thumbHeight = getScrollbarThumbHeight(entries.size(), extras);
            draggingPanel = panelId;
            if (mouseY >= thumbTop && mouseY < thumbTop + thumbHeight) scrollbarGrabOffset = mouseY - thumbTop;
            else {
                scrollbarGrabOffset = thumbHeight / 2;
                updateScrollbarDrag(panelId, mouseY, extras);
            }
            return true;
        }
        return false;
    }

    @Override
    protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (draggingPanel != 0 && clickedMouseButton == 0) {
            updateScrollbarDrag(draggingPanel, mouseY, additionalListManager.getListNames());
            return;
        }
        super.func_146273_a(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
    }

    @Override
    protected void func_146286_b(int mouseX, int mouseY, int state) {
        if (draggingPanel != 0 && state == 0) {
            updateScrollbarDrag(draggingPanel, mouseY, additionalListManager.getListNames());
            draggingPanel = 0;
            return;
        }
        super.func_146286_b(mouseX, mouseY, state);
    }

    @Override
    public void func_146274_d() {
        super.func_146274_d();
        int wheel = Mouse.getEventDWheel();
        if (wheel == 0) return;
        List<String> extras = additionalListManager.getListNames();
        int delta = wheel > 0 ? -WHEEL_ROWS : WHEEL_ROWS;
        if (!extras.isEmpty()) {
            Panel secondary = getSecondaryPanel(extras);
            if (lastMouseX >= secondary.left && lastMouseX < secondary.right
                    && lastMouseY >= getListTop() && lastMouseY < getListBottom(extras)) {
                secondaryScrollRow += delta;
            } else {
                primaryScrollRow += delta;
            }
        } else {
            primaryScrollRow += delta;
        }
        clampScrolls(extras);
    }

    @Override
    public void func_146281_b() {
        draggingPanel = 0;
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        int id = button.field_146127_k;
        if (id == BUTTON_BACK) {
            this.field_146297_k.func_147108_a(parent);
            return;
        }
        if (id == BUTTON_SETTINGS) {
            this.field_146297_k.func_147108_a(new ListSettingsSelectorScreen(this, lobbyWatcher));
            return;
        }
        if (id == BUTTON_ADD_LIST) {
            if (!additionalListManager.isAtCapacity()) this.field_146297_k.func_147108_a(new AddListScreen(this, additionalListManager));
            return;
        }
        if (id == BUTTON_PRIMARY_HUD) {
            lobbyWatcher.setHudEnabled(!lobbyWatcher.isHudEnabled());
            button.field_146126_j = primaryHudLabel();
            return;
        }
        if (id == BUTTON_PRIMARY_SORT) {
            primarySortMode = (primarySortMode + 1) % SORT_MODE_COUNT;
            primaryScrollRow = 0;
            button.field_146126_j = sortLabel(primarySortMode);
            return;
        }
        if (id == BUTTON_SECONDARY_HUD && selectedExtraList != null) {
            additionalListManager.setHudEnabled(selectedExtraList, !additionalListManager.isHudEnabled(selectedExtraList));
            button.field_146126_j = secondaryHudLabel();
            return;
        }
        if (id == BUTTON_SECONDARY_SORT) {
            secondarySortMode = (secondarySortMode + 1) % SORT_MODE_COUNT;
            secondaryScrollRow = 0;
            button.field_146126_j = sortLabel(secondarySortMode);
            return;
        }
        if (id >= BUTTON_EXTRA_BASE && id < BUTTON_EXTRA_BASE + AdditionalListManager.MAX_LISTS) {
            List<String> extras = additionalListManager.getListNames();
            int index = id - BUTTON_EXTRA_BASE;
            if (index >= 0 && index < extras.size()) {
                selectedExtraList = extras.get(index);
                secondaryScrollRow = 0;
                this.field_146292_n.clear();
                func_73866_w_();
            }
        }
    }

    private List<String> getSortedPrimaryEntries() {
        return sortEntries(blacklistManager.getEntries(), primarySortMode);
    }

    private List<String> getSortedSecondaryEntries() {
        if (selectedExtraList == null) return Collections.emptyList();
        return sortEntries(additionalListManager.getEntries(selectedExtraList), secondarySortMode);
    }

    private List<String> sortEntries(List<String> source, int mode) {
        List<String> entries = new ArrayList<String>(source);
        if (mode == SORT_A_TO_Z) Collections.sort(entries, String.CASE_INSENSITIVE_ORDER);
        else if (mode == SORT_Z_TO_A) Collections.sort(entries, Collections.reverseOrder(String.CASE_INSENSITIVE_ORDER));
        else if (mode == SORT_ADDED_NEWEST) Collections.reverse(entries);
        return entries;
    }

    private void normalizeSelectedExtra(List<String> extras) {
        if (extras.isEmpty()) {
            selectedExtraList = null;
            return;
        }
        if (selectedExtraList == null || !additionalListManager.containsList(selectedExtraList)) selectedExtraList = extras.get(0);
    }

    void selectList(String name) {
        if (name != null && additionalListManager.containsList(name)) {
            selectedExtraList = name;
            secondaryScrollRow = 0;
        }
    }

    private String primaryHudLabel() {
        return lobbyWatcher.isHudEnabled() ? "HUD: ON" : "HUD: OFF";
    }

    private String secondaryHudLabel() {
        return selectedExtraList != null && additionalListManager.isHudEnabled(selectedExtraList) ? "HUD: ON" : "HUD: OFF";
    }

    private String sortLabel(int mode) {
        if (mode == SORT_Z_TO_A) return "Sort: Z-A";
        if (mode == SORT_ADDED_OLDEST) return "Sort: Oldest";
        if (mode == SORT_ADDED_NEWEST) return "Sort: Newest";
        return "Sort: A-Z";
    }

    private Panel getPrimaryPanel(List<String> extras) {
        if (extras.isEmpty()) {
            int width = Math.min(290, Math.max(180, this.field_146294_l - 20));
            int left = (this.field_146294_l - width) / 2;
            return new Panel(left, width);
        }
        int width = Math.min(270, Math.max(135, (this.field_146294_l - 30) / 2));
        int total = width * 2 + 10;
        return new Panel((this.field_146294_l - total) / 2, width);
    }

    private Panel getSecondaryPanel(List<String> extras) {
        Panel primary = getPrimaryPanel(extras);
        return new Panel(primary.right + 10, primary.width);
    }

    private int getListTop() { return 170; }

    private int getListBottom(List<String> extras) {
        return Math.max(getListTop() + ROW_HEIGHT, this.field_146295_m - (extras.size() > 1 ? 62 : 34));
    }

    private int getSelectorY(List<String> extras) { return getListBottom(extras) + 4; }

    private int getVisibleRows(List<String> extras) {
        return Math.max(1, (getListBottom(extras) - getListTop()) / ROW_HEIGHT);
    }

    private void clampScrolls(List<String> extras) {
        clampPrimary(blacklistManager.size(), extras);
        clampSecondary(selectedExtraList == null ? 0 : additionalListManager.size(selectedExtraList), extras);
    }

    private void clampPrimary(int entryCount, List<String> extras) {
        int max = Math.max(0, entryCount - getVisibleRows(extras));
        primaryScrollRow = Math.max(0, Math.min(max, primaryScrollRow));
    }

    private void clampSecondary(int entryCount, List<String> extras) {
        int max = Math.max(0, entryCount - getVisibleRows(extras));
        secondaryScrollRow = Math.max(0, Math.min(max, secondaryScrollRow));
    }

    private int getScrollbarThumbHeight(int entryCount, List<String> extras) {
        int trackHeight = Math.max(1, getListBottom(extras) - getListTop());
        int visibleRows = getVisibleRows(extras);
        int calculated = Math.round(trackHeight * (visibleRows / (float)Math.max(1, entryCount)));
        return Math.max(12, Math.min(trackHeight, calculated));
    }

    private int getScrollbarThumbTop(int entryCount, int scrollRow, List<String> extras) {
        int visibleRows = getVisibleRows(extras);
        int maxScroll = Math.max(1, entryCount - visibleRows);
        int thumbHeight = getScrollbarThumbHeight(entryCount, extras);
        int travel = Math.max(1, (getListBottom(extras) - getListTop()) - thumbHeight);
        return getListTop() + Math.round((scrollRow / (float)maxScroll) * travel);
    }

    private void updateScrollbarDrag(int panelId, int mouseY, List<String> extras) {
        int entryCount = panelId == 1 ? blacklistManager.size() : (selectedExtraList == null ? 0 : additionalListManager.size(selectedExtraList));
        int maxScroll = Math.max(0, entryCount - getVisibleRows(extras));
        if (maxScroll <= 0) {
            if (panelId == 1) primaryScrollRow = 0; else secondaryScrollRow = 0;
            return;
        }
        int thumbHeight = getScrollbarThumbHeight(entryCount, extras);
        int travel = Math.max(1, (getListBottom(extras) - getListTop()) - thumbHeight);
        int relative = Math.max(0, Math.min(travel, mouseY - scrollbarGrabOffset - getListTop()));
        int value = Math.round((relative / (float)travel) * maxScroll);
        if (panelId == 1) primaryScrollRow = value; else secondaryScrollRow = value;
    }

    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }

    private static final class Panel {
        final int left;
        final int width;
        final int right;
        Panel(int left, int width) {
            this.left = left;
            this.width = width;
            this.right = left + width;
        }
    }
}
