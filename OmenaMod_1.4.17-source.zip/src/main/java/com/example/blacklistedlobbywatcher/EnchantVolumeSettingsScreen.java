package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class EnchantVolumeSettingsScreen extends GuiScreen {
    private static final int SLIDER_W=150,SLIDER_H=12;
    private final GuiScreen parent; private final LobbyWatcher watcher; private final EnchantSettingsManager settings; private final String target,category,enchant; private int dragging;
    public EnchantVolumeSettingsScreen(GuiScreen parent,LobbyWatcher watcher,String target,String category,String enchant){this.parent=parent;this.watcher=watcher;this.settings=watcher.getEnchantSettingsManager();this.target=target;this.category=category;this.enchant=enchant;}
    @Override public void func_73866_w_(){int cx=field_146294_l/2,top=field_146295_m/2-70;field_146292_n.add(new GuiButton(1,cx+55,top+34,55,18,"Preview"));field_146292_n.add(new GuiButton(2,cx+55,top+92,55,18,"Preview"));field_146292_n.add(new GuiButton(0,cx-100,top+126,200,20,"Back"));}
    @Override public void func_73863_a(int mx,int my,float pt){if(dragging!=0)update(dragging,mx);OmenaUi.background(field_146294_l,field_146295_m);int cx=field_146294_l/2,top=field_146295_m/2-70;center("\u00A7b\u00A7l"+enchant+" Volume",top-28);field_146289_q.func_78276_b("\u00A7fJoin / detected: \u00A7b"+settings.getJoinVolume(target,category,enchant)+"%",cx-100,top+8,0xFFFFFF);slider(cx-100,top+34,settings.getJoinVolume(target,category,enchant));field_146289_q.func_78276_b("\u00A7fLeave: \u00A7b"+settings.getLeaveVolume(target,category,enchant)+"%",cx-100,top+66,0xFFFFFF);slider(cx-100,top+92,settings.getLeaveVolume(target,category,enchant));super.func_73863_a(mx,my,pt);}
    private void slider(int x,int y,int v){Gui.func_73734_a(x,y+4,x+SLIDER_W,y+8,0xFF555555);int f=Math.round(SLIDER_W*(v/100.0F));Gui.func_73734_a(x,y+4,x+f,y+8,0xFFCC3333);Gui.func_73734_a(x+f-3,y,x+f+3,y+SLIDER_H,0xFFFFFFFF);}
    @Override protected void func_73864_a(int mx,int my,int mb){if(mb==0){int cx=field_146294_l/2,top=field_146295_m/2-70;if(inside(mx,my,cx-100,top+34)){dragging=1;update(1,mx);return;}if(inside(mx,my,cx-100,top+92)){dragging=2;update(2,mx);return;}}super.func_73864_a(mx,my,mb);}
    @Override protected void func_146273_a(int mx,int my,int mb,long t){if(dragging!=0&&mb==0){update(dragging,mx);return;}super.func_146273_a(mx,my,mb,t);} @Override protected void func_146286_b(int mx,int my,int state){if(dragging!=0&&state==0){update(dragging,mx);dragging=0;settings.save();return;}super.func_146286_b(mx,my,state);}
    @Override protected void func_146284_a(GuiButton b){if(b.field_146127_k==0){settings.save();field_146297_k.func_147108_a(parent);}else if(b.field_146127_k==1)watcher.previewEnchantPing(target,category,enchant,true);else if(b.field_146127_k==2)watcher.previewEnchantPing(target,category,enchant,false);}
    @Override public void func_146281_b(){dragging=0;settings.save();} private boolean inside(int mx,int my,int x,int y){return mx>=x-4&&mx<=x+SLIDER_W+4&&my>=y-4&&my<=y+SLIDER_H+4;} private void update(int which,int mx){int x=field_146294_l/2-100,c=Math.max(x,Math.min(x+SLIDER_W,mx));int v=Math.round(((c-x)/(float)SLIDER_W)*100.0F);if(which==1)settings.setJoinVolume(target,category,enchant,v);else settings.setLeaveVolume(target,category,enchant,v);} private void center(String s,int y){field_146289_q.func_78276_b(s,(field_146294_l-field_146289_q.func_78256_a(s))/2,y,0xFFFFFF);}
}
