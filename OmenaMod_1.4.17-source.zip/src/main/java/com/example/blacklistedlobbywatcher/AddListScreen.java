package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;

/** Small client-side form for creating a named additional list. */
public class AddListScreen extends GuiScreen {
    private final BlacklistSettingsScreen parent;
    private final AdditionalListManager listManager;
    private GuiTextField nameField;
    private String status = "";

    public AddListScreen(BlacklistSettingsScreen parent, AdditionalListManager listManager) {
        this.parent = parent;
        this.listManager = listManager;
    }

    @Override
    public void func_73866_w_() {
        int centerX = this.field_146294_l / 2;
        int centerY = this.field_146295_m / 2;
        nameField = new GuiTextField(10, this.field_146289_q, centerX - 100, centerY - 25, 200, 20);
        nameField.func_146203_f(16);
        nameField.func_146195_b(true);
        this.field_146292_n.add(new GuiButton(1, centerX - 100, centerY + 5, 95, 20, "Create"));
        this.field_146292_n.add(new GuiButton(0, centerX + 5, centerY + 5, 95, 20, "Cancel"));
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        OmenaUi.background(this.field_146294_l,this.field_146295_m);
        int centerY = this.field_146295_m / 2; int centerX=this.field_146294_l/2;
        OmenaUi.panel(centerX-116,centerY-82,centerX+116,centerY+52);
        OmenaUi.pageTitle(this.field_146289_q,this.field_146294_l,"Create Player List","Use 1-16 letters, numbers, _ or -",centerY-69);
        if (nameField != null) nameField.func_146194_f();
        if (!status.isEmpty()) drawCentered(status, centerY + 34, 0xFFFFFF);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        if (nameField != null) nameField.func_146192_a(mouseX, mouseY, mouseButton);
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) {
        if (keyCode == 1) {
            this.field_146297_k.func_147108_a(parent);
            return;
        }
        if (keyCode == 28 || keyCode == 156) {
            tryCreate();
            return;
        }
        if (nameField != null) nameField.func_146201_a(typedChar, keyCode);
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == 1) {
            tryCreate();
        } else if (button.field_146127_k == 0) {
            this.field_146297_k.func_147108_a(parent);
        }
    }

    private void tryCreate() {
        String name = nameField == null ? "" : nameField.func_146179_b().trim();
        if (!AdditionalListManager.isValidListName(name)) {
            status = "\u00A7cInvalid list name.";
            return;
        }
        if ("blacklist".equalsIgnoreCase(name) || listManager.containsList(name)) {
            status = "\u00A7eThat list already exists.";
            return;
        }
        if (listManager.isAtCapacity()) {
            status = "\u00A7cList limit reached (" + AdditionalListManager.MAX_LISTS + ").";
            return;
        }
        if (listManager.createList(name)) {
            parent.selectList(name);
            this.field_146297_k.func_147108_a(parent);
        } else {
            status = "\u00A7cCould not create that list.";
        }
    }

    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
