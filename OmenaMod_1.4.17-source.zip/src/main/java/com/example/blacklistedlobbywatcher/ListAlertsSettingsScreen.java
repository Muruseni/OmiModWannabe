package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** All chat and ping controls for one named list. */
public class ListAlertsSettingsScreen extends GuiScreen {
    private final GuiScreen parent; private final FeatureSettingsManager features; private final AlertThrottleManager throttle; private final String listName;
    public ListAlertsSettingsScreen(GuiScreen parent, LobbyWatcher watcher, String listName) { this.parent=parent; this.features=watcher.getFeatureSettingsManager(); this.throttle=watcher.getAlertThrottleManager(); this.listName=listName==null?"Blacklist":listName; }
    @Override public void func_73866_w_(){int cx=field_146294_l/2,top=Math.max(38,field_146295_m/2-98);field_146292_n.add(new GuiButton(1,cx-105,top,210,20,"Join / detected chat: "+on(features.isJoinChatEnabled(listName))));field_146292_n.add(new GuiButton(2,cx-105,top+24,210,20,"Leave chat: "+on(features.isLeaveChatEnabled(listName))));field_146292_n.add(new GuiButton(3,cx-105,top+48,210,20,"Throttle chat alerts: "+on(throttle.isChatThrottle(listName))));field_146292_n.add(new GuiButton(4,cx-105,top+78,210,20,"Join / detected ping: "+on(features.isJoinPingEnabled(listName))));field_146292_n.add(new GuiButton(5,cx-105,top+102,210,20,"Leave ping: "+on(features.isLeavePingEnabled(listName))));field_146292_n.add(new GuiButton(6,cx-105,top+126,210,20,"Throttle pings: "+on(throttle.isPingThrottle(listName))));field_146292_n.add(new GuiButton(0,cx-105,top+158,210,20,"Back"));}
    @Override public void func_73863_a(int x,int y,float p){OmenaUi.background(field_146294_l,field_146295_m);center("\u00A7b\u00A7l"+listName+" Alerts",18);center("\u00A77Chat alerts and sound pings",34);super.func_73863_a(x,y,p);}
    @Override protected void func_146284_a(GuiButton b){switch(b.field_146127_k){case 0:features.save();field_146297_k.func_147108_a(parent);return;case 1:features.setJoinChatEnabled(listName,!features.isJoinChatEnabled(listName));break;case 2:features.setLeaveChatEnabled(listName,!features.isLeaveChatEnabled(listName));break;case 3:throttle.setChatThrottle(listName,!throttle.isChatThrottle(listName));break;case 4:features.setJoinPingEnabled(listName,!features.isJoinPingEnabled(listName));break;case 5:features.setLeavePingEnabled(listName,!features.isLeavePingEnabled(listName));break;case 6:throttle.setPingThrottle(listName,!throttle.isPingThrottle(listName));break;}features.save();field_146292_n.clear();func_73866_w_();}
    @Override public void func_146281_b(){features.save();}
    private String on(boolean v){return v?"ON":"OFF";} private void center(String s,int y){field_146289_q.func_78276_b(s,(field_146294_l-field_146289_q.func_78256_a(s))/2,y,0xFFFFFF);}
}
