package com.example.blacklistedlobbywatcher;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.util.ChatComponentText;
import java.util.*;

/** Passive Mystic Watcher: inspects only equipment already synchronized to the client. */
public class MysticWatcher {
    private final Minecraft mc; private final BlacklistManager blacklist; private final AdditionalListManager lists;
    private final MysticWatcherManager manager; private final EnchantSettingsManager enchants; private final CustomItemRuleManager custom;
    private final AlertThrottleManager throttle;
    private final Map<UUID,Watched> current=new LinkedHashMap<UUID,Watched>(); private final Map<String,String> activeItems=new HashMap<String,String>();
    public MysticWatcher(Minecraft mc,BlacklistManager b,AdditionalListManager l,MysticWatcherManager m,EnchantSettingsManager e,CustomItemRuleManager c,AlertThrottleManager t){this.mc=mc;blacklist=b;lists=l;manager=m;enchants=e;custom=c;throttle=t;}
    public void tick(Collection<NetworkPlayerInfo> infos){Map<UUID,Watched> next=new LinkedHashMap<UUID,Watched>();java.util.HashSet<UUID> present=new java.util.HashSet<UUID>();if(infos!=null){int checked=0;for(NetworkPlayerInfo info:infos){if(++checked>1000)break;if(info==null)continue;try{GameProfile p=info.func_178845_a();if(p==null||p.getId()==null||!BlacklistManager.isValidPlayerName(p.getName())||omitted(p.getName()))continue;present.add(p.getId());GearInfoUtil.GearData pants=GearInfoUtil.getLeggingsGear(mc,p.getId()),held=GearInfoUtil.getHeldGear(mc,p.getId());SlotMatch wear=matchSlot(pants,true),hand=matchSlot(held,false);String name=p.getName();processItem(p.getId(),name,"wearing",wear,pants.signature);processItem(p.getId(),name,"holding",hand,held.signature);if(!wear.display.isEmpty()||!hand.display.isEmpty())next.put(p.getId(),new Watched(name,wear,hand));}catch(RuntimeException ignored){}}}current.clear();current.putAll(next);pruneActive(present);}
    private boolean omitted(String name){if(manager.isOmitted("Blacklist")&&blacklist.contains(name))return true;for(String l:lists.getListNames())if(manager.isOmitted(l)&&lists.containsPlayer(l,name))return true;return false;}
    private SlotMatch matchSlot(GearInfoUtil.GearData gear,boolean pants){SlotMatch out=new SlotMatch();if(gear==null||gear.isEmpty())return out;for(String cat:EnchantRegistry.categories()){if(pants&&!EnchantRegistry.isLeggingsCategory(cat))continue;if(!pants&&!EnchantRegistry.isHeldCategory(cat))continue;for(String e:EnchantRegistry.enchantsFor(cat)){String line=GearInfoUtil.findEnchantTierLine(gear.enchants,e);if(line==null)continue;if(enchants.isDisplayEnabled("MysticWatcher",cat,e))out.display.add(colour(cat,e,line));if(enchants.isJoinPingEnabled("MysticWatcher",cat,e)){out.ping=true;if(out.sound==null){out.sound=enchants.getJoinSound("MysticWatcher",cat,e);out.volume=enchants.getJoinVolumeFloat("MysticWatcher",cat,e);}out.localPingThrottle|=enchants.isThrottlePingEnabled("MysticWatcher",cat,e);}if(enchants.isJoinChatEnabled("MysticWatcher",cat,e)){out.chat.add(line);out.chatColour=enchants.getJoinColour("MysticWatcher",cat,e);out.localChatThrottle|=enchants.isThrottleChatEnabled("MysticWatcher",cat,e);}}}
        for(CustomItemRuleManager.Rule r:custom.getRules()){if(custom.matches(r,gear.enchants)){if(r.enabled)out.display.add("\u00A7"+r.displayColour+r.name);if(r.ping){out.ping=true;if(out.sound==null){out.sound=r.sound;out.volume=.9F*(r.volume/50F);}}if(r.chat){out.chat.add(r.name);out.chatColour=r.chatColour;}}}return out;}
    private String colour(String cat,String e,String line){String prefix=EnchantRegistry.definition(cat,e)!=null&&EnchantRegistry.definition(cat,e).rare?"\u00A7dRARE! ":"";return prefix+"\u00A7"+enchants.getDisplayColour("MysticWatcher",cat,e)+line;}
    private void processItem(UUID id,String player,String slot,SlotMatch match,String signature){String key=id+"|"+slot,old=activeItems.get(key);if(match.hasAlert()){String sig=signature+"|"+match.chat.toString()+"|"+match.ping;if(!sig.equals(old)){activeItems.put(key,sig);String ev=key+"|"+sig;if(match.ping&&throttle.allowPing("MysticWatcher",ev,match.localPingThrottle))sound(match.sound,match.volume,1.35F);if(!match.chat.isEmpty()&&throttle.allowChat("MysticWatcher",ev,match.localChatThrottle))chat("\u00A7"+match.chatColour+"[Mystic] \u00A7f"+player+" \u00A7"+match.chatColour+"is "+slot+" "+joinPlain(match.chat)+".");}}else activeItems.remove(key);}
    private void pruneActive(Set<UUID> present){Iterator<String>it=activeItems.keySet().iterator();while(it.hasNext()){String k=it.next();int p=k.indexOf('|');try{UUID id=UUID.fromString(p<0?k:k.substring(0,p));if(!present.contains(id))it.remove();}catch(Exception e){it.remove();}}}
    public List<String> hudLines(){return hudLines(null);}
    public List<String> hudLines(FontRenderer font){
        List<String> lines=new ArrayList<String>();
        lines.add("\u00A7d\u00A7lMystic Watcher \u00A77("+current.size()+")");
        if(current.isEmpty()){lines.add("\u00A77No watched mystics loaded");return lines;}
        int playerWidth=font==null?90:font.func_78256_a("Player");
        int wearingWidth=font==null?145:font.func_78256_a("Wearing");
        if(font!=null){
            for(Watched w:current.values()){playerWidth=Math.max(playerWidth,font.func_78256_a(w.name));for(String x:w.wear.display)wearingWidth=Math.max(wearingWidth,font.func_78256_a(x));}
            playerWidth+=14; wearingWidth+=18;
        }
        lines.add(columns(font,"\u00A77Player","\u00A7bWearing","\u00A76Holding",playerWidth,wearingWidth));
        for(Watched w:current.values()){
            List<String>a=w.wear.display,b=w.held.display;int rows=Math.max(1,Math.max(a.size(),b.size()));
            for(int i=0;i<rows;i++){String n=i==(rows-1)/2?w.name:"";String x=i<a.size()?a.get(i):"",y=i<b.size()?b.get(i):"";lines.add(columns(font,n,x,y,playerWidth,wearingWidth));}
            lines.add("§8------------------------------------------------------------------------");
        }
        return lines;
    }
    private String columns(FontRenderer font,String a,String b,String c,int firstWidth,int secondWidth){
        if(font==null)return padChars(a,16)+padChars(b,24)+c;
        StringBuilder out=new StringBuilder(a);padPixels(font,out,firstWidth);out.append(b);padPixels(font,out,firstWidth+secondWidth);out.append(c);return out.toString();
    }
    private void padPixels(FontRenderer font,StringBuilder s,int target){int guard=0;while(font.func_78256_a(s.toString())<target&&guard++<80)s.append(' ');}
    private String padChars(String s,int n){String plain=GearInfoUtil.stripFormatting(s);StringBuilder b=new StringBuilder(s);while(plain.length()<n){b.append(' ');plain+=" ";}return b.toString();}
    private String joinPlain(List<String> l){StringBuilder b=new StringBuilder();for(String s:l){if(b.length()>0)b.append(", ");b.append(GearInfoUtil.stripFormatting(s));}return b.toString();}
    private void sound(String id,float vol,float pitch){if(mc.field_71439_g==null||vol<=0)return;try{mc.field_71439_g.func_85030_a(SoundChoice.sanitize(id),OverallSettingsManager.applyGlobalVolume(vol),pitch);}catch(RuntimeException ignored){}}
    private void chat(String s){if(mc.field_71439_g!=null)mc.field_71439_g.func_145747_a(new ChatComponentText(s));}
    public MysticWatcherManager getManager(){return manager;} public CustomItemRuleManager getCustomRules(){return custom;}
    private static final class Watched{final String name;final SlotMatch wear,held;Watched(String n,SlotMatch w,SlotMatch h){name=n;wear=w;held=h;}}
    private static final class SlotMatch{final List<String>display=new ArrayList<String>(),chat=new ArrayList<String>();boolean ping,localPingThrottle,localChatThrottle;String sound,chatColour="d";float volume=.9F;boolean hasAlert(){return ping||!chat.isEmpty();}}
}
