package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** Sound-ping enable/throttle controls for one named list. */
public class ListPingsSettingsScreen extends GuiScreen {
    private final GuiScreen parent;
    private final FeatureSettingsManager features;
    private final AlertThrottleManager throttle;
    private final String listName;

    public ListPingsSettingsScreen(GuiScreen parent, LobbyWatcher watcher, String listName) {
        this.parent=parent;this.features=watcher.getFeatureSettingsManager();this.throttle=watcher.getAlertThrottleManager();this.listName=listName==null?"Blacklist":listName;
    }
    @Override public void func_73866_w_(){int cx=field_146294_l/2,top=Math.max(58,field_146295_m/2-62);field_146292_n.add(new GuiButton(1,cx-105,top,210,20,joinLabel()));field_146292_n.add(new GuiButton(2,cx-105,top+26,210,20,leaveLabel()));field_146292_n.add(new GuiButton(3,cx-105,top+52,210,20,"Throttle pings: "+on(throttle.isPingThrottle(listName))));field_146292_n.add(new GuiButton(0,cx-105,top+84,210,20,"Back"));}
    @Override public void func_73863_a(int x,int y,float p){OmenaUi.background(field_146294_l,field_146295_m);center("\u00A7b\u00A7l"+listName+" Pings",24);center("\u00A77Ping enable / throttle settings",40);super.func_73863_a(x,y,p);}
    @Override protected void func_146284_a(GuiButton b){if(b.field_146127_k==0){features.save();field_146297_k.func_147108_a(parent);return;}if(b.field_146127_k==1)features.setJoinPingEnabled(listName,!features.isJoinPingEnabled(listName));else if(b.field_146127_k==2)features.setLeavePingEnabled(listName,!features.isLeavePingEnabled(listName));else if(b.field_146127_k==3)throttle.setPingThrottle(listName,!throttle.isPingThrottle(listName));features.save();field_146292_n.clear();func_73866_w_();}
    @Override public void func_146281_b(){features.save();}
    private String joinLabel(){return"Join / detected ping: "+on(features.isJoinPingEnabled(listName));}private String leaveLabel(){return"Leave ping: "+on(features.isLeavePingEnabled(listName));}private String on(boolean v){return v?"ON":"OFF";}private void center(String s,int y){field_146289_q.func_78276_b(s,(field_146294_l-field_146289_q.func_78256_a(s))/2,y,0xFFFFFF);}
}
