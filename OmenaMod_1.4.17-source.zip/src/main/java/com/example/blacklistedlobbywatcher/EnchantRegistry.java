package com.example.blacklistedlobbywatcher;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Fixed developer-controlled Pit Classic enchant catalogue. */
public final class EnchantRegistry {
    public static final String PANTS = "Pants";
    public static final String SWORDS = "Swords";
    public static final String BOWS = "Bows";
    public static final String DARKS = "Darks";
    private static final String[] CATEGORIES = {PANTS, SWORDS, BOWS, DARKS};
    private static final List<Definition> DEFINITIONS = new ArrayList<Definition>();

    static {
        // PANTS - rares
        add(PANTS, "Assassin", true, true, false, false, "f");
        add(PANTS, "Divine Miracle", true, false, false, false, "f");
        add(PANTS, "Escape Pod", true, true, false, false, "f");
        add(PANTS, "Gomraw's Heart", true, false, false, false, "f");
        add(PANTS, "Instaboom", true, false, false, false, "f");
        add(PANTS, "Martyrdom", true, true, false, false, "f");
        add(PANTS, "Phoenix", true, true, false, false, "f");
        add(PANTS, "Pit Blob", true, true, false, false, "f");
        add(PANTS, "Singularity", true, true, false, false, "f");
        add(PANTS, "Solitude", true, true, true, false, "f");
        add(PANTS, "Snowballs", true, false, false, false, "f");
        add(PANTS, "Snowmen Army", true, false, false, false, "f");
        add(PANTS, "Wolf Pack", true, false, false, false, "f");
        add(PANTS, "Pit MBA", true, true, false, false, "f");
        add(PANTS, "Fractional Reserve", true, true, false, false, "f");
        add(PANTS, "Paparazzi", true, false, false, false, "f");
        add(PANTS, "Double-Jump", true, true, true, false, "f");

        // PANTS - non-rares
        add(PANTS, "Billy", false, true, false, false, "f");
        add(PANTS, "Cricket", false, false, false, false, "f");
        add(PANTS, "David and Goliath", false, true, false, false, "f");
        add(PANTS, "Diamond Allergy", false, true, false, false, "f");
        add(PANTS, "McSwimmer", false, false, false, false, "f");
        add(PANTS, "\"Not\" Gladiator", false, true, false, false, "f");
        add(PANTS, "Protection", false, true, false, false, "f");
        add(PANTS, "Ring Armor", false, false, false, false, "f");
        add(PANTS, "Sweaty", false, true, false, false, "f");
        add(PANTS, "XP Boost", false, true, false, false, "f");
        add(PANTS, "XP Bump", false, true, false, false, "f");
        add(PANTS, "Critically Rich", false, false, false, false, "f");
        add(PANTS, "Gold Boost", false, true, false, false, "f");
        add(PANTS, "Gold Bump", false, true, false, false, "f");
        add(PANTS, "Lodbrok", false, false, false, false, "f");
        add(PANTS, "Moctezuma", false, true, false, false, "f");
        add(PANTS, "Negotiator", false, false, false, false, "f");
        add(PANTS, "Pebble", false, false, false, false, "f");
        add(PANTS, "Purple Gold", false, false, false, false, "f");
        add(PANTS, "Self-checkout", false, false, false, false, "f");
        add(PANTS, "Strike Gold", false, false, false, false, "f");
        add(PANTS, "Pants Radar", false, true, false, false, "f");
        add(PANTS, "Boo-boo", false, true, false, false, "f");
        add(PANTS, "Counter-Offensive", false, true, false, false, "f");
        add(PANTS, "Creative", false, false, false, false, "f");
        add(PANTS, "Critically Funky", false, true, false, false, "f");
        add(PANTS, "Danger Close", false, true, false, false, "f");
        add(PANTS, "Eggs", false, false, false, false, "f");
        add(PANTS, "Electrolytes", false, true, false, false, "f");
        add(PANTS, "Excess", false, false, false, false, "f");
        add(PANTS, "Golden Heart", false, true, false, false, "f");
        add(PANTS, "Gotta go fast", false, true, true, false, "f");
        add(PANTS, "Hearts", false, true, false, false, "f");
        add(PANTS, "Hunt the Hunter", false, true, false, false, "f");
        add(PANTS, "Last Stand", false, true, false, false, "f");
        add(PANTS, "Mirror", false, true, true, false, "f");
        add(PANTS, "Peroxide", false, true, false, false, "f");
        add(PANTS, "Prick", false, true, false, false, "f");
        add(PANTS, "Respawn: Absorption", false, true, false, false, "f");
        add(PANTS, "Respawn: Resistance", false, false, false, false, "f");
        add(PANTS, "Revitalize", false, true, false, false, "f");
        add(PANTS, "Steaks", false, false, false, false, "f");
        add(PANTS, "TNT", false, false, false, false, "f");

        // SWORDS - rares
        add(SWORDS, "Billionaire", true, true, true, true, "f");
        add(SWORDS, "Combo: Perun's Wrath", true, true, true, true, "f");
        add(SWORDS, "Combo: Stun", true, false, false, false, "f");
        add(SWORDS, "Executioner", true, true, false, false, "f");
        add(SWORDS, "Gamble", true, true, true, true, "f");
        add(SWORDS, "Healer", true, true, false, false, "f");
        add(SWORDS, "Hemorrhage", true, false, false, false, "f");
        add(SWORDS, "Knockback", true, true, false, false, "f");
        add(SWORDS, "Speedy Hit", true, false, false, false, "f");
        add(SWORDS, "The Punch", true, true, true, false, "f");

        // SWORDS - non-rares
        add(SWORDS, "Beat the Spammers", false, false, false, false, "f");
        add(SWORDS, "Bounty Reaper", false, true, false, false, "f");
        add(SWORDS, "Combo: Damage", false, true, false, false, "f");
        add(SWORDS, "Diamond Stomp", false, true, false, false, "f");
        add(SWORDS, "Fancy Raider", false, true, false, false, "f");
        add(SWORDS, "Grasshopper", false, false, false, false, "f");
        add(SWORDS, "Gold and Boosted", false, true, false, false, "f");
        add(SWORDS, "King Buster", false, true, false, false, "f");
        add(SWORDS, "Pain Focus", false, true, false, false, "f");
        add(SWORDS, "Punisher", false, true, false, false, "f");
        add(SWORDS, "Shark", false, true, false, false, "f");
        add(SWORDS, "Sharp", false, true, false, false, "f");
        add(SWORDS, "Combo: XP", false, false, false, false, "f");
        add(SWORDS, "Sweaty", false, true, false, false, "f");
        add(SWORDS, "XP Boost", false, false, false, false, "f");
        add(SWORDS, "XP Bump", false, false, false, false, "f");
        add(SWORDS, "Critically Rich", false, false, false, false, "f");
        add(SWORDS, "Gold Boost", false, false, false, false, "f");
        add(SWORDS, "Gold Bump", false, false, false, false, "f");
        add(SWORDS, "Moctezuma", false, true, false, false, "f");
        add(SWORDS, "Pitpocket", false, false, false, false, "f");
        add(SWORDS, "Sierra", false, false, false, false, "f");
        add(SWORDS, "Strike Gold", false, false, false, false, "f");
        add(SWORDS, "Pants Radar", false, true, false, false, "f");
        add(SWORDS, "Berserker", false, true, false, false, "f");
        add(SWORDS, "Bruiser", false, true, false, false, "f");
        add(SWORDS, "Bullet Time", false, true, false, false, "f");
        add(SWORDS, "Combo: Heal", false, true, false, false, "f");
        add(SWORDS, "Combo: Swift", false, true, false, false, "f");
        add(SWORDS, "Counter-Janitor", false, false, false, false, "f");
        add(SWORDS, "Crush", false, false, false, false, "f");
        add(SWORDS, "Duelist", false, true, false, false, "f");
        add(SWORDS, "Guts", false, true, false, false, "f");
        add(SWORDS, "Lifesteal", false, true, false, false, "f");
        add(SWORDS, "Revengeance", false, false, false, false, "f");
        add(SWORDS, "Speedy Kill", false, false, false, false, "f");

        // BOWS - rares
        add(BOWS, "Devil Chicks!", true, true, false, false, "f");
        add(BOWS, "Explosive", true, true, false, false, "f");
        add(BOWS, "Lucky Shot", true, false, false, false, "f");
        add(BOWS, "Mega Longbow", true, true, false, false, "f");
        add(BOWS, "Pullbow", true, true, true, false, "f");
        add(BOWS, "Telebow", true, true, false, false, "f");
        add(BOWS, "True Shot", true, true, false, false, "f");
        add(BOWS, "Volley", true, true, false, false, "f");
        add(BOWS, "Robinhood", true, true, true, false, "f");

        // BOWS - non-rares
        add(BOWS, "Bottomless Quiver", false, false, false, false, "f");
        add(BOWS, "First Shot", false, false, false, false, "f");
        add(BOWS, "Fletching", false, false, false, false, "f");
        add(BOWS, "Jumpspammer", false, false, false, false, "f");
        add(BOWS, "Sniper", false, false, false, false, "f");
        add(BOWS, "Spammer and Proud", false, false, false, false, "f");
        add(BOWS, "Sweaty", false, false, false, false, "f");
        add(BOWS, "XP Boost", false, false, false, false, "f");
        add(BOWS, "XP Bump", false, false, false, false, "f");
        add(BOWS, "Critically Rich", false, false, false, false, "f");
        add(BOWS, "Gold Boost", false, false, false, false, "f");
        add(BOWS, "Gold Bump", false, false, false, false, "f");
        add(BOWS, "Moctezuma", false, false, false, false, "f");
        add(BOWS, "Strike Gold", false, false, false, false, "f");
        add(BOWS, "Pants Radar", false, false, false, false, "f");
        add(BOWS, "Arrow Armory", false, false, false, false, "f");
        add(BOWS, "Chipping", false, true, false, false, "f");
        add(BOWS, "Faster than their shadow", false, true, false, false, "f");
        add(BOWS, "Mixed Combat", false, false, false, false, "f");
        add(BOWS, "Parasite", false, true, false, false, "f");
        add(BOWS, "Pin down", false, true, false, false, "f");
        add(BOWS, "Push comes to shove", false, true, false, false, "f");
        add(BOWS, "Sprint Drain", false, true, false, false, "f");
        add(BOWS, "What doesn't kill you", false, false, false, false, "f");
        add(BOWS, "Wasp", false, true, false, false, "f");

        // DARKS - rares
        add(DARKS, "Nostalgia", true, true, false, false, "5");
        add(DARKS, "Combo: Venom", true, true, true, true, "a");
        add(DARKS, "Golden Handcuffs", true, true, false, false, "5");
        add(DARKS, "Heartripper", true, true, false, false, "5");

        // DARKS - non-rares
        add(DARKS, "Grim Reaper", false, true, false, false, "5");
        add(DARKS, "Hedge Fund", false, true, false, false, "5");
        add(DARKS, "Lycanthropy", false, true, false, false, "5");
        add(DARKS, "Mind Assault", false, true, true, false, "5");
        add(DARKS, "Misery", false, true, true, false, "5");
        add(DARKS, "Needless Suffering", false, true, false, false, "5");
        add(DARKS, "Sanguisuge", false, true, false, false, "5");
        add(DARKS, "Spite", false, true, false, false, "5");
    }

    private EnchantRegistry() { }

    private static void add(String category, String name, boolean rare,
                            boolean defaultDisplay, boolean defaultPing, boolean defaultChat,
                            String displayColour) {
        String colour = displayColour;
        if (DARKS.equals(category)) colour = "Combo: Venom".equalsIgnoreCase(name) ? "a" : "5";
        else if (colour == null || colour.length() != 1) colour = "f";
        DEFINITIONS.add(new Definition(category, name, rare, defaultDisplay, defaultPing, defaultChat, colour));
    }

    public static List<String> categories() {
        List<String> out = new ArrayList<String>();
        Collections.addAll(out, CATEGORIES);
        return out;
    }

    public static List<String> enchantsFor(String category) {
        List<String> out = new ArrayList<String>();
        for (Definition d : DEFINITIONS) if (d.category.equals(category)) out.add(d.name);
        return out;
    }

    public static Definition definition(String category, String enchant) {
        if (category == null || enchant == null) return null;
        for (Definition d : DEFINITIONS) {
            if (d.category.equalsIgnoreCase(category.trim()) && d.name.equalsIgnoreCase(enchant.trim())) return d;
        }
        return null;
    }

    public static Definition definitionByName(String enchant) {
        if (enchant == null) return null;
        for (Definition d : DEFINITIONS) if (d.name.equalsIgnoreCase(enchant.trim())) return d;
        return null;
    }

    public static boolean isKnownEnchant(String category, String enchant) { return definition(category, enchant) != null; }
    public static String canonicalEnchant(String category, String enchant) { Definition d=definition(category,enchant); return d==null?null:d.name; }
    public static boolean isLeggingsCategory(String category) { return PANTS.equals(category) || DARKS.equals(category); }
    public static boolean isHeldCategory(String category) { return SWORDS.equals(category) || BOWS.equals(category); }

    public static String displayName(String category, String enchant) {
        Definition d = definition(category, enchant);
        if (d == null) return enchant == null ? "" : enchant;
        return d.rare ? "\u00A7dRARE! \u00A7r" + d.name : d.name;
    }

    public static String id(String value) {
        if (value == null) return "unknown";
        String lower = value.toLowerCase(Locale.ROOT);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) out.append(c);
            else if (c == '_' || c == '-') out.append(c);
        }
        return out.length() == 0 ? "unknown" : out.toString();
    }

    public static final class Definition {
        public final String category;
        public final String name;
        public final boolean rare;
        public final boolean defaultDisplay;
        public final boolean defaultPing;
        public final boolean defaultChat;
        public final String defaultDisplayColour;
        Definition(String category, String name, boolean rare, boolean defaultDisplay, boolean defaultPing, boolean defaultChat, String defaultDisplayColour) {
            this.category=category; this.name=name; this.rare=rare; this.defaultDisplay=defaultDisplay;
            this.defaultPing=defaultPing; this.defaultChat=defaultChat; this.defaultDisplayColour=defaultDisplayColour;
        }
    }
}
