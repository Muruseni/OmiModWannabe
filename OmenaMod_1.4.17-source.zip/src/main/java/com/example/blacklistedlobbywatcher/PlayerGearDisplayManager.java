package com.example.blacklistedlobbywatcher;

import java.io.*;
import java.util.Locale;
import java.util.Properties;

/** Per-list/per-player toggle for showing the base equipment label (Diamond/BHunter/Mystic Bow/etc). */
public class PlayerGearDisplayManager {
    private final File file; private final Properties values=new Properties();
    public PlayerGearDisplayManager(File dir){file=new File(dir,"omenamod_player_gear_display.properties");}
    public void load(){values.clear();if(!file.exists()||!file.isFile()||file.length()>128L*1024L)return;FileInputStream in=null;try{in=new FileInputStream(file);Properties p=new Properties();p.load(in);for(Object k:p.keySet()){String key=String.valueOf(k),v=p.getProperty(key);if(key.length()<180&&( "true".equalsIgnoreCase(v)||"false".equalsIgnoreCase(v)))values.setProperty(key,v.toLowerCase(Locale.ROOT));}}catch(Exception ignored){values.clear();}finally{if(in!=null)try{in.close();}catch(Exception ignored){}}}
    public void save(){FileOutputStream out=null;try{File p=file.getParentFile();if(p!=null&&!p.exists())p.mkdirs();out=new FileOutputStream(file);values.store(out,"OmenaMod per-player gear label visibility");}catch(Exception ignored){}finally{if(out!=null)try{out.close();}catch(Exception ignored){}}}
    public boolean isShown(String list,String ign){String v=values.getProperty(key(list,ign));return v==null||Boolean.parseBoolean(v);} public void setShown(String list,String ign,boolean shown){values.setProperty(key(list,ign),Boolean.toString(shown));save();}
    private String key(String list,String ign){return "gear."+EnchantRegistry.id(list==null?"Blacklist":list)+"."+(ign==null?"unknown":ign.toLowerCase(Locale.ROOT));}
}
