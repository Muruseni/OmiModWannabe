package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;

/** Shared visual language for OmenaMod configuration screens. */
public final class OmenaUi {
    public static final int AQUA = 0xFF35D4E4;
    public static final int AQUA_DARK = 0xFF176979;
    public static final int GOLD = 0xFFFFCC55;
    public static final int PANEL = 0xE5141D26;
    public static final int PANEL_SOFT = 0xB818222D;
    public static final int PANEL_DARK = 0xE90C131A;
    public static final int BORDER = 0xFF30404D;

    private OmenaUi() {}

    public static void background(int width, int height) {
        Gui.func_73734_a(0, 0, width, height, 0xF20A0F15);
        Gui.func_73734_a(0, 0, width, 24, 0xF0121B24);
        Gui.func_73734_a(0, 0, width, 2, AQUA);
        Gui.func_73734_a(0, 2, Math.max(24, width / 5), 3, GOLD);
        Gui.func_73734_a(5, 5, width - 5, height - 5, 0x18000000);
        border(5, 5, width - 5, height - 5, 0x44384A58);
        Gui.func_73734_a(0, height - 18, width, height, 0x7A0D151D);
    }

    public static void panel(int left, int top, int right, int bottom) {
        if (right <= left || bottom <= top) return;
        Gui.func_73734_a(left + 2, top + 2, right + 2, bottom + 2, 0x66000000);
        Gui.func_73734_a(left, top, right, bottom, PANEL);
        border(left, top, right, bottom, BORDER);
        Gui.func_73734_a(left + 1, top + 1, right - 1, top + 2, 0x7735D4E4);
    }

    public static void softPanel(int left, int top, int right, int bottom) {
        if (right <= left || bottom <= top) return;
        Gui.func_73734_a(left, top, right, bottom, PANEL_SOFT);
        border(left, top, right, bottom, 0x6630404D);
    }

    public static void border(int left, int top, int right, int bottom, int color) {
        Gui.func_73734_a(left, top, right, top + 1, color);
        Gui.func_73734_a(left, bottom - 1, right, bottom, color);
        Gui.func_73734_a(left, top, left + 1, bottom, color);
        Gui.func_73734_a(right - 1, top, right, bottom, color);
    }

    public static void divider(int left, int right, int y) {
        Gui.func_73734_a(left, y, right, y + 1, 0x6635D4E4);
    }

    public static void centered(FontRenderer font, int width, String text, int y) {
        font.func_78276_b(text, (width - font.func_78256_a(text)) / 2, y, 0xFFFFFF);
    }

    public static void pageTitle(FontRenderer font, int width, String title, String subtitle, int y) {
        centered(font, width, "\u00A7b\u00A7l" + title, y);
        if (subtitle != null && !subtitle.isEmpty()) centered(font, width, "\u00A77" + subtitle, y + 15);
    }
}
