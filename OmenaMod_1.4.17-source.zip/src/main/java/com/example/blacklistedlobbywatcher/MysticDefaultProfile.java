package com.example.blacklistedlobbywatcher;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Developer-defined defaults used only by the Mystic Watcher target.
 * Named lists and Friendlist continue to use the catalogue defaults.
 */
public final class MysticDefaultProfile {
    private static final Set<String> DISPLAY = new HashSet<String>(Arrays.asList(
            // Pants
            key(EnchantRegistry.PANTS, "Singularity"),
            key(EnchantRegistry.PANTS, "Solitude"),
            key(EnchantRegistry.PANTS, "Double-Jump"),
            key(EnchantRegistry.PANTS, "Gotta go fast"),
            key(EnchantRegistry.PANTS, "Mirror"),

            // Swords
            key(EnchantRegistry.SWORDS, "Billionaire"),
            key(EnchantRegistry.SWORDS, "Combo: Perun's Wrath"),
            key(EnchantRegistry.SWORDS, "Gamble"),
            key(EnchantRegistry.SWORDS, "The Punch"),
            key(EnchantRegistry.SWORDS, "Lifesteal"),

            // Bows
            key(EnchantRegistry.BOWS, "Mega Longbow"),
            key(EnchantRegistry.BOWS, "Pullbow"),
            key(EnchantRegistry.BOWS, "Telebow"),
            key(EnchantRegistry.BOWS, "True Shot"),
            key(EnchantRegistry.BOWS, "Volley"),
            key(EnchantRegistry.BOWS, "Robinhood"),
            key(EnchantRegistry.BOWS, "Sweaty"),
            key(EnchantRegistry.BOWS, "Moctezuma"),

            // Darks
            key(EnchantRegistry.DARKS, "Nostalgia"),
            key(EnchantRegistry.DARKS, "Combo: Venom"),
            key(EnchantRegistry.DARKS, "Golden Handcuffs"),
            key(EnchantRegistry.DARKS, "Heartripper"),
            key(EnchantRegistry.DARKS, "Grim Reaper"),
            key(EnchantRegistry.DARKS, "Hedge Fund"),
            key(EnchantRegistry.DARKS, "Lycanthropy"),
            key(EnchantRegistry.DARKS, "Mind Assault"),
            key(EnchantRegistry.DARKS, "Misery"),
            key(EnchantRegistry.DARKS, "Needless Suffering"),
            key(EnchantRegistry.DARKS, "Sanguisuge"),
            key(EnchantRegistry.DARKS, "Spite")
    ));

    private static final Set<String> PING = new HashSet<String>(Arrays.asList(
            key(EnchantRegistry.PANTS, "Double-Jump"),
            key(EnchantRegistry.BOWS, "Robinhood"),
            key(EnchantRegistry.DARKS, "Combo: Venom")
    ));

    private static final Set<String> CHAT = new HashSet<String>(Arrays.asList(
            key(EnchantRegistry.DARKS, "Combo: Venom")
    ));

    private MysticDefaultProfile() { }

    public static boolean isMysticTarget(String target) {
        return target != null && "MysticWatcher".equalsIgnoreCase(target.trim());
    }

    public static boolean display(String category, String enchant) {
        return DISPLAY.contains(key(category, enchant));
    }

    public static boolean ping(String category, String enchant) {
        return PING.contains(key(category, enchant));
    }

    public static boolean chat(String category, String enchant) {
        return CHAT.contains(key(category, enchant));
    }

    /** Minecraft colour code used only as Mystic Watcher's default display colour. */
    public static String displayColour(String category, String enchant, String fallback) {
        if (enchant != null) {
            if ("Sweaty".equalsIgnoreCase(enchant.trim())) return "b";     // aqua
            if ("Moctezuma".equalsIgnoreCase(enchant.trim())) return "6"; // gold
        }
        return fallback;
    }

    private static String key(String category, String enchant) {
        String c = category == null ? "" : category.trim().toLowerCase(Locale.ROOT);
        String e = enchant == null ? "" : enchant.trim().toLowerCase(Locale.ROOT);
        return c + "\u0000" + e;
    }
}
