package com.example.blacklistedlobbywatcher;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(
        modid = BlacklistedLobbyWatcher.MODID,
        name = BlacklistedLobbyWatcher.NAME,
        version = BlacklistedLobbyWatcher.VERSION,
        clientSideOnly = true
)
public class BlacklistedLobbyWatcher {
    public static final String MODID = "blacklistedlobbywatcher";
    public static final String NAME = "OmenaMod";
    public static final String VERSION = "1.4.17";

    private static BlacklistManager blacklistManager;
    private static LobbyWatcher lobbyWatcher;
    private static FriendListManager friendListManager;
    private static FriendListWatcher friendListWatcher;
    private static boolean accessDenied;
    private static String deniedUsername = "";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        deniedUsername = AccessControl.getLocalUsername();
        accessDenied = AccessControl.isDenied(deniedUsername);
        if (accessDenied) {
            System.err.println("[OmenaMod] Access denied for " + deniedUsername + ".");
            return;
        }

        blacklistManager = new BlacklistManager(event.getModConfigurationDirectory());
        blacklistManager.load();
        friendListManager = new FriendListManager(event.getModConfigurationDirectory());
        friendListManager.load();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        if (accessDenied) {
            MinecraftForge.EVENT_BUS.register(new AccessDeniedNotifier(deniedUsername));
            return;
        }

        Minecraft mc = Minecraft.func_71410_x();
        lobbyWatcher = new LobbyWatcher(mc, blacklistManager);
        MinecraftForge.EVENT_BUS.register(lobbyWatcher);
        friendListWatcher = new FriendListWatcher(mc, friendListManager, lobbyWatcher.getIndependentHudPositionManager());
        MinecraftForge.EVENT_BUS.register(friendListWatcher);
        ClientCommandHandler.instance.func_71560_a(new BlacklistCommand(lobbyWatcher));
    }

    public static BlacklistManager getBlacklistManager() { return blacklistManager; }
    public static LobbyWatcher getLobbyWatcher() { return lobbyWatcher; }
    public static FriendListWatcher getFriendListWatcher() { return friendListWatcher; }
}
