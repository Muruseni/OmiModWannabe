package com.example.blacklistedlobbywatcher;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

/** Reads only equipment already synchronized to the client for loaded player entities. */
public final class GearInfoUtil {
    private static final int LEGGINGS_ARMOR_INDEX = 1;
    private static final int MAX_TOOLTIP_LINES = 48;
    private static final int MAX_LINE_CHARS = 80;
    private static final int MAX_ENCHANTS = 12;
    private static final Pattern PIT_ENCHANT_LINE = Pattern.compile("^.+\\s(?:I|II|III)$");

    private GearInfoUtil() { }

    public static GearData getLeggingsGear(Minecraft mc, UUID playerId) {
        ItemStack stack = getLeggingsStack(mc, playerId);
        return inspect(mc, stack, true);
    }

    public static GearData getHeldGear(Minecraft mc, UUID playerId) {
        ItemStack stack = getHeldStack(mc, playerId);
        return inspect(mc, stack, false);
    }

    public static List<String> getLeggingsEnchantLines(Minecraft mc, UUID playerId) { return getLeggingsGear(mc, playerId).enchants; }
    public static List<String> getHeldEnchantLines(Minecraft mc, UUID playerId) { return getHeldGear(mc, playerId).enchants; }

    private static ItemStack getLeggingsStack(Minecraft mc, UUID playerId) {
        if (mc == null || playerId == null || mc.field_71441_e == null || mc.field_71439_g == null) return null;
        try { EntityPlayer p=mc.field_71441_e.func_152378_a(playerId); return p==null?null:p.func_82169_q(LEGGINGS_ARMOR_INDEX); }
        catch (Throwable ignored) { return null; }
    }
    private static ItemStack getHeldStack(Minecraft mc, UUID playerId) {
        if (mc == null || playerId == null || mc.field_71441_e == null || mc.field_71439_g == null) return null;
        try { EntityPlayer p=mc.field_71441_e.func_152378_a(playerId); return p==null?null:p.func_70694_bm(); }
        catch (Throwable ignored) { return null; }
    }

    private static GearData inspect(Minecraft mc, ItemStack stack, boolean leggings) {
        if (stack == null || mc == null || mc.field_71439_g == null) return GearData.EMPTY;
        try {
            String title=sanitizeLine(stack.func_82833_r());
            boolean darkLeggings=leggings&&isDarkLeggingsTitle(title);
            String type=leggings?classifyLeggings(title):classifyHeld(title);

            // Prefer the synchronized display.Lore NBT directly. This avoids tooltip-generation
            // quirks where one lore line can transiently disappear while an equipment stack is
            // being updated. Tooltip parsing remains a bounded fallback for unusual stacks.
            List<String> rawLines=readLoreFromNbt(stack);
            if(rawLines.isEmpty()){
                List<String> tooltip=stack.func_82840_a(mc.field_71439_g,false);
                if(tooltip!=null)rawLines=tooltip;
            }

            List<String> enchants=new ArrayList<String>();
            int checked=0;
            for (String raw:rawLines) {
                if (++checked>MAX_TOOLTIP_LINES || enchants.size()>=MAX_ENCHANTS) break;
                String line=normalizeKnownEnchantLine(raw,darkLeggings);
                if (line!=null&&!containsIgnoreCase(enchants,line)) enchants.add(line);
            }
            StringBuilder sig=new StringBuilder(stripFormatting(type));
            for(String e:enchants) sig.append('|').append(canonicalKey(e));
            return new GearData(type,Collections.unmodifiableList(enchants),sig.toString());
        } catch(Throwable ignored){ return GearData.EMPTY; }
    }

    private static List<String> readLoreFromNbt(ItemStack stack){
        List<String> out=new ArrayList<String>();
        if(stack==null)return out;
        try{
            NBTTagCompound root=stack.func_77978_p();
            if(root==null||!root.func_150297_b("display",10))return out;
            NBTTagCompound display=root.func_74775_l("display");
            if(display==null||!display.func_150297_b("Lore",9))return out;
            NBTTagList lore=display.func_150295_c("Lore",8);
            if(lore==null)return out;
            int count=Math.min(MAX_TOOLTIP_LINES,lore.func_74745_c());
            for(int i=0;i<count;i++){
                String line=lore.func_150307_f(i);
                if(line!=null)out.add(line);
            }
        }catch(Throwable ignored){out.clear();}
        return out;
    }

    private static boolean containsIgnoreCase(List<String> lines,String wanted){
        for(String line:lines)if(line!=null&&line.equalsIgnoreCase(wanted))return true;
        return false;
    }

    private static String classifyLeggings(String title) {
        String l=title==null?"":title.toLowerCase(Locale.ROOT);
        if (!(l.contains("pants") || l.contains("leggings"))) return "";
        // Pit Classic Darks are titled like "Tier II Dark Pants". They are
        // intentionally not given a base HUD label; the Dark enchants themselves
        // are what Mystic Watcher displays.
        if (isDarkLeggingsTitle(title)) return "";
        if (l.contains("diamond")) return "\u00A7bDiamond";
        if (l.contains("chain")) return "\u00A77Chain";
        if (l.contains("iron")) return "\u00A7fIron";
        if (l.contains("gold")) return "\u00A76BHunter";
        return "";
    }
    private static boolean isDarkLeggingsTitle(String title) {
        String l=title==null?"":title.toLowerCase(Locale.ROOT);
        if (!(l.contains("pants") || l.contains("leggings"))) return false;
        // Primary live format is "Tier II Dark Pants". Keeping this slightly
        // tolerant handles colour codes/spacing already stripped by sanitizeLine.
        return l.contains("dark pants") || l.contains("dark leggings") ||
               (l.contains("dark") && l.contains("tier ii"));
    }
    private static String classifyHeld(String title) {
        String l=title==null?"":title.toLowerCase(Locale.ROOT).trim();
        if (l.contains("mystic bow")) return "\u00A7bMystic Bow";
        if (l.contains("mystic sword")) return "\u00A7eMystic Sword";
        return "";
    }

    /** Normalize server-provided lore to a known catalogue enchant + tier only. */
    private static String normalizeKnownEnchantLine(String raw,boolean darkLeggings){
        String clean=sanitizeLine(raw);
        if(clean.length()==0)return null;
        // Dark pants are explicitly identified by their title. Match the Darks
        // catalogue first so they cannot be lost to generic item/lore handling.
        if(darkLeggings){
            String dark=normalizeFromCategory(clean,EnchantRegistry.DARKS);
            if(dark!=null)return dark;
        }
        ParsedEnchant parsed=parseEnchantLine(clean);
        if(parsed==null)return null;
        String canonical=canonicalKnownEnchantName(parsed.name);
        if(canonical==null)return null;
        return canonical+" "+parsed.tier;
    }


    private static String canonicalKnownEnchantName(String rawName){
        String key=canonicalKey(rawName);
        if(key.length()==0)return null;
        for(String category:EnchantRegistry.categories()){
            for(String known:EnchantRegistry.enchantsFor(category)){
                if(canonicalKey(known).equals(key))return known;
            }
        }
        return null;
    }

    /** Comparison key only; output always uses the catalogue's canonical spelling. */
    private static String canonicalKey(String value){
        if(value==null)return "";
        String clean=sanitizeLine(value).toLowerCase(Locale.ROOT);
        StringBuilder out=new StringBuilder();
        for(int i=0;i<clean.length();i++){
            char c=clean.charAt(i);
            if((c>='a'&&c<='z')||(c>='0'&&c<='9'))out.append(c);
        }
        return out.toString();
    }

    private static String normalizeFromCategory(String clean,String category){
        String work=clean;
        if(work.regionMatches(true,0,"RARE!",0,5))work=work.substring(5).trim();
        for(String name:EnchantRegistry.enchantsFor(category)){
            for(String tier:new String[]{"III","II","I"}){
                String expected=name+" "+tier;
                if(work.equalsIgnoreCase(expected))return name+" "+tier;
            }
        }
        return null;
    }

    public static String findEnchantTierLine(List<String> lines, String enchantName) {
        if (lines==null || enchantName==null) return null;
        String wanted=enchantName.trim();
        for(String line:lines){
            ParsedEnchant parsed=parseEnchantLine(line);
            if(parsed==null)continue;
            if(parsed.name.equalsIgnoreCase(wanted))return wanted+" "+parsed.tier;
        }
        return null;
    }

    public static boolean matchesCriterion(List<String> lines, String criterion) {
        if (criterion==null || criterion.trim().isEmpty() || lines==null) return false;
        String c=criterion.trim();
        String[] t=c.split("\\s+");
        String last=t.length==0?"":t[t.length-1];
        if(isTier(last)){
            String wantedName=c.substring(0,c.length()-last.length()).trim();
            for(String line:lines){
                ParsedEnchant parsed=parseEnchantLine(line);
                if(parsed!=null&&parsed.name.equalsIgnoreCase(wantedName)&&parsed.tier.equals(last))return true;
            }
            return false;
        }
        return findEnchantTierLine(lines,c)!=null;
    }

    private static ParsedEnchant parseEnchantLine(String line){
        if(line==null)return null;
        String clean=sanitizeLine(line);
        String[] tokens=clean.split("\\s+");
        if(tokens.length<2)return null;
        String tier=tokens[tokens.length-1];
        if(!isTier(tier))return null;
        String base=clean.substring(0,clean.length()-tier.length()).trim();
        if(base.regionMatches(true,0,"RARE!",0,5)){
            base=base.substring(5).trim();
        }
        if(base.length()==0)return null;
        return new ParsedEnchant(base,tier);
    }

    private static final class ParsedEnchant{
        final String name,tier;
        ParsedEnchant(String name,String tier){this.name=name;this.tier=tier;}
    }

    private static boolean looksLikePitEnchant(String line) {
        if(line==null||line.isEmpty())return false;
        String lower=line.toLowerCase(Locale.ROOT);
        if(lower.startsWith("lives ")||lower.startsWith("as strong as "))return false;
        if(lower.contains("tier iii")&&(lower.contains(" pants")||lower.contains(" bow")||lower.contains(" sword")))return false;
        String[] tokens=line.split("\\s+");
        if(tokens.length<2||tokens.length>8)return false;
        return PIT_ENCHANT_LINE.matcher(line).matches();
    }
    private static boolean isTier(String t){return "I".equals(t)||"II".equals(t)||"III".equals(t);}

    public static String sanitizeLine(String raw) {
        if(raw==null)return "";
        StringBuilder out=new StringBuilder(); boolean formatting=false;
        for(int i=0;i<raw.length()&&out.length()<MAX_LINE_CHARS;i++){
            char c=raw.charAt(i);
            if(formatting){formatting=false;continue;}
            if(c=='\u00A7'){formatting=true;continue;}
            if(c>=32&&c!=127)out.append(c);
        }
        return out.toString().trim();
    }
    public static String stripFormatting(String raw){return sanitizeLine(raw);}

    public static final class GearData {
        public static final GearData EMPTY=new GearData("",Collections.<String>emptyList(),"");
        public final String typeLabel;
        public final List<String> enchants;
        public final String signature;
        GearData(String typeLabel,List<String>enchants,String signature){this.typeLabel=typeLabel==null?"":typeLabel;this.enchants=enchants==null?Collections.<String>emptyList():enchants;this.signature=signature==null?"":signature;}
        public boolean isEmpty(){return typeLabel.isEmpty()&&enchants.isEmpty();}
    }
}
