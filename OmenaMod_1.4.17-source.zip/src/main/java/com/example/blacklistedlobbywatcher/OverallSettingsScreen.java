package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

/** Overall OmenaMod settings: menu key and global sound-volume multiplier. */
public class OverallSettingsScreen extends GuiScreen {
    private static final int BACK = 0, KEY = 1, RESET = 2;
    private static final int SLIDER_W = 200, SLIDER_H = 12;
    private final GuiScreen parent;
    private final OverallSettingsManager settings;
    private boolean listeningForKey;
    private boolean draggingVolume;

    public OverallSettingsScreen(GuiScreen parent, LobbyWatcher watcher) {
        this.parent = parent;
        this.settings = watcher.getOverallSettingsManager();
    }

    @Override public void func_73866_w_() {
        int cx = field_146294_l / 2, top = Math.max(52, field_146295_m / 2 - 92);
        field_146292_n.add(new GuiButton(KEY, cx - 100, top, 200, 20, keyLabel()));
        field_146292_n.add(new GuiButton(RESET, cx - 100, top + 104, 95, 20, "Reset defaults"));
        field_146292_n.add(new GuiButton(BACK, cx + 5, top + 104, 95, 20, "Back"));
    }

    @Override public void func_73863_a(int mx, int my, float pt) {
        if (draggingVolume) updateVolume(mx);
        OmenaUi.background(field_146294_l,field_146295_m);
        int cx=field_146294_l/2, top=Math.max(52,field_146295_m/2-92);
        OmenaUi.panel(cx-116,top-42,cx+116,top+133);
        OmenaUi.pageTitle(field_146289_q,field_146294_l,"Overall Settings","Menu shortcut and master sound level.",top-31);
        OmenaUi.divider(cx-98,cx+98,top+27);
        field_146289_q.func_78276_b("\u00A7fOverall sound volume: \u00A7b"+settings.getMasterSoundPercent()+"%",cx-100,top+40,0xFFFFFF);
        slider(cx-100,top+62,settings.getMasterSoundPercent());
        center("\u00A7eMaster volume multiplies every OmenaMod sound.",top+79);
        center("\u00A77Example: 50% = half of each sound's own configured volume.",top+91);
        super.func_73863_a(mx,my,pt);
    }

    private void slider(int x,int y,int v){Gui.func_73734_a(x,y+4,x+SLIDER_W,y+8,0xFF555555);int f=Math.round(SLIDER_W*(v/100.0F));Gui.func_73734_a(x,y+4,x+f,y+8,0xFF33AADD);Gui.func_73734_a(x+f-3,y,x+f+3,y+SLIDER_H,0xFFFFFFFF);}
    @Override protected void func_73864_a(int mx,int my,int mb){if(mb==0){int cx=field_146294_l/2,top=Math.max(52,field_146295_m/2-92);if(inside(mx,my,cx-100,top+62)){draggingVolume=true;updateVolume(mx);return;}}super.func_73864_a(mx,my,mb);}
    @Override protected void func_146273_a(int mx,int my,int mb,long t){if(draggingVolume&&mb==0){updateVolume(mx);return;}super.func_146273_a(mx,my,mb,t);}
    @Override protected void func_146286_b(int mx,int my,int state){if(draggingVolume&&state==0){updateVolume(mx);draggingVolume=false;settings.save();return;}super.func_146286_b(mx,my,state);}

    @Override protected void func_146284_a(GuiButton b){
        if(b.field_146127_k==KEY){listeningForKey=true;b.field_146126_j="Press a key...";return;}
        if(b.field_146127_k==RESET){settings.setMenuKeyCode(Keyboard.KEY_N);settings.setMasterSoundPercent(100);settings.save();rebuild();return;}
        if(b.field_146127_k==BACK){settings.save();field_146297_k.func_147108_a(parent);}
    }
    @Override protected void func_73869_a(char typedChar,int keyCode){
        if(listeningForKey){
            if(keyCode==Keyboard.KEY_ESCAPE){listeningForKey=false;rebuild();return;}
            if(settings.setMenuKeyCode(keyCode)){listeningForKey=false;rebuild();}
            return;
        }
        super.func_73869_a(typedChar,keyCode);
    }
    @Override public void func_146281_b(){draggingVolume=false;settings.save();}
    private String keyLabel(){return listeningForKey?"Press a key...":"Menu key: "+settings.getMenuKeyName();}
    private boolean inside(int mx,int my,int x,int y){return mx>=x-4&&mx<=x+SLIDER_W+4&&my>=y-4&&my<=y+SLIDER_H+4;}
    private void updateVolume(int mx){int x=field_146294_l/2-100,c=Math.max(x,Math.min(x+SLIDER_W,mx));settings.setMasterSoundPercent(Math.round(((c-x)/(float)SLIDER_W)*100F));}
    private void rebuild(){field_146292_n.clear();func_73866_w_();}
    private void center(String s,int y){field_146289_q.func_78276_b(s,(field_146294_l-field_146289_q.func_78256_a(s))/2,y,0xFFFFFF);}
}
