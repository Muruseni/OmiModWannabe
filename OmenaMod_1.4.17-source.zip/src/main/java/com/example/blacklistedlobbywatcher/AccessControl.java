package com.example.blacklistedlobbywatcher;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Local-only access control for OmenaMod.
 *
 * The denylist is intentionally explicit and stored in source. It checks only
 * the username already present in Minecraft's local session and performs no
 * server, HTTP, API, or packet lookup.
 */
public final class AccessControl {
    private static final Set<String> DENIED_USERS = Collections.unmodifiableSet(
            new HashSet<String>(Arrays.<String>asList(
                    // Add lowercase IGNs here in future versions, for example:
                    // "exampleplayer"
            ))
    );

    private AccessControl() {}

    public static String getLocalUsername() {
        try {
            Minecraft mc = Minecraft.func_71410_x();
            if (mc == null) return "";
            Session session = mc.func_110432_I();
            if (session == null) return "";
            String username = session.func_111285_a();
            return username == null ? "" : username.trim();
        } catch (RuntimeException ignored) {
            return "";
        }
    }

    public static boolean isDenied(String username) {
        if (username == null) return false;
        String normalized = username.trim().toLowerCase(Locale.ROOT);
        return !normalized.isEmpty() && DENIED_USERS.contains(normalized);
    }
}
