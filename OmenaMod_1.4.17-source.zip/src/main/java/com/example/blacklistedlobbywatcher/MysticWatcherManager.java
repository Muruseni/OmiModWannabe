package com.example.blacklistedlobbywatcher;

import java.io.*;
import java.util.Locale;
import java.util.Properties;

public class MysticWatcherManager {
    private final File file; private final Properties p=new Properties();
    public MysticWatcherManager(File dir){file=new File(dir,"omenamod_mystic_watcher.properties");}
    public void load(){p.clear();if(!file.exists()||!file.isFile()||file.length()>128L*1024L)return;FileInputStream in=null;try{in=new FileInputStream(file);p.load(in);}catch(Exception ignored){p.clear();}finally{if(in!=null)try{in.close();}catch(Exception ignored){}}}
    public void save(){FileOutputStream out=null;try{File d=file.getParentFile();if(d!=null&&!d.exists())d.mkdirs();out=new FileOutputStream(file);p.store(out,"OmenaMod Mystic Watcher settings");}catch(Exception ignored){}finally{if(out!=null)try{out.close();}catch(Exception ignored){}}}
    public boolean isHudEnabled(){return bool("hud",false);} public void setHudEnabled(boolean v){p.setProperty("hud",Boolean.toString(v));save();}
    public boolean isOmitted(String list){return bool("omit."+EnchantRegistry.id(list),false);} public void setOmitted(String list,boolean v){p.setProperty("omit."+EnchantRegistry.id(list),Boolean.toString(v));save();}
    private boolean bool(String k,boolean d){String v=p.getProperty(k);if("true".equalsIgnoreCase(v))return true;if("false".equalsIgnoreCase(v))return false;return d;}
}
