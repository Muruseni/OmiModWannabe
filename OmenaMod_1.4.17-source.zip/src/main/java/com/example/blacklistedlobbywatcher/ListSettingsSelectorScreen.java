package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.util.ArrayList;
import java.util.List;

/** First step of Blacklist Settings: choose which list owns the settings being edited. */
public class ListSettingsSelectorScreen extends GuiScreen {
    private static final int BUTTON_BACK = 0;
    private static final int BUTTON_LIST_BASE = 100;

    private final GuiScreen parent;
    private final LobbyWatcher watcher;

    public ListSettingsSelectorScreen(GuiScreen parent, LobbyWatcher watcher) {
        this.parent = parent;
        this.watcher = watcher;
    }

    @Override
    public void func_73866_w_() {
        int cx = this.field_146294_l / 2;
        int y = Math.max(58, this.field_146295_m / 2 - 75);
        List<String> targets = targets();
        for (int i = 0; i < targets.size(); i++) {
            String name = targets.get(i);
            this.field_146292_n.add(new GuiButton(BUTTON_LIST_BASE + i, cx - 100, y + i * 25, 200, 20, name));
        }
        int backY = Math.min(this.field_146295_m - 28, y + targets.size() * 25 + 10);
        this.field_146292_n.add(new GuiButton(BUTTON_BACK, cx - 100, backY, 200, 20, "Back"));
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        OmenaUi.background(this.field_146294_l,this.field_146295_m);
        int cx=this.field_146294_l/2; int y=Math.max(58,this.field_146295_m/2-75); int count=targets().size();
        int bottom=Math.min(this.field_146295_m-18,y+count*25+42);
        OmenaUi.panel(cx-116,14,cx+116,bottom);
        OmenaUi.pageTitle(this.field_146289_q,this.field_146294_l,"Choose List","Select which list you want to configure.",24);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == BUTTON_BACK) {
            this.field_146297_k.func_147108_a(parent);
            return;
        }
        int index = button.field_146127_k - BUTTON_LIST_BASE;
        List<String> targets = targets();
        if (index >= 0 && index < targets.size()) {
            this.field_146297_k.func_147108_a(new SettingsScreen(this, watcher, targets.get(index)));
        }
    }

    private List<String> targets() {
        List<String> out = new ArrayList<String>();
        out.add("Blacklist");
        out.addAll(watcher.getAdditionalListManager().getListNames());
        return out;
    }

    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
