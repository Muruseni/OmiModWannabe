package com.example.blacklistedlobbywatcher;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class LobbyWatcher {
    private static final int STATUS_UNKNOWN = 0;
    private static final int STATUS_EMPTY_BLACKLIST = 1;
    private static final int STATUS_EMPTY_LOBBY = 2;
    private static final int STATUS_CLEAR = 3;
    private static final int STATUS_DETECTED = 4;
    private static final int STATUS_DELAY_CHECKS = 8;

    /** Defensive limits for data originating from a multiplayer server. */
    private static final int MAX_TAB_PLAYERS_SCANNED = 1000;
    private static final int MAX_TAB_TEXT_CHARS = 128;
    private static final int MAX_HUD_ENTRIES = 32;
    private static final int MAX_COMMAND_LIST_ENTRIES = 20;
    private static final int MAX_STATUS_MATCHES = 32;
    private static final int MAX_CHAT_MESSAGE_CHARS = 512;

    private final Minecraft mc;
    private final BlacklistManager blacklistManager;
    private final HudPositionManager hudPositionManager;
    private final IndependentHudPositionManager independentHudPositionManager;
    private final FeatureSettingsManager featureSettingsManager;
    private final SoundSettingsManager soundSettingsManager;
    private final OverallSettingsManager overallSettingsManager;
    private final AdditionalListManager additionalListManager;
    private final ColourSettingsManager colourSettingsManager;
    private final EnchantSettingsManager enchantSettingsManager;
    private final PlayerGearDisplayManager playerGearDisplayManager;
    private final AlertThrottleManager alertThrottleManager;
    private final MysticWatcherManager mysticWatcherManager;
    private final CustomItemRuleManager customItemRuleManager;
    private final MysticWatcher mysticWatcher;
    /** UUID -> sanitized formatted TAB-list text, including server prefix/suffix/color codes. */
    private final Map<UUID, String> detectedPlayers = new LinkedHashMap<UUID, String>();
    /** UUID -> profile name; only presence is used to avoid repeated alerts. */
    private final Map<UUID, String> previousPlayers = new LinkedHashMap<UUID, String>();
    /** Per-extra-list UUID -> formatted TAB text. Extra lists are HUD-only for now. */
    private final Map<String, Map<UUID, String>> detectedAdditionalPlayers = new LinkedHashMap<String, Map<UUID, String>>();
    /** Client-only per-enchant alert presence, kept separate from list detection. */
    private final Map<String, ItemPresence> activeItemMatches = new LinkedHashMap<String, ItemPresence>();
    private int tickCounter;
    private int connectedChecks;
    private int lastStatus = STATUS_UNKNOWN;
    private int lastLobbyPlayerCount = -1;
    private boolean menuKeyWasDown;
    private boolean welcomeShownForConnection;
    /** Used only to recognize genuine world/lobby changes so alerts can fire again in a new lobby. */
    private WorldClient lastWorld;

    public LobbyWatcher(Minecraft mc, BlacklistManager blacklistManager) {
        this.mc = mc;
        this.blacklistManager = blacklistManager;
        this.hudPositionManager = new HudPositionManager(blacklistManager.getConfigDirectory());
        this.hudPositionManager.load();
        this.independentHudPositionManager = new IndependentHudPositionManager(blacklistManager.getConfigDirectory());
        this.independentHudPositionManager.load();
        this.featureSettingsManager = new FeatureSettingsManager(blacklistManager.getConfigDirectory());
        this.featureSettingsManager.load();
        this.soundSettingsManager = new SoundSettingsManager(blacklistManager.getConfigDirectory());
        this.soundSettingsManager.load();
        this.overallSettingsManager = new OverallSettingsManager(blacklistManager.getConfigDirectory());
        this.overallSettingsManager.load();
        this.additionalListManager = new AdditionalListManager(blacklistManager.getConfigDirectory());
        this.additionalListManager.load();
        this.colourSettingsManager = new ColourSettingsManager(blacklistManager.getConfigDirectory());
        this.colourSettingsManager.load();
        this.enchantSettingsManager = new EnchantSettingsManager(blacklistManager.getConfigDirectory());
        this.enchantSettingsManager.load();
        this.playerGearDisplayManager = new PlayerGearDisplayManager(blacklistManager.getConfigDirectory());
        this.playerGearDisplayManager.load();
        this.alertThrottleManager = new AlertThrottleManager(blacklistManager.getConfigDirectory());
        this.alertThrottleManager.load();
        this.mysticWatcherManager = new MysticWatcherManager(blacklistManager.getConfigDirectory());
        this.mysticWatcherManager.load();
        this.customItemRuleManager = new CustomItemRuleManager(blacklistManager.getConfigDirectory());
        this.customItemRuleManager.load();
        this.mysticWatcher = new MysticWatcher(mc, blacklistManager, additionalListManager, mysticWatcherManager, enchantSettingsManager, customItemRuleManager, alertThrottleManager);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event == null || event.phase != TickEvent.Phase.END) return;

        handleMenuKey();

        if (++tickCounter < 5) return;
        tickCounter = 0;

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            resetConnectionState();
            return;
        }

        // A fresh WorldClient is a strong client-side signal that we entered a new lobby/world.
        // Reset only the alert-presence state so blacklisted players can ping again in the new lobby.
        if (mc.field_71441_e != lastWorld) {
            beginNewLobby(mc.field_71441_e);
        }

        connectedChecks++;
        maybeShowWelcome();

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        lastLobbyPlayerCount = playerInfo == null ? 0 : playerInfo.size();

        Map<UUID, String> currentBlacklisted = new LinkedHashMap<UUID, String>();
        Map<UUID, String> currentProfileNames = new LinkedHashMap<UUID, String>();
        Map<String, Map<UUID, String>> currentAdditional = new LinkedHashMap<String, Map<UUID, String>>();
        List<String> additionalNames = additionalListManager.getListNames();
        for (String listName : additionalNames) {
            currentAdditional.put(listName, new LinkedHashMap<UUID, String>());
        }

        if (playerInfo == null || playerInfo.isEmpty()) {
            detectedPlayers.clear();
            previousPlayers.clear();
            detectedAdditionalPlayers.clear();
            activeItemMatches.clear();
            announceStatus(STATUS_EMPTY_LOBBY,
                    "\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        int scanned = 0;
        for (NetworkPlayerInfo info : playerInfo) {
            if (++scanned > MAX_TAB_PLAYERS_SCANNED) break;
            if (info == null) continue;

            GameProfile profile;
            try {
                profile = info.func_178845_a();
            } catch (RuntimeException ignored) {
                continue;
            }
            if (profile == null) continue;

            UUID uuid = profile.getId();
            String name = profile.getName();
            if (uuid == null || !BlacklistManager.isValidPlayerName(name)) continue;

            String tabText = null;
            if (blacklistManager.contains(name)) {
                tabText = getFormattedTabText(info, profile);
                currentBlacklisted.put(uuid, tabText);
                currentProfileNames.put(uuid, name);
                if (!previousPlayers.containsKey(uuid)) alert(tabText);
            }

            for (String listName : additionalNames) {
                if (additionalListManager.containsPlayer(listName, name)) {
                    if (tabText == null) tabText = getFormattedTabText(info, profile);
                    currentAdditional.get(listName).put(uuid, tabText);
                }
            }
        }

        // Player-made lists have fully independent local alert settings. They default quiet (all alert toggles OFF).
        for (String listName : additionalNames) {
            Map<UUID, String> oldMap = detectedAdditionalPlayers.get(listName);
            if (oldMap == null) oldMap = Collections.emptyMap();
            Map<UUID, String> newMap = currentAdditional.get(listName);
            if (newMap == null) newMap = Collections.emptyMap();

            for (Map.Entry<UUID, String> entry : newMap.entrySet()) {
                if (!oldMap.containsKey(entry.getKey())) {
                    if (featureSettingsManager.isJoinPingEnabled(listName) && alertThrottleManager.allowPing(listName, "listjoin|" + entry.getKey(), false)) {
                        playPing(soundSettingsManager.getJoinSound(listName), 1.35F, soundSettingsManager.getJoinVolumeFloat(listName));
                    }
                    if (featureSettingsManager.isJoinChatEnabled(listName)) {
                        alertAdditionalJoined(listName, entry.getValue());
                    }
                }
            }

            for (Map.Entry<UUID, String> entry : oldMap.entrySet()) {
                if (!newMap.containsKey(entry.getKey()) && containsAdditionalDisplayName(listName, entry.getValue())) {
                    if (featureSettingsManager.isLeavePingEnabled(listName) && alertThrottleManager.allowPing(listName, "listleave|" + entry.getKey(), false)) {
                        playPing(soundSettingsManager.getLeaveSound(listName), 0.65F, soundSettingsManager.getLeaveVolumeFloat(listName));
                    }
                    if (featureSettingsManager.isLeaveChatEnabled(listName)) {
                        alertAdditionalLeft(listName, entry.getValue());
                    }
                }
            }
        }

        // Per-enchant local alerts are scoped to the containing list. They inspect only already-loaded client equipment.
        processEnchantAlertsForTarget("Blacklist", currentBlacklisted);
        for (String listName : additionalNames) {
            Map<UUID, String> targetPlayers = currentAdditional.get(listName);
            if (targetPlayers == null) targetPlayers = Collections.emptyMap();
            processEnchantAlertsForTarget(listName, targetPlayers);
        }
        mysticWatcher.tick(playerInfo);

        // Players that were blacklisted in the previous scan but are no longer in TAB have left.
        // Do not announce a removal caused by the user taking someone off the blacklist.
        for (Map.Entry<UUID, String> previous : previousPlayers.entrySet()) {
            UUID uuid = previous.getKey();
            String profileName = previous.getValue();
            if (!currentProfileNames.containsKey(uuid) && blacklistManager.contains(profileName)) {
                String oldTabText = detectedPlayers.get(uuid);
                alertLeft(oldTabText == null ? profileName : oldTabText);
            }
        }

        detectedPlayers.clear();
        detectedPlayers.putAll(currentBlacklisted);
        previousPlayers.clear();
        previousPlayers.putAll(currentProfileNames);
        detectedAdditionalPlayers.clear();
        detectedAdditionalPlayers.putAll(currentAdditional);

        if (blacklistManager.isEmpty()) {
            announceStatus(STATUS_EMPTY_BLACKLIST,
                    "\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
        } else if (currentBlacklisted.isEmpty()) {
            announceStatus(STATUS_CLEAR,
                    "\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
        } else {
            lastStatus = STATUS_DETECTED;
        }
    }

    private void handleMenuKey() {
        int menuKey = overallSettingsManager == null ? Keyboard.KEY_N : overallSettingsManager.getMenuKeyCode();
        boolean down = Keyboard.isKeyDown(menuKey);
        if (down && !menuKeyWasDown && mc.field_71439_g != null && mc.field_71462_r == null) openMenu();
        menuKeyWasDown = down;
    }

    public void openMenu() {
        if (mc.field_71439_g != null) mc.func_147108_a(new BlacklistedLobbyMenu(blacklistManager, this));
    }

    private void maybeShowWelcome() {
        if (welcomeShownForConnection || mc.field_71439_g == null || mc.func_147114_u() == null) return;
        welcomeShownForConnection = true;
        String key = overallSettingsManager == null ? "N" : overallSettingsManager.getMenuKeyName();
        chat("\u00A7b\u00A7lThank you for using OmenaMod!");
        chat("\u00A7ePress \u00A7b" + key + " \u00A7eto open the menu \u00A77OR \u00A7etype \u00A7b/omenamod <Key> \u00A7eto change the keybind.");
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
        if (mc.field_71439_g == null || mc.field_71466_p == null) return;
        if (mc.field_71462_r instanceof BlacklistedLobbyMenu) return;
        drawEnabledHuds(mc.field_71466_p);
    }

    /** Draws every list HUD preview in the N menu. */
    public void drawAllHudPreviews(FontRenderer font) { drawAllHudPreviews(font, null); }
    public void drawAllHudPreviews(FontRenderer font, String selectedKey) {
        if (font == null) return;
        try {
            drawHudBox(font, getHudLines(), hudPositionManager.getX(), hudPositionManager.getY(), getHudScale("blacklist"), "blacklist".equals(selectedKey));
            List<String> names = additionalListManager.getListNames();
            for (int i = 0; i < names.size(); i++) {
                String listName = names.get(i);
                ensureAdditionalHudPosition(listName, i);
                String key = extraHudKey(listName);
                drawHudBox(font, getAdditionalHudLines(listName), independentHudPositionManager.getX(key, 7),
                        independentHudPositionManager.getY(key, 60 + i * 45), getHudScale(key), key.equals(selectedKey));
            }
            ensureMysticHudPosition();
            drawHudBox(font, mysticWatcher.hudLines(font), independentHudPositionManager.getX("mystic", 390),
                    independentHudPositionManager.getY("mystic", 7), getHudScale("mystic"), "mystic".equals(selectedKey));
        } catch (Throwable ignored) { }
    }

    /** Backward-compatible primary preview helper. */
    public void drawHud(FontRenderer font) {
        if (font == null) return;
        drawHudBox(font, getHudLines(), hudPositionManager.getX(), hudPositionManager.getY(), getHudScale("blacklist"), false);
    }

    private void drawEnabledHuds(FontRenderer font) {
        if (font == null) return;
        try {
            if (hudPositionManager.isHudEnabled()) drawHudBox(font, getHudLines(), hudPositionManager.getX(), hudPositionManager.getY(), getHudScale("blacklist"), false);
            List<String> names = additionalListManager.getListNames();
            for (int i = 0; i < names.size(); i++) {
                String listName = names.get(i);
                if (!additionalListManager.isHudEnabled(listName)) continue;
                ensureAdditionalHudPosition(listName, i);
                String key = extraHudKey(listName);
                drawHudBox(font, getAdditionalHudLines(listName), independentHudPositionManager.getX(key, 7),
                        independentHudPositionManager.getY(key, 60 + i * 45), getHudScale(key), false);
            }
            if (mysticWatcherManager.isHudEnabled()) {
                ensureMysticHudPosition();
                drawHudBox(font, mysticWatcher.hudLines(font), independentHudPositionManager.getX("mystic", 390),
                        independentHudPositionManager.getY("mystic", 7), getHudScale("mystic"), false);
            }
        } catch (Throwable ignored) { }
    }

    private void drawHudBox(FontRenderer font, List<String> lines, int x, int y, float scale, boolean selected) {
        scale = clampHudScale(scale);
        int width = getHudContentWidth(font, lines), height = getHudHeight(lines);
        int left = Math.round(x - 4F * scale), top = Math.round(y - 4F * scale);
        int right = Math.round(x + (width + 5F) * scale), bottom = Math.round(y + height * scale);
        Gui.func_73734_a(left, top, right, bottom, 0x90000000);
        if (selected) drawSelectionBorder(left, top, right, bottom);
        GL11.glPushMatrix();
        try {
            GL11.glTranslatef((float)x, (float)y, 0F);
            GL11.glScalef(scale, scale, 1F);
            for (int i = 0; i < lines.size(); i++) font.func_78276_b(lines.get(i), 0, i * 10, 0xFFFFFF);
        } finally { GL11.glPopMatrix(); }
    }

    private void drawSelectionBorder(int left,int top,int right,int bottom){
        int c=0xFF55FFFF;
        Gui.func_73734_a(left,top,right,top+1,c); Gui.func_73734_a(left,bottom-1,right,bottom,c);
        Gui.func_73734_a(left,top,left+1,bottom,c); Gui.func_73734_a(right-1,top,right,bottom,c);
        // small corner handles make resizing discoverable without covering the HUD.
        Gui.func_73734_a(right-3,bottom-3,right+1,bottom+1,c);
    }

    private String extraHudKey(String listName) { return "list:" + (listName == null ? "" : listName.toLowerCase(Locale.ROOT)); }
    private void ensureAdditionalHudPosition(String listName, int index) {
        String key = extraHudKey(listName); if (independentHudPositionManager.hasPosition(key)) return;
        independentHudPositionManager.setPosition(key, 7 + (index % 2) * 190, 60 + (index / 2) * 70);
    }
    private void ensureMysticHudPosition() { if (!independentHudPositionManager.hasPosition("mystic")) independentHudPositionManager.setPosition("mystic", 390, 7); }

    private List<String> getHudLinesForKey(String key, FontRenderer font) {
        if (key == null || "blacklist".equals(key)) return getHudLines();
        if (key.startsWith("list:")) { String wanted=key.substring(5); for(String listName:additionalListManager.getListNames()) if(listName.equalsIgnoreCase(wanted)) return getAdditionalHudLines(listName); }
        if ("mystic".equals(key)) return mysticWatcher.hudLines(font);
        return getHudLines();
    }

    public String findHudAtPoint(FontRenderer font, int mouseX, int mouseY) {
        if (font == null) return null;
        try {
            List<String> names = additionalListManager.getListNames();
            for (int i = names.size() - 1; i >= 0; i--) {
                String listName=names.get(i); ensureAdditionalHudPosition(listName,i); String key=extraHudKey(listName);
                if (isInside(font,getAdditionalHudLines(listName),independentHudPositionManager.getX(key,7),independentHudPositionManager.getY(key,60+i*45),getHudScale(key),mouseX,mouseY)) return key;
            }
            ensureMysticHudPosition();
            if (isInside(font,mysticWatcher.hudLines(font),independentHudPositionManager.getX("mystic",390),independentHudPositionManager.getY("mystic",7),getHudScale("mystic"),mouseX,mouseY)) return "mystic";
            if (isInside(font,getHudLines(),hudPositionManager.getX(),hudPositionManager.getY(),getHudScale("blacklist"),mouseX,mouseY)) return "blacklist";
        } catch (Throwable ignored) { }
        return null;
    }

    private boolean isInside(FontRenderer font,List<String> lines,int x,int y,float scale,int mx,int my){int[]b=bounds(font,lines,x,y,scale);return mx>=b[0]&&mx<=b[2]&&my>=b[1]&&my<=b[3];}
    private int[] bounds(FontRenderer font,List<String> lines,int x,int y,float scale){scale=clampHudScale(scale);int width=getHudContentWidth(font,lines),height=getHudHeight(lines);return new int[]{Math.round(x-4F*scale),Math.round(y-4F*scale),Math.round(x+(width+5F)*scale),Math.round(y+height*scale)};}
    public int[] getHudBounds(FontRenderer font,String key){try{return bounds(font,getHudLinesForKey(key,font),getHudX(key),getHudY(key),getHudScale(key));}catch(Throwable ignored){return new int[]{0,0,0,0};}}
    /** bitmask: 1 left, 2 right, 4 top, 8 bottom */
    public int getHudResizeEdge(FontRenderer font,String key,int mx,int my){int[]b=getHudBounds(font,key);int pad=5,edge=0;if(my>=b[1]-pad&&my<=b[3]+pad){if(Math.abs(mx-b[0])<=pad)edge|=1;if(Math.abs(mx-b[2])<=pad)edge|=2;}if(mx>=b[0]-pad&&mx<=b[2]+pad){if(Math.abs(my-b[1])<=pad)edge|=4;if(Math.abs(my-b[3])<=pad)edge|=8;}return edge;}

    public int getHudX(String key) { return key==null||"blacklist".equals(key)?hudPositionManager.getX():independentHudPositionManager.getX(key,7); }
    public int getHudY(String key) { return key==null||"blacklist".equals(key)?hudPositionManager.getY():independentHudPositionManager.getY(key,7); }
    public float getHudScale(String key){return independentHudPositionManager.getScale(key==null?"blacklist":key);}
    public void setHudScale(String key,float scale){independentHudPositionManager.setScale(key==null?"blacklist":key,clampHudScale(scale));}
    private float clampHudScale(float scale){return Math.max(independentHudPositionManager.minScale(),Math.min(independentHudPositionManager.maxScale(),scale));}

    public void setHudPositionClamped(String key,int x,int y,int screenWidth,int screenHeight,FontRenderer font){
        if(font==null)return;try{List<String>lines=getHudLinesForKey(key,font);float scale=getHudScale(key);int width=Math.round((getHudContentWidth(font,lines)+9)*scale),height=Math.round((getHudHeight(lines)+4)*scale);int pad=Math.round(4*scale);int minX=pad,minY=pad;int maxX=Math.max(minX,screenWidth-width+pad),maxY=Math.max(minY,screenHeight-height+pad);int cx=Math.max(minX,Math.min(maxX,x)),cy=Math.max(minY,Math.min(maxY,y));if(key==null||"blacklist".equals(key))hudPositionManager.setPosition(cx,cy);else independentHudPositionManager.setPosition(key,cx,cy);}catch(Throwable ignored){}
    }

    public void clampAllHudsToScreen(int screenWidth,int screenHeight,FontRenderer font){
        setHudPositionClamped("blacklist",hudPositionManager.getX(),hudPositionManager.getY(),screenWidth,screenHeight,font);
        List<String>names=additionalListManager.getListNames();for(int i=0;i<names.size();i++){String n=names.get(i);ensureAdditionalHudPosition(n,i);String k=extraHudKey(n);setHudPositionClamped(k,independentHudPositionManager.getX(k,7),independentHudPositionManager.getY(k,60+i*45),screenWidth,screenHeight,font);}ensureMysticHudPosition();setHudPositionClamped("mystic",independentHudPositionManager.getX("mystic",390),independentHudPositionManager.getY("mystic",7),screenWidth,screenHeight,font);
    }

    public void saveHudPosition(){hudPositionManager.save();independentHudPositionManager.save();}
    public IndependentHudPositionManager getIndependentHudPositionManager(){return independentHudPositionManager;}

    public boolean isHudEnabled() { return hudPositionManager.isHudEnabled(); }

    public void setHudEnabled(boolean enabled) {
        hudPositionManager.setHudEnabled(enabled);
        hudPositionManager.save();
    }

    public int getHudX() { return hudPositionManager.getX(); }
    public int getHudY() { return hudPositionManager.getY(); }

    private List<String> getHudLines() {
        List<String> lines = new ArrayList<String>();
        lines.add("\u00A7c\u00A7lBlacklisted in Lobby \u00A77(" + detectedPlayers.size() + ")");

        if (blacklistManager.isEmpty()) {
            lines.add("\u00A7eNo players on blacklist");
        } else if (mc.func_147114_u() == null) {
            lines.add("\u00A77Not connected");
        } else if (lastLobbyPlayerCount == 0) {
            lines.add("\u00A7eNo players listed in lobby");
        } else if (detectedPlayers.isEmpty()) {
            lines.add("\u00A7aNone");
        } else {
            lines.add("\u00A7cBlacklist            \u00A7bWearing                  \u00A76Holding");
            int shown = 0;
            for (Map.Entry<UUID, String> entry : detectedPlayers.entrySet()) {
                if (shown >= MAX_HUD_ENTRIES) break;
                lines.addAll(formatGearHudRows("Blacklist", entry.getValue(), entry.getKey()));
                lines.add("§8------------------------------------------------------------------------");
                shown++;
            }
            int hidden = detectedPlayers.size() - shown;
            if (hidden > 0) {
                lines.add("\u00A77... and " + hidden + " more");
            }
        }
        return lines;
    }


    private List<String> getAdditionalHudLines(String listName) {
        List<String> lines = new ArrayList<String>();
        Map<UUID, String> detected = detectedAdditionalPlayers.get(listName);
        int detectedCount = detected == null ? 0 : detected.size();
        lines.add("\u00A7c\u00A7l" + listName + " in Lobby \u00A77(" + detectedCount + ")");
        if (additionalListManager.size(listName) == 0) {
            lines.add("\u00A7eNo players on list");
        } else if (mc.func_147114_u() == null) {
            lines.add("\u00A77Not connected");
        } else if (lastLobbyPlayerCount == 0) {
            lines.add("\u00A7eNo players listed in lobby");
        } else if (detected == null || detected.isEmpty()) {
            lines.add("\u00A7aNone");
        } else {
            lines.add("\u00A7c" + listName + "            \u00A7bWearing                  \u00A76Holding");
            int shown = 0;
            for (Map.Entry<UUID, String> entry : detected.entrySet()) {
                if (shown >= MAX_HUD_ENTRIES) break;
                lines.addAll(formatGearHudRows(listName, entry.getValue(), entry.getKey()));
                lines.add("§8------------------------------------------------------------------------");
                shown++;
            }
            int hidden = detected.size() - shown;
            if (hidden > 0) lines.add("\u00A77... and " + hidden + " more");
        }
        return lines;
    }


    private List<String> formatGearHudRows(String listName, String playerText, UUID uuid) {
        List<String> out = new ArrayList<String>();
        GearInfoUtil.GearData pants = GearInfoUtil.getLeggingsGear(mc, uuid);
        GearInfoUtil.GearData held = GearInfoUtil.getHeldGear(mc, uuid);
        List<String> wearing = new ArrayList<String>();
        List<String> holding = new ArrayList<String>();
        String ign = extractIgn(playerText);
        if (playerGearDisplayManager.isShown(listName, ign)) {
            if (pants.typeLabel != null && !pants.typeLabel.isEmpty()) wearing.add(pants.typeLabel);
            if (held.typeLabel != null && !held.typeLabel.isEmpty()) holding.add(held.typeLabel);
        }
        addEnabledEnchants(wearing, listName, EnchantRegistry.PANTS, pants.enchants);
        addEnabledEnchants(wearing, listName, EnchantRegistry.DARKS, pants.enchants);
        addEnabledEnchants(holding, listName, EnchantRegistry.SWORDS, held.enchants);
        addEnabledEnchants(holding, listName, EnchantRegistry.BOWS, held.enchants);
        int rows = Math.max(1, Math.max(wearing.size(), holding.size()));
        for (int i = 0; i < rows; i++) {
            String name = i == (rows - 1) / 2 ? playerText : "";
            String wear = i < wearing.size() ? wearing.get(i) : "";
            String hand = i < holding.size() ? holding.get(i) : "";
            out.add(padHud(name, 20) + padHud(wear, 25) + hand);
        }
        return out;
    }

    private void addEnabledEnchants(List<String> out, String target, String category, List<String> lines) {
        for (String enchant : EnchantRegistry.enchantsFor(category)) {
            if (!enchantSettingsManager.isDisplayEnabled(target, category, enchant)) continue;
            String matched = GearInfoUtil.findEnchantTierLine(lines, enchant);
            if (matched == null) continue;
            EnchantRegistry.Definition d = EnchantRegistry.definition(category, enchant);
            String prefix = d != null && d.rare ? "§dRARE! " : "";
            out.add(prefix + "§" + enchantSettingsManager.getDisplayColour(target, category, enchant) + matched);
        }
    }

    private String padHud(String value, int visibleChars) {
        if (value == null) value = "";
        String plain = GearInfoUtil.stripFormatting(value);
        StringBuilder b = new StringBuilder(value);
        while (plain.length() < visibleChars) { b.append(' '); plain += " "; }
        return b.toString();
    }

    private String extractIgn(String display) {
        String plain = GearInfoUtil.stripFormatting(display);
        String[] parts = plain.split("\\s+");
        for (int i = parts.length - 1; i >= 0; i--) if (BlacklistManager.isValidPlayerName(parts[i])) return parts[i];
        return plain;
    }

    private int getHudContentWidth(FontRenderer font, List<String> lines) {
        int width = 0;
        for (String line : lines) {
            width = Math.max(width, font.func_78256_a(line));
        }
        return width;
    }

    private int getHudHeight(List<String> lines) {
        return lines.size() * 10 + 5;
    }

    private String getFormattedTabText(NetworkPlayerInfo info, GameProfile profile) {
        String fallback = profile == null ? "Unknown" : profile.getName();
        if (!BlacklistManager.isValidPlayerName(fallback)) fallback = "Unknown";

        try {
            IChatComponent displayName = info.func_178854_k();
            if (displayName != null) {
                String formatted = displayName.func_150254_d();
                if (formatted != null && !formatted.isEmpty()) {
                    return sanitizeServerText(formatted, fallback);
                }
            }
        } catch (RuntimeException ignored) { }

        try {
            ScorePlayerTeam team = info.func_178850_i();
            return sanitizeServerText(ScorePlayerTeam.func_96667_a(team, fallback), fallback);
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    /** Keeps normal Minecraft formatting codes but removes control characters/newlines and caps length. */
    private String sanitizeServerText(String input, String fallback) {
        if (input == null || input.isEmpty()) return fallback;
        StringBuilder out = new StringBuilder(Math.min(input.length(), MAX_TAB_TEXT_CHARS));
        for (int i = 0; i < input.length() && out.length() < MAX_TAB_TEXT_CHARS; i++) {
            char c = input.charAt(i);
            if (c < 32 || c == 127) continue;
            out.append(c);
        }
        if (out.length() == 0) return fallback;
        return out.toString();
    }

    public void handleCommand(String[] args) {
        if (args == null || args.length == 0) {
            openMenu();
            return;
        }

        String action = args[0].toLowerCase(Locale.ROOT);
        if ("key".equals(action)) {
            if (args.length != 2) { chat("\u00A7e[OmenaMod] \u00A7fUsage: \u00A7b/omenamod <Key>"); return; }
            setMenuKeyFromCommand(args[1]);
            return;
        }
        if (args.length == 1 && !isBlacklistAction(action) && overallSettingsManager != null && overallSettingsManager.setMenuKeyByName(args[0])) {
            chat("\u00A7a[OmenaMod] \u00A7fMenu key changed to \u00A7b" + overallSettingsManager.getMenuKeyName() + "\u00A7f.");
            return;
        }

        if ("add".equals(action)) {
            if (args.length != 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw add <name>");
                return;
            }
            String name = args[1];
            if (!BlacklistManager.isValidPlayerName(name)) {
                chat("\u00A7c[Blacklist] \u00A7fInvalid Minecraft username. Use 1-16 letters, numbers, or underscores.");
                return;
            }
            if (blacklistManager.contains(name)) {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f is already on the blacklist.");
                return;
            }
            if (blacklistManager.isAtCapacity()) {
                chat("\u00A7c[Blacklist] \u00A7fBlacklist limit reached (" + BlacklistManager.MAX_ENTRIES + ").");
                return;
            }
            if (blacklistManager.add(name)) {
                chat("\u00A7a[Blacklist] \u00A7fAdded \u00A7b" + name + "\u00A7f to the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7c[Blacklist] \u00A7fCould not add that player.");
            }
            return;
        }

        if ("remove".equals(action) || "del".equals(action) || "delete".equals(action)) {
            if (args.length != 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw remove <name>");
                return;
            }
            String name = args[1];
            if (!BlacklistManager.isValidPlayerName(name)) {
                chat("\u00A7c[Blacklist] \u00A7fInvalid Minecraft username.");
                return;
            }
            if (blacklistManager.remove(name)) {
                chat("\u00A7a[Blacklist] \u00A7fRemoved \u00A7b" + name + "\u00A7f from the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f was not on the blacklist.");
            }
            return;
        }

        if ("createlist".equals(action) || "newlist".equals(action)) {
            if (args.length != 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw createlist <name>");
                return;
            }
            String listName = args[1];
            if (!AdditionalListManager.isValidListName(listName) || "blacklist".equalsIgnoreCase(listName)) {
                chat("\u00A7c[Blacklist] \u00A7fList names use 1-16 letters, numbers, _ or -.");
                return;
            }
            if (additionalListManager.containsList(listName)) {
                chat("\u00A7e[Blacklist] \u00A7fList \u00A7b" + listName + "\u00A7f already exists.");
                return;
            }
            if (additionalListManager.isAtCapacity()) {
                chat("\u00A7c[Blacklist] \u00A7fList limit reached (" + AdditionalListManager.MAX_LISTS + ").");
                return;
            }
            if (additionalListManager.createList(listName)) {
                chat("\u00A7a[Blacklist] \u00A7fCreated list \u00A7b" + listName + "\u00A7f.");
            } else {
                chat("\u00A7c[Blacklist] \u00A7fCould not create that list.");
            }
            return;
        }

        if ("lists".equals(action)) {
            showLists();
            return;
        }

        if ("addto".equals(action)) {
            if (args.length != 3) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw addto <list> <name>");
                return;
            }
            if (!additionalListManager.containsList(args[1])) {
                chat("\u00A7c[Blacklist] \u00A7fUnknown additional list: \u00A7b" + args[1]);
                return;
            }
            if (!BlacklistManager.isValidPlayerName(args[2])) {
                chat("\u00A7c[Blacklist] \u00A7fInvalid Minecraft username.");
                return;
            }
            if (additionalListManager.addPlayer(args[1], args[2])) {
                chat("\u00A7a[Blacklist] \u00A7fAdded \u00A7b" + args[2] + "\u00A7f to list \u00A7b" + args[1] + "\u00A7f.");
            } else {
                chat("\u00A7e[Blacklist] \u00A7fCould not add that player; they may already be on the list.");
            }
            return;
        }

        if ("removefrom".equals(action)) {
            if (args.length != 3) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw removefrom <list> <name>");
                return;
            }
            if (additionalListManager.removePlayer(args[1], args[2])) {
                chat("\u00A7a[Blacklist] \u00A7fRemoved \u00A7b" + args[2] + "\u00A7f from list \u00A7b" + args[1] + "\u00A7f.");
            } else {
                chat("\u00A7e[Blacklist] \u00A7fThat player was not on that list.");
            }
            return;
        }

        if ("list".equals(action)) {
            showBlacklist();
            return;
        }

        if ("check".equals(action) || "status".equals(action)) {
            printCurrentStatus();
            return;
        }

        if ("clear".equals(action)) {
            if (blacklistManager.clear()) {
                chat("\u00A7a[Blacklist] \u00A7fCleared the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7fThe blacklist is already empty.");
            }
            return;
        }

        if ("help".equals(action)) {
            showHelp();
            return;
        }

        chat("\u00A7c[Blacklist] \u00A7fUnknown command. Use \u00A7b/blw help\u00A7f.");
    }

    private boolean isBlacklistAction(String action) {
        return "add".equals(action) || "remove".equals(action) || "del".equals(action) || "delete".equals(action)
                || "createlist".equals(action) || "newlist".equals(action) || "lists".equals(action) || "addto".equals(action)
                || "removefrom".equals(action) || "list".equals(action) || "check".equals(action) || "status".equals(action)
                || "clear".equals(action) || "help".equals(action);
    }

    private void setMenuKeyFromCommand(String keyName) {
        if (overallSettingsManager != null && overallSettingsManager.setMenuKeyByName(keyName)) {
            chat("\u00A7a[OmenaMod] \u00A7fMenu key changed to \u00A7b" + overallSettingsManager.getMenuKeyName() + "\u00A7f.");
        } else {
            chat("\u00A7c[OmenaMod] \u00A7fUnknown or unsupported key: \u00A7b" + keyName + "\u00A7f.");
        }
    }

    private void showHelp() {
        chat("\u00A7b[Blacklist] \u00A7fCommands:");
        chat("\u00A77/blw add <name> \u00A7f- add a player");
        chat("\u00A77/blw remove <name> \u00A7f- remove a player");
        chat("\u00A77/blw list \u00A7f- show your blacklist");
        chat("\u00A77/blw check \u00A7f- check the current lobby");
        chat("\u00A77/blw clear \u00A7f- remove everyone from the blacklist");
        chat("\u00A77/blw createlist <name> \u00A7f- create another list");
        chat("\u00A77/blw lists \u00A7f- show saved lists");
        chat("\u00A77/blw addto <list> <name> \u00A7f- add to another list");
        chat("\u00A77/blw removefrom <list> <name> \u00A7f- remove from another list");
        chat("\u00A77/omenamod <Key> \u00A7f- change the OmenaMod menu key");
    }

    private void showBlacklist() {
        List<String> entries = blacklistManager.getEntries();
        if (entries.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist.");
            return;
        }

        int count = Math.min(entries.size(), MAX_COMMAND_LIST_ENTRIES);
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) builder.append("\u00A77, \u00A7b");
            builder.append(entries.get(i));
        }
        chat("\u00A7b[Blacklist] \u00A7f" + entries.size() + " player(s): \u00A7b" + builder.toString());
        if (entries.size() > count) {
            chat("\u00A77[Blacklist] " + (entries.size() - count) + " more saved. Press N -> Blacklist Settings to view them.");
        }
    }

    private void printCurrentStatus() {
        if (blacklistManager.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
            return;
        }

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            chat("\u00A7e[Blacklist] \u00A7fYou are not currently connected to a lobby.");
            return;
        }

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        if (playerInfo == null || playerInfo.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        List<String> matches = findMatches(playerInfo);
        if (matches.isEmpty()) {
            chat("\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
            return;
        }

        int count = Math.min(matches.size(), MAX_STATUS_MATCHES);
        for (int i = 0; i < count; i++) {
            chat("\u00A7c[Blacklist] \u00A7f" + matches.get(i) + "\u00A7c is in the lobby.");
        }
        if (matches.size() > count) {
            chat("\u00A77[Blacklist] " + (matches.size() - count) + " additional matches omitted from chat.");
        }
    }

    private List<String> findMatches(Collection<NetworkPlayerInfo> playerInfo) {
        List<String> matches = new ArrayList<String>();
        int scanned = 0;
        for (NetworkPlayerInfo info : playerInfo) {
            if (++scanned > MAX_TAB_PLAYERS_SCANNED) break;
            if (info == null) continue;
            try {
                GameProfile profile = info.func_178845_a();
                if (profile == null || !BlacklistManager.isValidPlayerName(profile.getName())) continue;
                if (blacklistManager.contains(profile.getName())) {
                    matches.add(getFormattedTabText(info, profile));
                }
            } catch (RuntimeException ignored) { }
        }
        return matches;
    }

    private void forceStatusRefresh() {
        lastStatus = STATUS_UNKNOWN;
        if (connectedChecks < STATUS_DELAY_CHECKS) {
            connectedChecks = STATUS_DELAY_CHECKS;
        }
    }

    private void announceStatus(int status, String message) {
        if (connectedChecks < STATUS_DELAY_CHECKS) return;
        if (lastStatus == status) return;
        lastStatus = status;
        chat(message);
    }

    private void beginNewLobby(WorldClient world) {
        lastWorld = world;
        detectedPlayers.clear();
        previousPlayers.clear();
        detectedAdditionalPlayers.clear();
        activeItemMatches.clear();
        connectedChecks = 0;
        lastStatus = STATUS_UNKNOWN;
        lastLobbyPlayerCount = -1;
    }

    private void resetConnectionState() {
        detectedPlayers.clear();
        previousPlayers.clear();
        detectedAdditionalPlayers.clear();
        activeItemMatches.clear();
        connectedChecks = 0;
        lastStatus = STATUS_UNKNOWN;
        lastLobbyPlayerCount = -1;
        lastWorld = null;
        welcomeShownForConnection = false;
    }

    private void processEnchantAlertsForTarget(String target, Map<UUID, String> currentPlayers) {
        if (currentPlayers == null) currentPlayers = Collections.emptyMap();
        java.util.HashSet<String> seen = new java.util.HashSet<String>();
        for (Map.Entry<UUID,String> player : currentPlayers.entrySet()) {
            handleItemAlerts(target, player.getKey(), player.getValue(), "wearing", GearInfoUtil.getLeggingsGear(mc, player.getKey()), seen);
            handleItemAlerts(target, player.getKey(), player.getValue(), "holding", GearInfoUtil.getHeldGear(mc, player.getKey()), seen);
        }
        java.util.Iterator<Map.Entry<String,ItemPresence>> it = activeItemMatches.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String,ItemPresence> e = it.next(); ItemPresence old=e.getValue();
            if (!old.target.equalsIgnoreCase(target) || seen.contains(e.getKey())) continue;
            if (!currentPlayers.containsKey(old.uuid) && !isUuidStillInLobby(old.uuid)) alertItemLeft(old);
            it.remove();
        }
    }

    private void handleItemAlerts(String target, UUID uuid, String playerText, String slot, GearInfoUtil.GearData gear, java.util.Set<String> seen) {
        String key = itemStateKey(target, uuid, slot); ItemPresence old=activeItemMatches.get(key);
        if (gear == null || gear.isEmpty()) { if (old != null) seen.add(key); return; }
        List<ItemEnchant> matches = collectKnownMatches(gear, "wearing".equals(slot));
        if (matches.isEmpty()) { activeItemMatches.remove(key); return; }
        seen.add(key);
        ItemPresence now=new ItemPresence(target,uuid,playerText,slot,gear.signature,matches);
        if (old==null || !old.signature.equals(now.signature)) { activeItemMatches.put(key,now); alertItemDetected(now); }
        else activeItemMatches.put(key,now);
    }

    private List<ItemEnchant> collectKnownMatches(GearInfoUtil.GearData gear, boolean leggings) {
        List<ItemEnchant> out=new ArrayList<ItemEnchant>();
        for(String category:EnchantRegistry.categories()){
            if(leggings&&!EnchantRegistry.isLeggingsCategory(category))continue;
            if(!leggings&&!EnchantRegistry.isHeldCategory(category))continue;
            for(String enchant:EnchantRegistry.enchantsFor(category)){
                String line=GearInfoUtil.findEnchantTierLine(gear.enchants,enchant);
                if(line!=null)out.add(new ItemEnchant(category,enchant,line));
            }
        }
        return out;
    }

    private void alertItemDetected(ItemPresence p) {
        ItemEnchant ping=null; boolean localPingThrottle=false,localChatThrottle=false; List<String> chatLines=new ArrayList<String>(); String chatColour="c";
        for(ItemEnchant m:p.matches){
            if(enchantSettingsManager.isJoinPingEnabled(p.target,m.category,m.enchant)){if(ping==null)ping=m;localPingThrottle|=enchantSettingsManager.isThrottlePingEnabled(p.target,m.category,m.enchant);}
            if(enchantSettingsManager.isJoinChatEnabled(p.target,m.category,m.enchant)){if(chatLines.isEmpty())chatColour=enchantSettingsManager.getJoinColour(p.target,m.category,m.enchant);chatLines.add(formatAlertEnchant(m));localChatThrottle|=enchantSettingsManager.isThrottleChatEnabled(p.target,m.category,m.enchant);}
        }
        String event=p.uuid+"|"+p.slot+"|"+p.signature;
        if(ping!=null&&alertThrottleManager.allowPing(p.target,event,localPingThrottle))playPing(enchantSettingsManager.getJoinSound(p.target,ping.category,ping.enchant),1.35F,enchantSettingsManager.getJoinVolumeFloat(p.target,ping.category,ping.enchant));
        if(!chatLines.isEmpty()&&alertThrottleManager.allowChat(p.target,event,localChatThrottle))chat("\u00A7"+chatColour+"["+p.target+"] \u00A7f"+p.playerText+" \u00A7"+chatColour+"is "+p.slot+" "+joinAlertLines(chatLines)+".");
    }

    private void alertItemLeft(ItemPresence p) {
        ItemEnchant ping=null; boolean localPingThrottle=false,localChatThrottle=false; List<String> chatLines=new ArrayList<String>(); String chatColour="e";
        for(ItemEnchant m:p.matches){
            if(enchantSettingsManager.isLeavePingEnabled(p.target,m.category,m.enchant)){if(ping==null)ping=m;localPingThrottle|=enchantSettingsManager.isThrottlePingEnabled(p.target,m.category,m.enchant);}
            if(enchantSettingsManager.isLeaveChatEnabled(p.target,m.category,m.enchant)){if(chatLines.isEmpty())chatColour=enchantSettingsManager.getLeaveColour(p.target,m.category,m.enchant);chatLines.add(formatAlertEnchant(m));localChatThrottle|=enchantSettingsManager.isThrottleChatEnabled(p.target,m.category,m.enchant);}
        }
        String event="leave|"+p.uuid+"|"+p.slot+"|"+p.signature;
        if(ping!=null&&alertThrottleManager.allowPing(p.target,event,localPingThrottle))playPing(enchantSettingsManager.getLeaveSound(p.target,ping.category,ping.enchant),0.65F,enchantSettingsManager.getLeaveVolumeFloat(p.target,ping.category,ping.enchant));
        if(!chatLines.isEmpty()&&alertThrottleManager.allowChat(p.target,event,localChatThrottle))chat("\u00A7"+chatColour+"["+p.target+"] \u00A7f"+p.playerText+" \u00A7"+chatColour+"left while "+p.slot+" "+joinAlertLines(chatLines)+".");
    }

    private String formatAlertEnchant(ItemEnchant m){EnchantRegistry.Definition d=EnchantRegistry.definition(m.category,m.enchant);return (d!=null&&d.rare?"\u00A7dRARE! \u00A7f":"")+m.line;}
    private String joinAlertLines(List<String> lines){StringBuilder b=new StringBuilder();for(String x:lines){if(b.length()>0)b.append("\u00A77, \u00A7f");b.append(x);}return b.toString();}
    private String itemStateKey(String target,UUID uuid,String slot){return EnchantRegistry.id(target)+"|"+uuid+"|"+slot;}

    private boolean isUuidStillInLobby(UUID uuid) {
        if (uuid == null || mc.func_147114_u() == null) return false;
        try {
            Collection<NetworkPlayerInfo> infos = mc.func_147114_u().func_175106_d(); if (infos == null) return false; int checked=0;
            for(NetworkPlayerInfo info:infos){if(++checked>MAX_TAB_PLAYERS_SCANNED)break;if(info==null)continue;GameProfile profile=info.func_178845_a();if(profile!=null&&uuid.equals(profile.getId()))return true;}
        } catch(RuntimeException ignored) { }
        return false;
    }

    private static final class ItemEnchant { final String category,enchant,line; ItemEnchant(String c,String e,String l){category=c;enchant=e;line=l;} }
    private static final class ItemPresence { final String target,playerText,slot,signature; final UUID uuid; final List<ItemEnchant> matches; ItemPresence(String t,UUID u,String p,String s,String sig,List<ItemEnchant>m){target=t;uuid=u;playerText=p==null?"Unknown":p;slot=s;signature=sig==null?"":sig;matches=new ArrayList<ItemEnchant>(m);} }

    private void alert(String tabText) {
        String event = "listjoin|" + GearInfoUtil.stripFormatting(tabText);
        if (featureSettingsManager.isJoinPingEnabled() && alertThrottleManager.allowPing("Blacklist", event, false)) playPing(soundSettingsManager.getJoinSound("Blacklist"), 1.35F, soundSettingsManager.getJoinVolumeFloat());
        if (featureSettingsManager.isJoinChatEnabled() && alertThrottleManager.allowChat("Blacklist", event, false)) {
            String c = colourSettingsManager.getJoinCode("Blacklist");
            chat("\u00A7" + c + "[Blacklist] \u00A7f" + tabText + "\u00A7" + c + " is in the lobby.");
        }
    }

    private void alertLeft(String tabText) {
        String event = "listleave|" + GearInfoUtil.stripFormatting(tabText);
        if (featureSettingsManager.isLeavePingEnabled() && alertThrottleManager.allowPing("Blacklist", event, false)) playPing(soundSettingsManager.getLeaveSound("Blacklist"), 0.65F, soundSettingsManager.getLeaveVolumeFloat());
        if (featureSettingsManager.isLeaveChatEnabled() && alertThrottleManager.allowChat("Blacklist", event, false)) {
            String c = colourSettingsManager.getLeaveCode("Blacklist");
            chat("\u00A7" + c + "[Blacklist] \u00A7f" + tabText + "\u00A7" + c + " left the lobby.");
        }
    }

    private void alertAdditionalJoined(String listName, String tabText) {
        if (!alertThrottleManager.allowChat(listName, "listjoin|" + GearInfoUtil.stripFormatting(tabText), false)) return;
        String c = colourSettingsManager.getJoinCode(listName);
        chat("\u00A7" + c + "[" + listName + "] \u00A7f" + tabText + "\u00A7" + c + " is in the lobby.");
    }

    private void alertAdditionalLeft(String listName, String tabText) {
        if (!alertThrottleManager.allowChat(listName, "listleave|" + GearInfoUtil.stripFormatting(tabText), false)) return;
        String c = colourSettingsManager.getLeaveCode(listName);
        chat("\u00A7" + c + "[" + listName + "] \u00A7f" + tabText + "\u00A7" + c + " left the lobby.");
    }

    private boolean containsAdditionalDisplayName(String listName, String tabText) {
        if (tabText == null) return false;
        for (String player : additionalListManager.getEntries(listName)) {
            if (tabText.toLowerCase(Locale.ROOT).contains(player.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    /** Plays locally on the client; this does not send a command or custom packet to the server. */
    private void playPing(String soundId, float pitch, float volume) {
        if (mc.field_71439_g == null || volume <= 0.0F) return;
        try {
            mc.field_71439_g.func_85030_a(SoundChoice.sanitize(soundId), OverallSettingsManager.applyGlobalVolume(volume), pitch);
        } catch (RuntimeException ignored) { }
    }

    public void previewJoinPing() { previewJoinPing("Blacklist"); }
    public void previewLeavePing() { previewLeavePing("Blacklist"); }
    public void previewJoinPing(String listName) { playPing(soundSettingsManager.getJoinSound(listName), 1.35F, soundSettingsManager.getJoinVolumeFloat(listName)); }
    public void previewLeavePing(String listName) { playPing(soundSettingsManager.getLeaveSound(listName), 0.65F, soundSettingsManager.getLeaveVolumeFloat(listName)); }
    public void previewEnchantPing(String target, String category, String enchant, boolean join) {
        if (join) playPing(enchantSettingsManager.getJoinSound(target, category, enchant), 1.35F, enchantSettingsManager.getJoinVolumeFloat(target, category, enchant));
        else playPing(enchantSettingsManager.getLeaveSound(target, category, enchant), 0.65F, enchantSettingsManager.getLeaveVolumeFloat(target, category, enchant));
    }
    public SoundSettingsManager getSoundSettingsManager() { return soundSettingsManager; }
    public OverallSettingsManager getOverallSettingsManager() { return overallSettingsManager; }
    public EnchantSettingsManager getEnchantSettingsManager() { return enchantSettingsManager; }
    public PlayerGearDisplayManager getPlayerGearDisplayManager() { return playerGearDisplayManager; }
    public AlertThrottleManager getAlertThrottleManager() { return alertThrottleManager; }
    public MysticWatcher getMysticWatcher() { return mysticWatcher; }

    private void showLists() {
        List<String> names = additionalListManager.getListNames();
        if (names.isEmpty()) {
            chat("\u00A7b[Blacklist] \u00A7fLists: \u00A7cBlacklist\u00A7f (primary only)");
            return;
        }
        StringBuilder builder = new StringBuilder("Blacklist");
        for (String name : names) {
            builder.append("\u00A77, \u00A7b").append(name);
        }
        chat("\u00A7b[Blacklist] \u00A7fLists: \u00A7b" + builder.toString());
    }

    public AdditionalListManager getAdditionalListManager() {
        return additionalListManager;
    }

    public FeatureSettingsManager getFeatureSettingsManager() {
        return featureSettingsManager;
    }

    public ColourSettingsManager getColourSettingsManager() {
        return colourSettingsManager;
    }

    private void chat(String message) {
        if (mc.field_71439_g == null || message == null) return;
        String safe = sanitizeLocalChat(message);
        mc.field_71439_g.func_145747_a(new ChatComponentText(safe));
    }

    private String sanitizeLocalChat(String message) {
        StringBuilder out = new StringBuilder(Math.min(message.length(), MAX_CHAT_MESSAGE_CHARS));
        for (int i = 0; i < message.length() && out.length() < MAX_CHAT_MESSAGE_CHARS; i++) {
            char c = message.charAt(i);
            if (c < 32 || c == 127) continue;
            out.append(c);
        }
        return out.toString();
    }

    public List<String> getDetectedPlayers() {
        return Collections.unmodifiableList(new ArrayList<String>(detectedPlayers.values()));
    }
}
