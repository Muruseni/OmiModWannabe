package com.example.blacklistedlobbywatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

/** Stores up to five additional named client-side lists and their HUD toggles. */
public class AdditionalListManager {
    private static final Pattern LIST_NAME = Pattern.compile("^[A-Za-z0-9_-]{1,16}$");
    private static final long MAX_CONFIG_BYTES = 256L * 1024L;
    public static final int MAX_LISTS = 5;
    public static final int MAX_ENTRIES_PER_LIST = 1000;

    private final File file;
    private final LinkedHashMap<String, List<String>> lists = new LinkedHashMap<String, List<String>>();
    private final LinkedHashMap<String, Boolean> hudEnabled = new LinkedHashMap<String, Boolean>();

    public AdditionalListManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher_lists.properties");
    }

    public void load() {
        lists.clear();
        hudEnabled.clear();
        if (!file.exists()) return;
        if (!file.isFile() || file.length() > MAX_CONFIG_BYTES) {
            System.err.println("[BlacklistedLobbyWatcher] Ignoring oversized or invalid lists config.");
            return;
        }

        FileInputStream input = null;
        try {
            Properties properties = new Properties();
            input = new FileInputStream(file);
            properties.load(input);
            int count = parseInt(properties.getProperty("count"), 0, 0, MAX_LISTS);
            for (int i = 0; i < count && lists.size() < MAX_LISTS; i++) {
                String name = properties.getProperty("list." + i + ".name");
                if (!isValidListName(name) || isPrimaryName(name) || containsList(name)) continue;
                String cleanName = name.trim();
                List<String> entries = new ArrayList<String>();
                String raw = properties.getProperty("list." + i + ".entries", "");
                if (!raw.isEmpty()) {
                    String[] split = raw.split(",");
                    for (String player : split) {
                        if (entries.size() >= MAX_ENTRIES_PER_LIST) break;
                        addUnique(entries, player);
                    }
                }
                lists.put(cleanName, entries);
                hudEnabled.put(cleanName, parseBoolean(properties.getProperty("list." + i + ".hud"), false));
            }
        } catch (Exception e) {
            lists.clear();
            hudEnabled.clear();
            System.err.println("[BlacklistedLobbyWatcher] Could not parse additional lists config; using none.");
        } finally {
            if (input != null) {
                try { input.close(); } catch (Exception ignored) { }
            }
        }
    }

    public void save() {
        FileOutputStream output = null;
        File tempFile = new File(file.getParentFile(), file.getName() + ".tmp");
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                System.err.println("[BlacklistedLobbyWatcher] Could not create lists config directory.");
                return;
            }

            Properties properties = new Properties();
            properties.setProperty("count", Integer.toString(lists.size()));
            int index = 0;
            for (Map.Entry<String, List<String>> entry : lists.entrySet()) {
                String name = entry.getKey();
                properties.setProperty("list." + index + ".name", name);
                properties.setProperty("list." + index + ".entries", joinEntries(entry.getValue()));
                properties.setProperty("list." + index + ".hud", Boolean.toString(isHudEnabled(name)));
                index++;
            }

            output = new FileOutputStream(tempFile);
            properties.store(output, "Blacklisted Lobby Watcher additional lists");
            output.flush();
            output.close();
            output = null;

            try {
                Files.move(tempFile.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(tempFile.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            System.err.println("[BlacklistedLobbyWatcher] Could not save additional lists config.");
            tempFile.delete();
        } finally {
            if (output != null) {
                try { output.close(); } catch (Exception ignored) { }
            }
        }
    }

    public static boolean isValidListName(String name) {
        return name != null && LIST_NAME.matcher(name.trim()).matches();
    }

    private static boolean isPrimaryName(String name) {
        return name != null && "blacklist".equalsIgnoreCase(name.trim());
    }

    public boolean createList(String name) {
        if (!isValidListName(name) || isPrimaryName(name) || lists.size() >= MAX_LISTS || containsList(name)) return false;
        String cleanName = name.trim();
        lists.put(cleanName, new ArrayList<String>());
        hudEnabled.put(cleanName, false);
        save();
        return true;
    }

    public boolean containsList(String name) {
        return findKey(name) != null;
    }

    public boolean isAtCapacity() {
        return lists.size() >= MAX_LISTS;
    }

    public List<String> getListNames() {
        return Collections.unmodifiableList(new ArrayList<String>(lists.keySet()));
    }

    public List<String> getEntries(String listName) {
        String key = findKey(listName);
        if (key == null) return Collections.emptyList();
        return Collections.unmodifiableList(new ArrayList<String>(lists.get(key)));
    }

    public int size(String listName) {
        String key = findKey(listName);
        return key == null ? 0 : lists.get(key).size();
    }

    public boolean containsPlayer(String listName, String playerName) {
        String key = findKey(listName);
        return key != null && containsPlayer(lists.get(key), playerName);
    }

    public boolean isHudEnabled(String listName) {
        String key = findKey(listName);
        if (key == null) return false;
        Boolean enabled = hudEnabled.get(key);
        return enabled != null && enabled.booleanValue();
    }

    public void setHudEnabled(String listName, boolean enabled) {
        String key = findKey(listName);
        if (key == null) return;
        hudEnabled.put(key, Boolean.valueOf(enabled));
        save();
    }

    public boolean addPlayer(String listName, String playerName) {
        String key = findKey(listName);
        if (key == null || !BlacklistManager.isValidPlayerName(playerName)) return false;
        List<String> entries = lists.get(key);
        if (entries.size() >= MAX_ENTRIES_PER_LIST || containsPlayer(entries, playerName)) return false;
        entries.add(playerName.trim());
        save();
        return true;
    }

    public boolean removePlayer(String listName, String playerName) {
        String key = findKey(listName);
        if (key == null || !BlacklistManager.isValidPlayerName(playerName)) return false;
        List<String> entries = lists.get(key);
        String target = playerName.trim().toLowerCase(Locale.ROOT);
        boolean changed = false;
        for (int i = entries.size() - 1; i >= 0; i--) {
            if (entries.get(i).toLowerCase(Locale.ROOT).equals(target)) {
                entries.remove(i);
                changed = true;
            }
        }
        if (changed) save();
        return changed;
    }

    private String findKey(String name) {
        if (name == null) return null;
        String normalized = name.trim().toLowerCase(Locale.ROOT);
        for (String key : lists.keySet()) {
            if (key.toLowerCase(Locale.ROOT).equals(normalized)) return key;
        }
        return null;
    }

    private static void addUnique(List<String> entries, String player) {
        if (!BlacklistManager.isValidPlayerName(player) || entries.size() >= MAX_ENTRIES_PER_LIST) return;
        if (!containsPlayer(entries, player)) entries.add(player.trim());
    }

    private static boolean containsPlayer(List<String> entries, String player) {
        if (player == null) return false;
        String normalized = player.trim().toLowerCase(Locale.ROOT);
        for (String entry : entries) {
            if (entry.toLowerCase(Locale.ROOT).equals(normalized)) return true;
        }
        return false;
    }

    private String joinEntries(List<String> entries) {
        StringBuilder builder = new StringBuilder();
        for (String entry : entries) {
            if (builder.length() > 0) builder.append(',');
            builder.append(entry);
        }
        return builder.toString();
    }

    private int parseInt(String value, int fallback, int min, int max) {
        try {
            int parsed = Integer.parseInt(value == null ? "" : value.trim());
            return Math.max(min, Math.min(max, parsed));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private boolean parseBoolean(String value, boolean fallback) {
        if (value == null) return fallback;
        if ("true".equalsIgnoreCase(value.trim())) return true;
        if ("false".equalsIgnoreCase(value.trim())) return false;
        return fallback;
    }
}
