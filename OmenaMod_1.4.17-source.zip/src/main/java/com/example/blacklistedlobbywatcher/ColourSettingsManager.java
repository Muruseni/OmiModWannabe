package com.example.blacklistedlobbywatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

/** Stores per-list local chat alert colours. No networking is performed here. */
public class ColourSettingsManager {
    private static final long MAX_CONFIG_BYTES = 32L * 1024L;
    private static final String DEFAULT_JOIN = "c";
    private static final String DEFAULT_LEAVE = "e";
    private static final String VALID_CODES = "0123456789abcdef";

    private final File file;
    private final Properties values = new Properties();

    public ColourSettingsManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher_colours.properties");
    }

    public void load() {
        values.clear();
        if (!file.exists()) return;
        if (!file.isFile() || file.length() > MAX_CONFIG_BYTES) {
            System.err.println("[BlacklistedLobbyWatcher] Ignoring oversized or invalid colour config.");
            return;
        }
        FileInputStream input = null;
        try {
            input = new FileInputStream(file);
            values.load(input);
            sanitizeLoadedValues();
        } catch (Exception e) {
            values.clear();
            System.err.println("[BlacklistedLobbyWatcher] Could not parse colour config; using defaults.");
        } finally {
            if (input != null) try { input.close(); } catch (Exception ignored) { }
        }
    }

    public void save() {
        FileOutputStream output = null;
        File temp = new File(file.getParentFile(), file.getName() + ".tmp");
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return;
            sanitizeLoadedValues();
            output = new FileOutputStream(temp);
            values.store(output, "Blacklisted Lobby Watcher alert colours");
            output.flush();
            output.close();
            output = null;
            try {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            temp.delete();
            System.err.println("[BlacklistedLobbyWatcher] Could not save colour config.");
        } finally {
            if (output != null) try { output.close(); } catch (Exception ignored) { }
        }
    }

    public String getJoinCode(String listName) { return getCode(key(listName, "join"), DEFAULT_JOIN); }
    public String getLeaveCode(String listName) { return getCode(key(listName, "leave"), DEFAULT_LEAVE); }

    public void setJoinCode(String listName, String code) {
        setCode(key(listName, "join"), code, DEFAULT_JOIN);
    }

    public void setLeaveCode(String listName, String code) {
        setCode(key(listName, "leave"), code, DEFAULT_LEAVE);
    }

    public void reset(String listName) {
        values.remove(key(listName, "join"));
        values.remove(key(listName, "leave"));
        save();
    }

    public static boolean isValidCode(String code) {
        return code != null && code.length() == 1 && VALID_CODES.indexOf(Character.toLowerCase(code.charAt(0))) >= 0;
    }

    private String key(String listName, String kind) {
        String safe = listName == null ? "Blacklist" : listName.trim();
        if (!"Blacklist".equalsIgnoreCase(safe) && !AdditionalListManager.isValidListName(safe)) safe = "Blacklist";
        return "list." + safe.toLowerCase(java.util.Locale.ROOT) + "." + kind;
    }

    private String getCode(String key, String fallback) {
        String value = values.getProperty(key);
        return isValidCode(value) ? value.toLowerCase(java.util.Locale.ROOT) : fallback;
    }

    private void setCode(String key, String code, String fallback) {
        values.setProperty(key, isValidCode(code) ? code.toLowerCase(java.util.Locale.ROOT) : fallback);
        save();
    }

    private void sanitizeLoadedValues() {
        java.util.ArrayList<String> bad = new java.util.ArrayList<String>();
        for (Object rawKey : values.keySet()) {
            String k = String.valueOf(rawKey);
            String v = values.getProperty(k);
            if (!k.startsWith("list.") || !(k.endsWith(".join") || k.endsWith(".leave")) || !isValidCode(v)) bad.add(k);
        }
        for (String k : bad) values.remove(k);
    }
}
