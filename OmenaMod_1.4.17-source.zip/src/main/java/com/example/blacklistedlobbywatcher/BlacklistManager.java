package com.example.blacklistedlobbywatcher;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class BlacklistManager {
    /** Minecraft Java usernames are 1-16 characters and use letters, digits and underscores. */
    private static final Pattern PLAYER_NAME = Pattern.compile("^[A-Za-z0-9_]{1,16}$");
    /** Prevent a locally replaced/corrupt JSON file from causing unbounded parsing or memory use. */
    private static final long MAX_CONFIG_BYTES = 256L * 1024L;
    /** Far above a normal personal blacklist, but still gives the mod a firm memory/output bound. */
    public static final int MAX_ENTRIES = 1000;

    private final File file;
    private final List<String> blacklist = new ArrayList<String>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public BlacklistManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher.json");
    }

    public void load() {
        blacklist.clear();
        if (!file.exists()) {
            save();
            return;
        }

        if (!file.isFile() || file.length() > MAX_CONFIG_BYTES) {
            System.err.println("[BlacklistedLobbyWatcher] Refusing to load oversized or invalid blacklist config.");
            return;
        }

        FileReader reader = null;
        try {
            Type type = new TypeToken<List<String>>() { }.getType();
            reader = new FileReader(file);
            List<String> loaded = gson.fromJson(reader, type);
            if (loaded != null) {
                for (String name : loaded) {
                    if (blacklist.size() >= MAX_ENTRIES) break;
                    addInternal(name, false);
                }
            }
        } catch (Exception e) {
            // Treat malformed local config as an empty blacklist rather than failing mod/game loading.
            blacklist.clear();
            System.err.println("[BlacklistedLobbyWatcher] Could not parse blacklist config; using an empty blacklist.");
        } finally {
            if (reader != null) {
                try { reader.close(); } catch (Exception ignored) { }
            }
        }
    }

    public void save() {
        FileWriter writer = null;
        File tempFile = new File(file.getParentFile(), file.getName() + ".tmp");
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                System.err.println("[BlacklistedLobbyWatcher] Could not create config directory.");
                return;
            }

            writer = new FileWriter(tempFile);
            gson.toJson(blacklist, writer);
            writer.flush();
            writer.close();
            writer = null;

            try {
                Files.move(tempFile.toPath(), file.toPath(),
                        StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(tempFile.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            System.err.println("[BlacklistedLobbyWatcher] Could not save blacklist config.");
            tempFile.delete();
        } finally {
            if (writer != null) {
                try { writer.close(); } catch (Exception ignored) { }
            }
        }
    }

    public static boolean isValidPlayerName(String name) {
        if (name == null) return false;
        return PLAYER_NAME.matcher(name.trim()).matches();
    }

    public boolean isAtCapacity() {
        return blacklist.size() >= MAX_ENTRIES;
    }

    public boolean contains(String name) {
        if (!isValidPlayerName(name)) return false;
        String normalized = name.trim().toLowerCase(Locale.ROOT);
        for (String entry : blacklist) {
            if (entry.toLowerCase(Locale.ROOT).equals(normalized)) return true;
        }
        return false;
    }

    public boolean add(String name) {
        return addInternal(name, true);
    }

    private boolean addInternal(String name, boolean shouldSave) {
        if (!isValidPlayerName(name) || blacklist.size() >= MAX_ENTRIES) return false;
        String cleaned = name.trim();
        if (contains(cleaned)) return false;
        blacklist.add(cleaned);
        if (shouldSave) save();
        return true;
    }

    public boolean remove(String name) {
        if (!isValidPlayerName(name)) return false;
        String normalized = name.trim().toLowerCase(Locale.ROOT);
        boolean changed = false;
        for (int i = blacklist.size() - 1; i >= 0; i--) {
            if (blacklist.get(i).toLowerCase(Locale.ROOT).equals(normalized)) {
                blacklist.remove(i);
                changed = true;
            }
        }
        if (changed) save();
        return changed;
    }

    public boolean clear() {
        if (blacklist.isEmpty()) return false;
        blacklist.clear();
        save();
        return true;
    }

    public boolean isEmpty() {
        return blacklist.isEmpty();
    }

    public int size() {
        return blacklist.size();
    }

    public List<String> getEntries() {
        return Collections.unmodifiableList(new ArrayList<String>(blacklist));
    }

    public File getConfigDirectory() {
        return file.getParentFile();
    }
}
