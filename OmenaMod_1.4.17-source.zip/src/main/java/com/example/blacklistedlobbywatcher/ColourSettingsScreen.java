package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** Join/leave local chat colour editor for one selected list. */
public class ColourSettingsScreen extends GuiScreen {
    private static final int BUTTON_BACK = 0;
    private static final int BUTTON_JOIN = 1;
    private static final int BUTTON_LEAVE = 2;
    private static final int BUTTON_RESET = 3;

    private static final String[] CODES = {"c","6","e","a","2","b","3","9","1","d","5","f","7","8","4","0"};
    private static final String[] NAMES = {"Red","Gold","Yellow","Green","Dark Green","Aqua","Dark Aqua","Blue","Dark Blue","Light Purple","Dark Purple","White","Gray","Dark Gray","Dark Red","Black"};

    private final GuiScreen parent;
    private final ColourSettingsManager colours;
    private final String listName;

    public ColourSettingsScreen(GuiScreen parent, LobbyWatcher watcher, String listName) {
        this.parent = parent;
        this.colours = watcher.getColourSettingsManager();
        this.listName = listName == null ? "Blacklist" : listName;
    }

    @Override
    public void func_73866_w_() {
        int cx = this.field_146294_l / 2;
        int top = this.field_146295_m / 2 - 60;
        this.field_146292_n.add(new GuiButton(BUTTON_JOIN, cx - 110, top, 220, 20, joinLabel()));
        this.field_146292_n.add(new GuiButton(BUTTON_LEAVE, cx - 110, top + 28, 220, 20, leaveLabel()));
        this.field_146292_n.add(new GuiButton(BUTTON_RESET, cx - 110, top + 56, 220, 20, "Reset colours"));
        this.field_146292_n.add(new GuiButton(BUTTON_BACK, cx - 110, top + 92, 220, 20, "Back"));
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        OmenaUi.background(this.field_146294_l,this.field_146295_m);
        drawCentered("\u00A7b\u00A7l" + listName + " Colours", this.field_146295_m / 2 - 100, 0xFFFFFF);
        drawCentered("\u00A77Left-click next colour, right-click previous.", this.field_146295_m / 2 - 86, 0xFFFFFF);
        String joinCode = colours.getJoinCode(listName);
        String leaveCode = colours.getLeaveCode(listName);
        drawCentered("\u00A7" + joinCode + "[" + listName + "] \u00A7fPlayer \u00A7" + joinCode + "is in the lobby.", this.field_146295_m / 2 + 52, 0xFFFFFF);
        drawCentered("\u00A7" + leaveCode + "[" + listName + "] \u00A7fPlayer \u00A7" + leaveCode + "left the lobby.", this.field_146295_m / 2 + 66, 0xFFFFFF);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }


    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 1) {
            int cx = field_146294_l / 2, top = field_146295_m / 2 - 60;
            if (inside(mouseX, mouseY, cx - 110, top, 220, 20)) { colours.setJoinCode(listName, previousCode(colours.getJoinCode(listName))); colours.save(); rebuild(); return; }
            if (inside(mouseX, mouseY, cx - 110, top + 28, 220, 20)) { colours.setLeaveCode(listName, previousCode(colours.getLeaveCode(listName))); colours.save(); rebuild(); return; }
        }
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == BUTTON_JOIN) {
            colours.setJoinCode(listName, nextCode(colours.getJoinCode(listName)));
            button.field_146126_j = joinLabel();
        } else if (button.field_146127_k == BUTTON_LEAVE) {
            colours.setLeaveCode(listName, nextCode(colours.getLeaveCode(listName)));
            button.field_146126_j = leaveLabel();
        } else if (button.field_146127_k == BUTTON_RESET) {
            colours.reset(listName);
            rebuild();
        } else if (button.field_146127_k == BUTTON_BACK) {
            colours.save();
            this.field_146297_k.func_147108_a(parent);
        }
    }

    @Override public void func_146281_b() { colours.save(); }
    private void rebuild() { this.field_146292_n.clear(); func_73866_w_(); }
    private String joinLabel() { String c = colours.getJoinCode(listName); return "Join message: \u00A7" + c + colorName(c); }
    private String leaveLabel() { String c = colours.getLeaveCode(listName); return "Leave message: \u00A7" + c + colorName(c); }
    private String nextCode(String current) {
        for (int i = 0; i < CODES.length; i++) if (CODES[i].equalsIgnoreCase(current)) return CODES[(i + 1) % CODES.length];
        return CODES[0];
    }
    private String previousCode(String current) {
        for (int i = 0; i < CODES.length; i++) if (CODES[i].equalsIgnoreCase(current)) return CODES[(i + CODES.length - 1) % CODES.length];
        return CODES[0];
    }
    private boolean inside(int mx,int my,int x,int y,int w,int h){return mx>=x&&mx<x+w&&my>=y&&my<y+h;}
    private String colorName(String code) {
        for (int i = 0; i < CODES.length; i++) if (CODES[i].equalsIgnoreCase(code)) return NAMES[i];
        return "Red";
    }
    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
