package com.example.blacklistedlobbywatcher;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Pit Classic friend-list UI mirror. Server friend commands remain server-side. */
public class FriendListWatcher {
    private static final long COMMAND_COOLDOWN_MS = 650L;
    private static final String NETWORK_LOBBY_TEXT = "NETWORK LOBBY";
    private static final String FRIENDS_HUD_KEY = "friends";
    private static final String FF_HUD_KEY = "friend_ff";
    private static final int FF_UNKNOWN = -1;
    private static final int FF_OFF = 0;
    private static final int FF_ON = 1;

    private final Minecraft mc;
    private final FriendListManager manager;
    private final IndependentHudPositionManager hudPositionManager;
    private final Map<UUID,String> current = new LinkedHashMap<UUID,String>();
    private final Map<UUID,String> previous = new LinkedHashMap<UUID,String>();
    private final Map<String, FriendItemPresence> activeItemMatches = new LinkedHashMap<String, FriendItemPresence>();
    private int ticks;
    private long lastCommandAt;
    private boolean sentHistoryInitialized;
    private int observedSentMessages;
    private int ffState = FF_UNKNOWN;

    public FriendListWatcher(Minecraft mc, FriendListManager manager, IndependentHudPositionManager hudPositionManager) {
        this.mc = mc;
        this.manager = manager;
        this.hudPositionManager = hudPositionManager;
        ensureHudPositions();
    }

    public boolean isOnPitClassic() {
        if (mc == null || mc.func_71356_B()) return false;
        ServerData data = mc.func_147104_D();
        if (data == null || data.field_78845_b == null) return false;
        String host = data.field_78845_b.trim().toLowerCase(Locale.ROOT);
        int colon = host.indexOf(':');
        if (colon >= 0) host = host.substring(0, colon);
        return host.equals("pitclassic.net") || host.endsWith(".pitclassic.net");
    }

    /** Reads only already-received local scoreboard/TAB state. No packet is sent. */
    public boolean isNetworkLobby() {
        if (!isOnPitClassic()) return false;
        try {
            if (mc.field_71441_e != null) {
                Scoreboard scoreboard = mc.field_71441_e.func_96441_U();
                if (scoreboard != null) {
                    ScoreObjective objective = scoreboard.func_96539_a(1);
                    if (objective != null) {
                        if (containsNetworkLobby(objective.func_96678_d())) return true;
                        Collection<Score> scores = scoreboard.func_96534_i(objective);
                        if (scores != null) {
                            int checked = 0;
                            for (Score score : scores) {
                                if (++checked > 64) break;
                                if (score == null) continue;
                                String player = score.func_96653_e();
                                if (containsNetworkLobby(player)) return true;
                                ScorePlayerTeam team = scoreboard.func_96509_i(player);
                                if (containsNetworkLobby(ScorePlayerTeam.func_96667_a(team, player))) return true;
                            }
                        }
                    }
                }
            }
        } catch (RuntimeException ignored) { }

        try {
            if (mc.func_147114_u() != null) {
                Collection<NetworkPlayerInfo> infos = mc.func_147114_u().func_175106_d();
                if (infos != null) {
                    int checked = 0;
                    for (NetworkPlayerInfo info : infos) {
                        if (++checked > 160) break;
                        if (info == null) continue;
                        GameProfile profile = info.func_178845_a();
                        if (profile != null && containsNetworkLobby(formatted(info, profile))) return true;
                    }
                }
            }
        } catch (RuntimeException ignored) { }
        return false;
    }

    public String findLobbyPlayer(String requestedName) {
        if (!BlacklistManager.isValidPlayerName(requestedName) || mc.func_147114_u() == null) return null;
        try {
            Collection<NetworkPlayerInfo> infos = mc.func_147114_u().func_175106_d();
            if (infos == null) return null;
            int checked = 0;
            for (NetworkPlayerInfo info : infos) {
                if (++checked > 1000) break;
                if (info == null) continue;
                GameProfile profile = info.func_178845_a();
                if (profile != null && BlacklistManager.isValidPlayerName(profile.getName())
                        && profile.getName().equalsIgnoreCase(requestedName)) return profile.getName();
            }
        } catch (RuntimeException ignored) { }
        return null;
    }

    public String getFriendCommandBlockReason(String action, String name) {
        if (!isOnPitClassic()) return "You must be on Pit Classic (pitclassic.net).";
        if (isNetworkLobby()) return "Friend commands cannot be used in the NETWORK LOBBY.";
        if (!("add".equalsIgnoreCase(action) || "remove".equalsIgnoreCase(action))) return "Unsupported friend command.";
        if (!BlacklistManager.isValidPlayerName(name)) return "Enter a valid Minecraft IGN.";
        if (findLobbyPlayer(name) == null) return "That player must be in your current lobby.";
        return null;
    }

    public String getFfCommandBlockReason() {
        if (!isOnPitClassic()) return "You must be on Pit Classic (pitclassic.net).";
        if (isNetworkLobby()) return "/ff cannot be used in the NETWORK LOBBY.";
        return null;
    }

    public boolean sendFriendCommand(String action, String requestedName) {
        String reason = getFriendCommandBlockReason(action, requestedName);
        if (reason != null || mc.field_71439_g == null || !commandCooldownReady()) return false;
        String canonical = findLobbyPlayer(requestedName);
        if (canonical == null) return false;
        String verb = "remove".equalsIgnoreCase(action) ? "remove" : "add";
        mc.field_71439_g.func_71165_d("/friend " + verb + " " + canonical);
        lastCommandAt = System.currentTimeMillis();
        if ("add".equals(verb)) manager.add(canonical); else manager.remove(canonical);
        return true;
    }

    /** Sends /ff on or /ff off only from an explicit GUI action and records that explicit choice locally. */
    public boolean sendFfCommand(boolean enabled) {
        if (getFfCommandBlockReason() != null || mc.field_71439_g == null || !commandCooldownReady()) return false;
        mc.field_71439_g.func_71165_d(enabled ? "/ff on" : "/ff off");
        lastCommandAt = System.currentTimeMillis();
        ffState = enabled ? FF_ON : FF_OFF;
        return true;
    }

    /**
     * Observes Minecraft's own sent-chat history after vanilla has already sent the message.
     * This does not intercept, cancel, resend, or reflect into GuiChat.
     */
    private void observeManualCommandsFromHistory() {
        try {
            if (mc.field_71456_v == null || mc.field_71456_v.func_146158_b() == null) return;
            List<String> sent = mc.field_71456_v.func_146158_b().func_146238_c();
            if (sent == null) return;

            if (!sentHistoryInitialized) {
                observedSentMessages = sent.size();
                sentHistoryInitialized = true;
                return;
            }

            if (observedSentMessages > sent.size()) observedSentMessages = 0;
            int processed = 0;
            while (observedSentMessages < sent.size() && processed++ < 8) {
                String raw = sent.get(observedSentMessages++);
                observeManualCommand(raw);
            }

            // If more than eight messages arrived in one tick, skip the backlog rather than doing
            // unbounded work. Normal user chat can never realistically hit this path.
            if (observedSentMessages < sent.size()) observedSentMessages = sent.size();
        } catch (RuntimeException ignored) { }
    }

    private void observeManualCommand(String raw) {
        if (raw == null) return;
        String msg = raw.trim();
        String[] p = msg.split("\\s+");
        if (p.length == 3 && "/friend".equalsIgnoreCase(p[0])
                && ("add".equalsIgnoreCase(p[1]) || "remove".equalsIgnoreCase(p[1]))
                && BlacklistManager.isValidPlayerName(p[2])) {
            if (getFriendCommandBlockReason(p[1], p[2]) != null) return;
            String canonical = findLobbyPlayer(p[2]);
            if (canonical == null) return;
            if ("add".equalsIgnoreCase(p[1])) manager.add(canonical); else manager.remove(canonical);
            return;
        }
        if (p.length == 2 && "/ff".equalsIgnoreCase(p[0])
                && ("on".equalsIgnoreCase(p[1]) || "off".equalsIgnoreCase(p[1]))) {
            if (getFfCommandBlockReason() == null) ffState = "on".equalsIgnoreCase(p[1]) ? FF_ON : FF_OFF;
        }
    }

    private boolean commandCooldownReady() {
        return System.currentTimeMillis() - lastCommandAt >= COMMAND_COOLDOWN_MS;
    }

    private boolean containsNetworkLobby(String text) {
        return text != null && stripFormatting(text).toUpperCase(Locale.ROOT).contains(NETWORK_LOBBY_TEXT);
    }

    private String stripFormatting(String text) {
        if (text == null) return "";
        StringBuilder out = new StringBuilder(text.length());
        boolean skip = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (skip) { skip = false; continue; }
            if (c == '\u00A7') { skip = true; continue; }
            if (c >= 32 && c != 127) out.append(c);
        }
        return out.toString();
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event == null || event.phase != TickEvent.Phase.END || ++ticks < 5) return;
        ticks = 0;
        if (!isOnPitClassic() || mc.field_71439_g == null || mc.func_147114_u() == null) {
            current.clear();
            previous.clear();
            activeItemMatches.clear();
            ffState = FF_UNKNOWN;
            sentHistoryInitialized = false;
            observedSentMessages = 0;
            return;
        }
        // Manual outgoing-command mirroring is temporarily disabled in 1.4.12 for Lunar stability.
        Collection<NetworkPlayerInfo> infos = mc.func_147114_u().func_175106_d();
        Map<UUID,String> now = new LinkedHashMap<UUID,String>();
        if (infos != null) {
            int count = 0;
            for (NetworkPlayerInfo info : infos) {
                if (++count > 1000 || info == null) break;
                GameProfile profile;
                try { profile = info.func_178845_a(); } catch (RuntimeException e) { continue; }
                if (profile == null || profile.getId() == null || !BlacklistManager.isValidPlayerName(profile.getName())) continue;
                if (manager.contains(profile.getName())) now.put(profile.getId(), formatted(info, profile));
            }
        }
        for (Map.Entry<UUID,String> e : now.entrySet()) if (!previous.containsKey(e.getKey())) joined(e.getValue());
        for (Map.Entry<UUID,String> e : previous.entrySet()) if (!now.containsKey(e.getKey())) left(e.getValue());
        processEnchantAlerts(now);
        current.clear(); current.putAll(now);
        previous.clear(); previous.putAll(now);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        try {
            if (!isOnPitClassic() || mc.field_71466_p == null || mc.field_71439_g == null) return;
            if (mc.field_71462_r instanceof BlacklistedLobbyMenu) return;
            ensureHudPositions(); FontRenderer f=mc.field_71466_p;
            if (manager.isHudEnabled()) drawHudBox(f,getFriendsHudLines(),getHudX(FRIENDS_HUD_KEY),getHudY(FRIENDS_HUD_KEY),getHudScale(FRIENDS_HUD_KEY),false);
            if (manager.isFfHudEnabled()) drawHudBox(f,getFfHudLines(),getHudX(FF_HUD_KEY),getHudY(FF_HUD_KEY),getHudScale(FF_HUD_KEY),false);
        } catch (Throwable ignored) { }
    }

    public void drawHudPreviews(FontRenderer font) { drawHudPreviews(font,null); }
    public void drawHudPreviews(FontRenderer font,String selectedKey) {
        try {
            if(font==null||!isOnPitClassic())return; ensureHudPositions();
            drawHudBox(font,getFriendsHudLines(),getHudX(FRIENDS_HUD_KEY),getHudY(FRIENDS_HUD_KEY),getHudScale(FRIENDS_HUD_KEY),FRIENDS_HUD_KEY.equals(selectedKey));
            drawHudBox(font,getFfHudLines(),getHudX(FF_HUD_KEY),getHudY(FF_HUD_KEY),getHudScale(FF_HUD_KEY),FF_HUD_KEY.equals(selectedKey));
        } catch(Throwable ignored){}
    }

    private List<String> getFriendsHudLines() {
        List<String> lines = new ArrayList<String>();
        lines.add("\u00A7a\u00A7lFriends in Lobby \u00A77(" + current.size() + ")");
        if (current.isEmpty()) lines.add("\u00A77None");
        else {
            lines.add("\u00A7aFriends              \u00A7bWearing                  \u00A76Holding");
            int shown = 0;
            for (Map.Entry<UUID,String> e : current.entrySet()) { if(shown>=32)break; lines.addAll(formatFriendGearRows(e.getValue(),e.getKey())); lines.add("§8------------------------------------------------------------------------"); shown++; }
            if(current.size()>shown)lines.add("\u00A77... and "+(current.size()-shown)+" more");
        }
        return lines;
    }

    private List<String> formatFriendGearRows(String playerText, UUID uuid) {
        List<String> out=new ArrayList<String>(); EnchantSettingsManager es=enchantSettings();
        GearInfoUtil.GearData pants=GearInfoUtil.getLeggingsGear(mc,uuid),held=GearInfoUtil.getHeldGear(mc,uuid);
        List<String>w=new ArrayList<String>(),h=new ArrayList<String>(); String ign=extractIgn(playerText);
        if(manager.isGearShown(ign)){if(!pants.typeLabel.isEmpty())w.add(pants.typeLabel);if(!held.typeLabel.isEmpty())h.add(held.typeLabel);}
        if(es!=null){addEnabled(w,"Friendlist",EnchantRegistry.PANTS,pants.enchants,es);addEnabled(w,"Friendlist",EnchantRegistry.DARKS,pants.enchants,es);addEnabled(h,"Friendlist",EnchantRegistry.SWORDS,held.enchants,es);addEnabled(h,"Friendlist",EnchantRegistry.BOWS,held.enchants,es);}
        int rows=Math.max(1,Math.max(w.size(),h.size()));for(int i=0;i<rows;i++){String n=i==(rows-1)/2?playerText:"",a=i<w.size()?w.get(i):"",b=i<h.size()?h.get(i):"";out.add(pad(n,20)+pad(a,25)+b);}return out;
    }
    private void addEnabled(List<String>out,String target,String category,List<String>lines,EnchantSettingsManager es){for(String enchant:EnchantRegistry.enchantsFor(category)){if(!es.isDisplayEnabled(target,category,enchant))continue;String matched=GearInfoUtil.findEnchantTierLine(lines,enchant);if(matched==null)continue;EnchantRegistry.Definition d=EnchantRegistry.definition(category,enchant);out.add((d!=null&&d.rare?"\u00A7dRARE! ":"")+"\u00A7"+es.getDisplayColour(target,category,enchant)+matched);}}
    private String pad(String s,int n){if(s==null)s="";String plain=GearInfoUtil.stripFormatting(s);StringBuilder b=new StringBuilder(s);while(plain.length()<n){b.append(' ');plain+=" ";}return b.toString();}
    private String extractIgn(String s){String[]p=GearInfoUtil.stripFormatting(s).split("\\s+");for(int i=p.length-1;i>=0;i--)if(BlacklistManager.isValidPlayerName(p[i]))return p[i];return GearInfoUtil.stripFormatting(s);}

    private List<String> getFfHudLines() { List<String>lines=new ArrayList<String>();lines.add("\u00A7b\u00A7lFriend Follow");if(ffState==FF_ON)lines.add("\u00A7a/ff: ON");else if(ffState==FF_OFF)lines.add("\u00A7c/ff: OFF");else lines.add("\u00A7e/ff: UNKNOWN");return lines; }

    private void drawHudBox(FontRenderer font,List<String>lines,int x,int y,float scale,boolean selected){
        scale=clampScale(scale);int width=hudWidth(font,lines),height=hudHeight(lines);int left=Math.round(x-4F*scale),top=Math.round(y-4F*scale),right=Math.round(x+(width+5F)*scale),bottom=Math.round(y+height*scale);Gui.func_73734_a(left,top,right,bottom,0x90000000);if(selected)drawSelectionBorder(left,top,right,bottom);GL11.glPushMatrix();try{GL11.glTranslatef((float)x,(float)y,0F);GL11.glScalef(scale,scale,1F);for(int i=0;i<lines.size();i++)font.func_78276_b(lines.get(i),0,i*10,0xFFFFFF);}finally{GL11.glPopMatrix();}
    }
    private void drawSelectionBorder(int l,int t,int r,int b){int c=0xFF55FFFF;Gui.func_73734_a(l,t,r,t+1,c);Gui.func_73734_a(l,b-1,r,b,c);Gui.func_73734_a(l,t,l+1,b,c);Gui.func_73734_a(r-1,t,r,b,c);Gui.func_73734_a(r-3,b-3,r+1,b+1,c);}
    private int hudWidth(FontRenderer font,List<String>lines){int w=0;for(String line:lines)w=Math.max(w,font.func_78256_a(line));return w;} private int hudHeight(List<String>lines){return lines.size()*10+5;}
    private void ensureHudPositions(){if(hudPositionManager==null)return;if(!hudPositionManager.hasPosition(FRIENDS_HUD_KEY))hudPositionManager.setPosition(FRIENDS_HUD_KEY,220,7);if(!hudPositionManager.hasPosition(FF_HUD_KEY))hudPositionManager.setPosition(FF_HUD_KEY,220,52);}
    public String findHudAtPoint(FontRenderer font,int mx,int my){if(font==null||!isOnPitClassic())return null;ensureHudPositions();if(inside(font,getFfHudLines(),getHudX(FF_HUD_KEY),getHudY(FF_HUD_KEY),getHudScale(FF_HUD_KEY),mx,my))return FF_HUD_KEY;if(inside(font,getFriendsHudLines(),getHudX(FRIENDS_HUD_KEY),getHudY(FRIENDS_HUD_KEY),getHudScale(FRIENDS_HUD_KEY),mx,my))return FRIENDS_HUD_KEY;return null;}
    private boolean inside(FontRenderer f,List<String>lines,int x,int y,float scale,int mx,int my){int[]b=bounds(f,lines,x,y,scale);return mx>=b[0]&&mx<=b[2]&&my>=b[1]&&my<=b[3];}
    private int[]bounds(FontRenderer f,List<String>lines,int x,int y,float scale){scale=clampScale(scale);int w=hudWidth(f,lines),h=hudHeight(lines);return new int[]{Math.round(x-4F*scale),Math.round(y-4F*scale),Math.round(x+(w+5F)*scale),Math.round(y+h*scale)};}
    private List<String>linesForKey(String key){return FF_HUD_KEY.equals(key)?getFfHudLines():getFriendsHudLines();}
    public int[]getHudBounds(FontRenderer f,String key){return bounds(f,linesForKey(key),getHudX(key),getHudY(key),getHudScale(key));}
    public int getHudResizeEdge(FontRenderer f,String key,int mx,int my){int[]b=getHudBounds(f,key);int pad=5,edge=0;if(my>=b[1]-pad&&my<=b[3]+pad){if(Math.abs(mx-b[0])<=pad)edge|=1;if(Math.abs(mx-b[2])<=pad)edge|=2;}if(mx>=b[0]-pad&&mx<=b[2]+pad){if(Math.abs(my-b[1])<=pad)edge|=4;if(Math.abs(my-b[3])<=pad)edge|=8;}return edge;}
    public int getHudX(String key){ensureHudPositions();return hudPositionManager.getX(key,220);} public int getHudY(String key){ensureHudPositions();return hudPositionManager.getY(key,FF_HUD_KEY.equals(key)?52:7);} public float getHudScale(String key){return hudPositionManager.getScale(key);} public void setHudScale(String key,float scale){hudPositionManager.setScale(key,clampScale(scale));} private float clampScale(float s){return Math.max(hudPositionManager.minScale(),Math.min(hudPositionManager.maxScale(),s));}
    public void setHudPositionClamped(String key,int x,int y,int sw,int sh,FontRenderer f){if(f==null||hudPositionManager==null)return;List<String>lines=linesForKey(key);float scale=getHudScale(key);int ow=Math.round((hudWidth(f,lines)+9)*scale),oh=Math.round((hudHeight(lines)+4)*scale),pad=Math.round(4*scale);int maxX=Math.max(pad,sw-ow+pad),maxY=Math.max(pad,sh-oh+pad);hudPositionManager.setPosition(key,Math.max(pad,Math.min(maxX,x)),Math.max(pad,Math.min(maxY,y)));}
    public void clampHudsToScreen(int sw,int sh,FontRenderer f){ensureHudPositions();setHudPositionClamped(FRIENDS_HUD_KEY,getHudX(FRIENDS_HUD_KEY),getHudY(FRIENDS_HUD_KEY),sw,sh,f);setHudPositionClamped(FF_HUD_KEY,getHudX(FF_HUD_KEY),getHudY(FF_HUD_KEY),sw,sh,f);} public void saveHudPositions(){if(hudPositionManager!=null)hudPositionManager.save();}

    public String getFfStatusLabel() {
        if (ffState == FF_ON) return "ON";
        if (ffState == FF_OFF) return "OFF";
        return "UNKNOWN";
    }

    private void processEnchantAlerts(Map<UUID,String> nowPlayers) {
        EnchantSettingsManager es=enchantSettings();if(es==null)return;java.util.HashSet<String>seen=new java.util.HashSet<String>();
        for(Map.Entry<UUID,String>e:nowPlayers.entrySet()){handleFriendItem(es,e.getKey(),e.getValue(),"wearing",GearInfoUtil.getLeggingsGear(mc,e.getKey()),seen);handleFriendItem(es,e.getKey(),e.getValue(),"holding",GearInfoUtil.getHeldGear(mc,e.getKey()),seen);}
        java.util.Iterator<Map.Entry<String,FriendItemPresence>>it=activeItemMatches.entrySet().iterator();while(it.hasNext()){Map.Entry<String,FriendItemPresence>e=it.next();if(seen.contains(e.getKey()))continue;FriendItemPresence old=e.getValue();if(!nowPlayers.containsKey(old.uuid)&&!isUuidStillInLobby(old.uuid))friendItemLeft(es,old);it.remove();}
    }
    private void handleFriendItem(EnchantSettingsManager es,UUID uuid,String player,String slot,GearInfoUtil.GearData gear,java.util.Set<String>seen){String key=uuid+"|"+slot;FriendItemPresence old=activeItemMatches.get(key);if(gear==null||gear.isEmpty()){if(old!=null)seen.add(key);return;}List<FriendMatch>m=friendMatches(gear,"wearing".equals(slot));if(m.isEmpty()){activeItemMatches.remove(key);return;}seen.add(key);FriendItemPresence now=new FriendItemPresence(uuid,player,slot,gear.signature,m);if(old==null||!old.signature.equals(now.signature)){activeItemMatches.put(key,now);friendItemJoined(es,now);}else activeItemMatches.put(key,now);}
    private List<FriendMatch>friendMatches(GearInfoUtil.GearData gear,boolean leggings){List<FriendMatch>o=new ArrayList<FriendMatch>();for(String c:EnchantRegistry.categories()){if(leggings&&!EnchantRegistry.isLeggingsCategory(c))continue;if(!leggings&&!EnchantRegistry.isHeldCategory(c))continue;for(String e:EnchantRegistry.enchantsFor(c)){String l=GearInfoUtil.findEnchantTierLine(gear.enchants,e);if(l!=null)o.add(new FriendMatch(c,e,l));}}return o;}
    private void friendItemJoined(EnchantSettingsManager es,FriendItemPresence p){FriendMatch ping=null;boolean lp=false,lc=false;List<String>chatLines=new ArrayList<String>();String colour="a";for(FriendMatch m:p.matches){if(es.isJoinPingEnabled("Friendlist",m.category,m.enchant)){if(ping==null)ping=m;lp|=es.isThrottlePingEnabled("Friendlist",m.category,m.enchant);}if(es.isJoinChatEnabled("Friendlist",m.category,m.enchant)){if(chatLines.isEmpty())colour=es.getJoinColour("Friendlist",m.category,m.enchant);chatLines.add(friendFormat(m));lc|=es.isThrottleChatEnabled("Friendlist",m.category,m.enchant);}}AlertThrottleManager t=throttle();String ev=p.uuid+"|"+p.slot+"|"+p.signature;if(ping!=null&&(t==null||t.allowPing("Friendlist",ev,lp)))sound(es.getJoinSound("Friendlist",ping.category,ping.enchant),es.getJoinVolumeFloat("Friendlist",ping.category,ping.enchant),1.35f);if(!chatLines.isEmpty()&&(t==null||t.allowChat("Friendlist",ev,lc)))chat("\u00A7"+colour+"[Friends] \u00A7f"+p.player+" \u00A7"+colour+"is "+p.slot+" "+friendJoin(chatLines)+".");}
    private void friendItemLeft(EnchantSettingsManager es,FriendItemPresence p){FriendMatch ping=null;boolean lp=false,lc=false;List<String>chatLines=new ArrayList<String>();String colour="e";for(FriendMatch m:p.matches){if(es.isLeavePingEnabled("Friendlist",m.category,m.enchant)){if(ping==null)ping=m;lp|=es.isThrottlePingEnabled("Friendlist",m.category,m.enchant);}if(es.isLeaveChatEnabled("Friendlist",m.category,m.enchant)){if(chatLines.isEmpty())colour=es.getLeaveColour("Friendlist",m.category,m.enchant);chatLines.add(friendFormat(m));lc|=es.isThrottleChatEnabled("Friendlist",m.category,m.enchant);}}AlertThrottleManager t=throttle();String ev="leave|"+p.uuid+"|"+p.slot+"|"+p.signature;if(ping!=null&&(t==null||t.allowPing("Friendlist",ev,lp)))sound(es.getLeaveSound("Friendlist",ping.category,ping.enchant),es.getLeaveVolumeFloat("Friendlist",ping.category,ping.enchant),0.65f);if(!chatLines.isEmpty()&&(t==null||t.allowChat("Friendlist",ev,lc)))chat("\u00A7"+colour+"[Friends] \u00A7f"+p.player+" \u00A7"+colour+"left while "+p.slot+" "+friendJoin(chatLines)+".");}
    private String friendFormat(FriendMatch m){EnchantRegistry.Definition d=EnchantRegistry.definition(m.category,m.enchant);return(d!=null&&d.rare?"\u00A7dRARE! \u00A7f":"")+m.line;}private String friendJoin(List<String>x){StringBuilder b=new StringBuilder();for(String s:x){if(b.length()>0)b.append("\u00A77, \u00A7f");b.append(s);}return b.toString();}
    private boolean isUuidStillInLobby(UUID uuid){if(uuid==null||mc.func_147114_u()==null)return false;try{Collection<NetworkPlayerInfo> infos=mc.func_147114_u().func_175106_d();if(infos==null)return false;int checked=0;for(NetworkPlayerInfo info:infos){if(++checked>1000)break;if(info==null)continue;GameProfile p=info.func_178845_a();if(p!=null&&uuid.equals(p.getId()))return true;}}catch(RuntimeException ignored){}return false;}
    private EnchantSettingsManager enchantSettings(){LobbyWatcher w=BlacklistedLobbyWatcher.getLobbyWatcher();return w==null?null:w.getEnchantSettingsManager();}private AlertThrottleManager throttle(){LobbyWatcher w=BlacklistedLobbyWatcher.getLobbyWatcher();return w==null?null:w.getAlertThrottleManager();}
    private static final class FriendMatch{final String category,enchant,line;FriendMatch(String c,String e,String l){category=c;enchant=e;line=l;}}
    private static final class FriendItemPresence{final UUID uuid;final String player,slot,signature;final List<FriendMatch>matches;FriendItemPresence(UUID u,String p,String s,String sig,List<FriendMatch>m){uuid=u;player=p==null?"Unknown":p;slot=s;signature=sig==null?"":sig;matches=new ArrayList<FriendMatch>(m);}}

    private void joined(String name) {
        AlertThrottleManager t=throttle(); String ev="join|"+name;
        if (manager.isJoinChatEnabled() && (t==null||t.allowChat("Friendlist",ev,false))) chat("\u00A7a[Friends] \u00A7f" + name + " \u00A7ahas joined the lobby.");
        if (manager.isJoinPingEnabled() && (t==null||t.allowPing("Friendlist",ev,false))) sound(manager.getJoinSound(), manager.getJoinVolumeFloat(), 1.35f);
    }

    private void left(String name) {
        AlertThrottleManager t=throttle(); String ev="leave|"+name;
        if (manager.isLeaveChatEnabled() && (t==null||t.allowChat("Friendlist",ev,false))) chat("\u00A7e[Friends] \u00A7f" + name + " \u00A7eleft the lobby.");
        if (manager.isLeavePingEnabled() && (t==null||t.allowPing("Friendlist",ev,false))) sound(manager.getLeaveSound(), manager.getLeaveVolumeFloat(), 0.65f);
    }

    private void sound(String soundId, float volume, float pitch) {
        if (mc.field_71439_g == null || volume <= 0.0F) return;
        try { mc.field_71439_g.func_85030_a(SoundChoice.sanitize(soundId), OverallSettingsManager.applyGlobalVolume(volume), pitch); }
        catch (RuntimeException ignored) { }
    }

    public void previewJoinPing() { sound(manager.getJoinSound(), manager.getJoinVolumeFloat(), 1.35f); }
    public void previewLeavePing() { sound(manager.getLeaveSound(), manager.getLeaveVolumeFloat(), 0.65f); }

    private void chat(String s) {
        if (mc.field_71439_g != null) mc.field_71439_g.func_145747_a(new ChatComponentText(s));
    }

    private String formatted(NetworkPlayerInfo info, GameProfile profile) {
        try {
            IChatComponent c = info.func_178854_k();
            if (c != null && c.func_150254_d() != null) return trim(c.func_150254_d(), profile.getName());
        } catch (RuntimeException ignored) { }
        try {
            return trim(ScorePlayerTeam.func_96667_a(info.func_178850_i(), profile.getName()), profile.getName());
        } catch (RuntimeException ignored) {
            return profile.getName();
        }
    }

    private String trim(String s, String fallback) {
        if (s == null || s.isEmpty()) return fallback;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length() && b.length() < 128; i++) {
            char c = s.charAt(i);
            if (c >= 32 && c != 127) b.append(c);
        }
        return b.length() == 0 ? fallback : b.toString();
    }

    public FriendListManager getManager() { return manager; }
}
