package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** Main OmenaMod menu and HUD editor. */
public class BlacklistedLobbyMenu extends GuiScreen {
    private final BlacklistManager blacklistManager;
    private final LobbyWatcher lobbyWatcher;
    private final FriendListWatcher friendListWatcher;
    private String friendStatus = "";

    private String selectedHudKey;
    private int selectedHudSource; // 1=list/mystic, 2=friend
    private String draggingHudKey;
    private int draggingHudSource;
    private int dragOffsetX, dragOffsetY;
    private int resizeEdge;
    private int[] resizeStartBounds;
    private float resizeStartScale;

    public BlacklistedLobbyMenu(BlacklistManager blacklistManager, LobbyWatcher lobbyWatcher) {
        this.blacklistManager=blacklistManager; this.lobbyWatcher=lobbyWatcher; this.friendListWatcher=BlacklistedLobbyWatcher.getFriendListWatcher();
    }

    @Override public void func_73866_w_() {
        int cx=field_146294_l/2,cy=field_146295_m/2;
        field_146292_n.add(new GuiButton(1,cx-100,cy-48,200,20,"\u00A7bBlacklist Settings"));
        field_146292_n.add(new GuiButton(2,cx-100,cy-20,200,20,"\u00A7aFriendlist"));
        field_146292_n.add(new GuiButton(3,cx-100,cy+8,200,20,"\u00A7dMystic Watcher"));
        field_146292_n.add(new GuiButton(4,cx-100,cy+36,200,20,"\u00A7eOverall Settings"));
        field_146292_n.add(new GuiButton(0,cx-100,cy+68,200,20,"\u00A77Close"));
        lobbyWatcher.clampAllHudsToScreen(field_146294_l,field_146295_m,field_146289_q);
        try{if(friendListWatcher!=null&&friendListWatcher.isOnPitClassic())friendListWatcher.clampHudsToScreen(field_146294_l,field_146295_m,field_146289_q);}catch(Throwable ignored){}
        lobbyWatcher.saveHudPosition();
    }

    @Override public void func_73863_a(int mouseX,int mouseY,float partialTicks) {
        if(draggingHudKey!=null){if(resizeEdge!=0)resizeDraggedHud(mouseX,mouseY);else moveDraggedHud(mouseX,mouseY);}
        OmenaUi.background(field_146294_l,field_146295_m);
        int cx=field_146294_l/2,cy=field_146295_m/2;
        OmenaUi.panel(cx-122,cy-102,cx+122,cy+96);
        OmenaUi.centered(field_146289_q,field_146294_l,"\u00A7b\u00A7lOmenaMod",cy-88);
        OmenaUi.centered(field_146289_q,field_146294_l,"\u00A7eMade for Pit Classic by Muruseni",cy-72);
        OmenaUi.divider(cx-104,cx+104,cy-61);
        OmenaUi.centered(field_146289_q,field_146294_l,"\u00A78v"+BlacklistedLobbyWatcher.VERSION+"  \u00A77|  Click a HUD preview to edit it",cy+91);
        if(!friendStatus.isEmpty())OmenaUi.centered(field_146289_q,field_146294_l,friendStatus,cy+111);
        super.func_73863_a(mouseX,mouseY,partialTicks);
        lobbyWatcher.drawAllHudPreviews(field_146289_q,selectedHudSource==1?selectedHudKey:null);
        try{if(friendListWatcher!=null)friendListWatcher.drawHudPreviews(field_146289_q,selectedHudSource==2?selectedHudKey:null);}catch(Throwable ignored){}
        if(selectedHudKey!=null)OmenaUi.centered(field_146289_q,field_146294_l,"\u00A7bSelected HUD  \u00A78-  drag inside to move, drag border to resize",field_146295_m-16);
    }

    @Override protected void func_73864_a(int mouseX,int mouseY,int mouseButton) {
        if(mouseButton==0){
            if(selectedHudKey!=null){int edge=getResizeEdge(selectedHudSource,selectedHudKey,mouseX,mouseY);if(edge!=0){startResize(selectedHudSource,selectedHudKey,edge);return;}}
            String key=null;int source=0;
            if(friendListWatcher!=null&&friendListWatcher.isOnPitClassic()){key=friendListWatcher.findHudAtPoint(field_146289_q,mouseX,mouseY);if(key!=null)source=2;}
            if(key==null){key=lobbyWatcher.findHudAtPoint(field_146289_q,mouseX,mouseY);if(key!=null)source=1;}
            if(key!=null){selectedHudKey=key;selectedHudSource=source;int edge=getResizeEdge(source,key,mouseX,mouseY);if(edge!=0){startResize(source,key,edge);}else{draggingHudKey=key;draggingHudSource=source;dragOffsetX=mouseX-getHudX(source,key);dragOffsetY=mouseY-getHudY(source,key);}return;}
            selectedHudKey=null;selectedHudSource=0;
        }
        super.func_73864_a(mouseX,mouseY,mouseButton);
    }

    private void startResize(int source,String key,int edge){draggingHudSource=source;draggingHudKey=key;resizeEdge=edge;resizeStartBounds=getBounds(source,key);resizeStartScale=getScale(source,key);}
    @Override protected void func_146273_a(int mouseX,int mouseY,int button,long elapsed){if(draggingHudKey!=null&&button==0){if(resizeEdge!=0)resizeDraggedHud(mouseX,mouseY);else moveDraggedHud(mouseX,mouseY);return;}super.func_146273_a(mouseX,mouseY,button,elapsed);}
    @Override protected void func_146286_b(int mouseX,int mouseY,int state){if(draggingHudKey!=null&&state==0){if(resizeEdge!=0)resizeDraggedHud(mouseX,mouseY);else moveDraggedHud(mouseX,mouseY);draggingHudKey=null;draggingHudSource=0;resizeEdge=0;resizeStartBounds=null;lobbyWatcher.saveHudPosition();if(friendListWatcher!=null)friendListWatcher.saveHudPositions();return;}super.func_146286_b(mouseX,mouseY,state);}

    private void moveDraggedHud(int mx,int my){if(draggingHudKey==null)return;setPosition(draggingHudSource,draggingHudKey,mx-dragOffsetX,my-dragOffsetY);}
    private void resizeDraggedHud(int mx,int my){
        if(draggingHudKey==null||resizeStartBounds==null||resizeStartScale<=0)return;
        float baseW=(resizeStartBounds[2]-resizeStartBounds[0])/resizeStartScale,baseH=(resizeStartBounds[3]-resizeStartBounds[1])/resizeStartScale;if(baseW<1||baseH<1)return;
        float hs=resizeStartScale,vs=resizeStartScale;boolean hasH=(resizeEdge&3)!=0,hasV=(resizeEdge&12)!=0;
        if((resizeEdge&1)!=0)hs=(resizeStartBounds[2]-mx)/baseW;else if((resizeEdge&2)!=0)hs=(mx-resizeStartBounds[0])/baseW;
        if((resizeEdge&4)!=0)vs=(resizeStartBounds[3]-my)/baseH;else if((resizeEdge&8)!=0)vs=(my-resizeStartBounds[1])/baseH;
        float proposed=hasH&&hasV?(Math.abs(hs-resizeStartScale)>=Math.abs(vs-resizeStartScale)?hs:vs):(hasH?hs:vs);
        setScale(draggingHudSource,draggingHudKey,proposed);float scale=getScale(draggingHudSource,draggingHudKey);
        float left=((resizeEdge&1)!=0)?resizeStartBounds[2]-baseW*scale:resizeStartBounds[0];
        float top=((resizeEdge&4)!=0)?resizeStartBounds[3]-baseH*scale:resizeStartBounds[1];
        int x=Math.round(left+4F*scale),y=Math.round(top+4F*scale);setPosition(draggingHudSource,draggingHudKey,x,y);
    }

    private int getResizeEdge(int source,String key,int x,int y){return source==2&&friendListWatcher!=null?friendListWatcher.getHudResizeEdge(field_146289_q,key,x,y):lobbyWatcher.getHudResizeEdge(field_146289_q,key,x,y);}
    private int[]getBounds(int source,String key){return source==2&&friendListWatcher!=null?friendListWatcher.getHudBounds(field_146289_q,key):lobbyWatcher.getHudBounds(field_146289_q,key);}
    private int getHudX(int source,String key){return source==2&&friendListWatcher!=null?friendListWatcher.getHudX(key):lobbyWatcher.getHudX(key);} private int getHudY(int source,String key){return source==2&&friendListWatcher!=null?friendListWatcher.getHudY(key):lobbyWatcher.getHudY(key);}
    private float getScale(int source,String key){return source==2&&friendListWatcher!=null?friendListWatcher.getHudScale(key):lobbyWatcher.getHudScale(key);} private void setScale(int source,String key,float s){if(source==2&&friendListWatcher!=null)friendListWatcher.setHudScale(key,s);else lobbyWatcher.setHudScale(key,s);}
    private void setPosition(int source,String key,int x,int y){if(source==2&&friendListWatcher!=null)friendListWatcher.setHudPositionClamped(key,x,y,field_146294_l,field_146295_m,field_146289_q);else lobbyWatcher.setHudPositionClamped(key,x,y,field_146294_l,field_146295_m,field_146289_q);}

    @Override public void func_146281_b(){draggingHudKey=null;draggingHudSource=0;resizeEdge=0;lobbyWatcher.saveHudPosition();if(friendListWatcher!=null)friendListWatcher.saveHudPositions();}
    @Override protected void func_146284_a(GuiButton b){if(b.field_146127_k==1)field_146297_k.func_147108_a(new BlacklistSettingsScreen(this,blacklistManager,lobbyWatcher));else if(b.field_146127_k==2){if(friendListWatcher!=null&&friendListWatcher.isOnPitClassic()){friendStatus="";field_146297_k.func_147108_a(new FriendListScreen(this,friendListWatcher));}else friendStatus="\u00A7cYou must be on Pit Classic (pitclassic.net) to use this feature.";}else if(b.field_146127_k==3)field_146297_k.func_147108_a(new MysticWatcherScreen(this,lobbyWatcher));else if(b.field_146127_k==4)field_146297_k.func_147108_a(new OverallSettingsScreen(this,lobbyWatcher));else if(b.field_146127_k==0)field_146297_k.func_147108_a(null);}
}
