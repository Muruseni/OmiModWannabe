package com.example.blacklistedlobbywatcher;
import net.minecraft.client.gui.Gui;import net.minecraft.client.gui.GuiButton;import net.minecraft.client.gui.GuiScreen;
public class FriendPingsSettingsScreen extends GuiScreen{
 private final GuiScreen parent;private final FriendListManager manager;private final AlertThrottleManager throttle;
 public FriendPingsSettingsScreen(GuiScreen p,FriendListWatcher w){parent=p;manager=w.getManager();LobbyWatcher lw=BlacklistedLobbyWatcher.getLobbyWatcher();throttle=lw==null?null:lw.getAlertThrottleManager();}
 @Override public void func_73866_w_(){int cx=field_146294_l/2,top=Math.max(58,field_146295_m/2-62);field_146292_n.add(new GuiButton(1,cx-105,top,210,20,"Join / detected ping: "+on(manager.isJoinPingEnabled())));field_146292_n.add(new GuiButton(2,cx-105,top+26,210,20,"Leave ping: "+on(manager.isLeavePingEnabled())));field_146292_n.add(new GuiButton(3,cx-105,top+52,210,20,"Throttle pings: "+on(throttle!=null&&throttle.isPingThrottle("Friendlist"))));field_146292_n.add(new GuiButton(0,cx-105,top+84,210,20,"Back"));}
 @Override public void func_73863_a(int x,int y,float p){OmenaUi.background(field_146294_l,field_146295_m);center("\u00A7a\u00A7lFriendlist Pings",24);center("\u00A77Ping enable / throttle settings",40);super.func_73863_a(x,y,p);}
 @Override protected void func_146284_a(GuiButton b){if(b.field_146127_k==0){manager.save();field_146297_k.func_147108_a(parent);return;}if(b.field_146127_k==1)manager.setJoinPingEnabled(!manager.isJoinPingEnabled());else if(b.field_146127_k==2)manager.setLeavePingEnabled(!manager.isLeavePingEnabled());else if(b.field_146127_k==3&&throttle!=null)throttle.setPingThrottle("Friendlist",!throttle.isPingThrottle("Friendlist"));field_146292_n.clear();func_73866_w_();}
 private String on(boolean v){return v?"ON":"OFF";}private void center(String s,int y){field_146289_q.func_78276_b(s,(field_146294_l-field_146289_q.func_78256_a(s))/2,y,0xFFFFFF);}
}
