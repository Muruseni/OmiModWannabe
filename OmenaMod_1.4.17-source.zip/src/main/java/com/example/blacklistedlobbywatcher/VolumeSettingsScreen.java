package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** Mouse-draggable join/leave ping volume sliders for one selected list. */
public class VolumeSettingsScreen extends GuiScreen {
    private static final int BUTTON_BACK = 0;
    private static final int BUTTON_PREVIEW_JOIN = 1;
    private static final int BUTTON_PREVIEW_LEAVE = 2;
    private static final int BUTTON_RESET = 3;
    private static final int SLIDER_WIDTH = 200;
    private static final int SLIDER_HEIGHT = 12;

    private final GuiScreen parent;
    private final LobbyWatcher watcher;
    private final SoundSettingsManager sounds;
    private final String listName;
    private int draggingSlider;

    public VolumeSettingsScreen(GuiScreen parent, LobbyWatcher watcher, String listName) {
        this.parent = parent;
        this.watcher = watcher;
        this.sounds = watcher.getSoundSettingsManager();
        this.listName = listName == null ? "Blacklist" : listName;
    }

    @Override
    public void func_73866_w_() {
        int cx = this.field_146294_l / 2;
        int top = this.field_146295_m / 2 - 78;
        this.field_146292_n.add(new GuiButton(BUTTON_PREVIEW_JOIN, cx + 55, top + 34, 45, 18, "Preview"));
        this.field_146292_n.add(new GuiButton(BUTTON_PREVIEW_LEAVE, cx + 55, top + 94, 45, 18, "Preview"));
        this.field_146292_n.add(new GuiButton(BUTTON_RESET, cx - 100, top + 124, 95, 20, "Reset to 50%"));
        this.field_146292_n.add(new GuiButton(BUTTON_BACK, cx + 5, top + 124, 95, 20, "Back"));
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        if (draggingSlider != 0) updateSlider(draggingSlider, mouseX);
        OmenaUi.background(this.field_146294_l,this.field_146295_m);
        int cx = this.field_146294_l / 2;
        int top = this.field_146295_m / 2 - 78;
        drawCentered("\u00A7b\u00A7l" + listName + " Volume", top - 28, 0xFFFFFF);
        drawCentered("\u00A7750% is normal ping volume.", top - 12, 0xFFFFFF);
        this.field_146289_q.func_78276_b("\u00A7fJoin / detected: \u00A7b" + sounds.getJoinVolume(listName) + "%", cx - 100, top + 8, 0xFFFFFF);
        drawSlider(cx - 100, top + 34, sounds.getJoinVolume(listName));
        this.field_146289_q.func_78276_b("\u00A7fLeave: \u00A7b" + sounds.getLeaveVolume(listName) + "%", cx - 100, top + 68, 0xFFFFFF);
        drawSlider(cx - 100, top + 94, sounds.getLeaveVolume(listName));
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    private void drawSlider(int x, int y, int value) {
        int usableWidth = SLIDER_WIDTH - 50;
        Gui.func_73734_a(x, y + 4, x + usableWidth, y + 8, 0xFF555555);
        int filled = Math.round(usableWidth * (value / 100.0F));
        Gui.func_73734_a(x, y + 4, x + filled, y + 8, 0xFFCC3333);
        int knobX = x + filled;
        Gui.func_73734_a(knobX - 3, y, knobX + 3, y + SLIDER_HEIGHT, 0xFFFFFFFF);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0) {
            int cx = this.field_146294_l / 2;
            int top = this.field_146295_m / 2 - 78;
            if (insideSlider(mouseX, mouseY, cx - 100, top + 34)) { draggingSlider = 1; updateSlider(1, mouseX); return; }
            if (insideSlider(mouseX, mouseY, cx - 100, top + 94)) { draggingSlider = 2; updateSlider(2, mouseX); return; }
        }
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (draggingSlider != 0 && clickedMouseButton == 0) { updateSlider(draggingSlider, mouseX); return; }
        super.func_146273_a(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
    }

    @Override
    protected void func_146286_b(int mouseX, int mouseY, int state) {
        if (draggingSlider != 0 && state == 0) { updateSlider(draggingSlider, mouseX); draggingSlider = 0; sounds.save(); return; }
        super.func_146286_b(mouseX, mouseY, state);
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        int id = button.field_146127_k;
        if (id == BUTTON_PREVIEW_JOIN) watcher.previewJoinPing(listName);
        else if (id == BUTTON_PREVIEW_LEAVE) watcher.previewLeavePing(listName);
        else if (id == BUTTON_RESET) { sounds.resetDefaults(listName); sounds.save(); }
        else if (id == BUTTON_BACK) { sounds.save(); this.field_146297_k.func_147108_a(parent); }
    }

    @Override public void func_146281_b() { draggingSlider = 0; sounds.save(); }
    private boolean insideSlider(int mouseX, int mouseY, int x, int y) {
        return mouseX >= x - 4 && mouseX <= x + (SLIDER_WIDTH - 50) + 4 && mouseY >= y - 4 && mouseY <= y + SLIDER_HEIGHT + 4;
    }
    private void updateSlider(int slider, int mouseX) {
        int x = this.field_146294_l / 2 - 100;
        int usableWidth = SLIDER_WIDTH - 50;
        int clamped = Math.max(x, Math.min(x + usableWidth, mouseX));
        int value = Math.round(((clamped - x) / (float) usableWidth) * 100.0F);
        if (slider == 1) sounds.setJoinVolume(listName, value); else if (slider == 2) sounds.setLeaveVolume(listName, value);
    }
    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
