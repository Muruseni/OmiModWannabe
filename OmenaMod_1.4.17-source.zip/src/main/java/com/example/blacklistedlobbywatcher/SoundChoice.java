package com.example.blacklistedlobbywatcher;

/** Allowlisted vanilla Minecraft 1.8.9 client sound choices used by OmenaMod alerts. */
public final class SoundChoice {
    private static final String[] LABELS = {
            "Pling", "Harp", "Bass", "Snare", "Orb", "Click", "Pop"
    };
    private static final String[] IDS = {
            "note.pling", "note.harp", "note.bass", "note.snare", "random.orb", "random.click", "random.pop"
    };
    public static final String DEFAULT_ID = "note.pling";

    private SoundChoice() { }

    public static int size() { return IDS.length; }

    public static int indexOf(String id) {
        String safe = sanitize(id);
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(safe)) return i;
        return 0;
    }

    public static String idAt(int index) {
        if (index < 0) index = 0;
        if (index >= IDS.length) index = IDS.length - 1;
        return IDS[index];
    }

    public static String sanitize(String id) {
        if (id == null) return DEFAULT_ID;
        for (String allowed : IDS) if (allowed.equals(id)) return allowed;
        return DEFAULT_ID;
    }

    public static String labelFor(String id) {
        String safe = sanitize(id);
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(safe)) return LABELS[i];
        return LABELS[0];
    }

    public static String next(String id) {
        String safe = sanitize(id);
        for (int i = 0; i < IDS.length; i++) {
            if (IDS[i].equals(safe)) return IDS[(i + 1) % IDS.length];
        }
        return DEFAULT_ID;
    }

    public static String previous(String id) {
        String safe = sanitize(id);
        for (int i = 0; i < IDS.length; i++) {
            if (IDS[i].equals(safe)) return IDS[(i + IDS.length - 1) % IDS.length];
        }
        return DEFAULT_ID;
    }
}
