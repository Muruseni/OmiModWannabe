package com.example.blacklistedlobbywatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Properties;

/** Stores client-only alert feature toggles independently for each list. */
public class FeatureSettingsManager {
    private static final long MAX_CONFIG_BYTES = 64L * 1024L;
    private static final String PRIMARY = "Blacklist";

    private final File file;
    private final Properties values = new Properties();

    public FeatureSettingsManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher_features.properties");
    }

    public void load() {
        values.clear();
        if (!file.exists()) return;
        if (!file.isFile() || file.length() > MAX_CONFIG_BYTES) {
            System.err.println("[OmenaMod] Ignoring oversized or invalid feature config.");
            return;
        }
        FileInputStream input = null;
        try {
            Properties loaded = new Properties();
            input = new FileInputStream(file);
            loaded.load(input);

            // Migrate the pre-1.2.7 global settings to the primary Blacklist only.
            copyLegacyBoolean(loaded, "joinPing", PRIMARY, "joinPing", true);
            copyLegacyBoolean(loaded, "leavePing", PRIMARY, "leavePing", true);
            copyLegacyBoolean(loaded, "joinChat", PRIMARY, "joinChat", true);
            copyLegacyBoolean(loaded, "leaveChat", PRIMARY, "leaveChat", true);

            for (Object rawKey : loaded.keySet()) {
                String key = String.valueOf(rawKey);
                if (!key.startsWith("list.")) continue;
                String value = loaded.getProperty(key);
                if (isBoolean(value)) values.setProperty(key, value.trim().toLowerCase(Locale.ROOT));
            }
        } catch (Exception e) {
            values.clear();
            System.err.println("[OmenaMod] Could not parse feature config; using safe defaults.");
        } finally {
            if (input != null) try { input.close(); } catch (Exception ignored) { }
        }
    }

    private void copyLegacyBoolean(Properties loaded, String oldKey, String listName, String kind, boolean fallback) {
        String newKey = key(listName, kind);
        if (loaded.containsKey(newKey)) return;
        String value = loaded.getProperty(oldKey);
        if (isBoolean(value)) values.setProperty(newKey, value.trim().toLowerCase(Locale.ROOT));
        else values.setProperty(newKey, Boolean.toString(fallback));
    }

    public void save() {
        FileOutputStream output = null;
        File temp = new File(file.getParentFile(), file.getName() + ".tmp");
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return;
            output = new FileOutputStream(temp);
            values.store(output, "OmenaMod per-list alert feature settings");
            output.flush();
            output.close();
            output = null;
            try {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            temp.delete();
            System.err.println("[OmenaMod] Could not save feature config.");
        } finally {
            if (output != null) try { output.close(); } catch (Exception ignored) { }
        }
    }

    private boolean defaultFor(String listName) { return isPrimary(listName); }
    private boolean get(String listName, String kind) {
        String value = values.getProperty(key(listName, kind));
        return isBoolean(value) ? Boolean.parseBoolean(value) : defaultFor(listName);
    }
    private void set(String listName, String kind, boolean enabled) {
        values.setProperty(key(listName, kind), Boolean.toString(enabled));
    }

    public boolean isJoinPingEnabled(String listName) { return get(listName, "joinPing"); }
    public boolean isLeavePingEnabled(String listName) { return get(listName, "leavePing"); }
    public boolean isJoinChatEnabled(String listName) { return get(listName, "joinChat"); }
    public boolean isLeaveChatEnabled(String listName) { return get(listName, "leaveChat"); }
    public void setJoinPingEnabled(String listName, boolean enabled) { set(listName, "joinPing", enabled); }
    public void setLeavePingEnabled(String listName, boolean enabled) { set(listName, "leavePing", enabled); }
    public void setJoinChatEnabled(String listName, boolean enabled) { set(listName, "joinChat", enabled); }
    public void setLeaveChatEnabled(String listName, boolean enabled) { set(listName, "leaveChat", enabled); }

    // Backward-compatible primary Blacklist accessors used elsewhere in the mod.
    public boolean isJoinPingEnabled() { return isJoinPingEnabled(PRIMARY); }
    public boolean isLeavePingEnabled() { return isLeavePingEnabled(PRIMARY); }
    public boolean isJoinChatEnabled() { return isJoinChatEnabled(PRIMARY); }
    public boolean isLeaveChatEnabled() { return isLeaveChatEnabled(PRIMARY); }
    public void setJoinPingEnabled(boolean enabled) { setJoinPingEnabled(PRIMARY, enabled); }
    public void setLeavePingEnabled(boolean enabled) { setLeavePingEnabled(PRIMARY, enabled); }
    public void setJoinChatEnabled(boolean enabled) { setJoinChatEnabled(PRIMARY, enabled); }
    public void setLeaveChatEnabled(boolean enabled) { setLeaveChatEnabled(PRIMARY, enabled); }

    private String key(String listName, String kind) {
        String safe = normalizeListName(listName);
        return "list." + safe.toLowerCase(Locale.ROOT) + "." + kind;
    }
    private String normalizeListName(String listName) {
        if (isPrimary(listName)) return PRIMARY;
        if (AdditionalListManager.isValidListName(listName)) return listName.trim();
        return PRIMARY;
    }
    private boolean isPrimary(String listName) { return listName == null || PRIMARY.equalsIgnoreCase(listName.trim()); }
    private boolean isBoolean(String value) { return value != null && ("true".equalsIgnoreCase(value.trim()) || "false".equalsIgnoreCase(value.trim())); }
}
