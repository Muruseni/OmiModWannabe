package com.example.blacklistedlobbywatcher;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Shows a one-time local message if OmenaMod access is denied. */
public final class AccessDeniedNotifier {
    private final String username;
    private boolean shown;

    public AccessDeniedNotifier(String username) {
        this.username = username == null || username.trim().isEmpty() ? "this account" : username.trim();
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (shown || event == null || event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.func_71410_x();
        if (mc == null || mc.field_71439_g == null) return;
        mc.field_71439_g.func_145747_a(new ChatComponentText("\u00A7c[OmenaMod] Access denied for " + username + "."));
        shown = true;
    }
}
