package com.example.blacklistedlobbywatcher;
import net.minecraft.client.gui.Gui;import net.minecraft.client.gui.GuiButton;import net.minecraft.client.gui.GuiScreen;import java.util.*;
public class MysticOmitScreen extends GuiScreen{
 private final GuiScreen parent;private final LobbyWatcher watcher;private final MysticWatcherManager manager;
 public MysticOmitScreen(GuiScreen p,LobbyWatcher w){parent=p;watcher=w;manager=w.getMysticWatcher().getManager();}
 @Override public void func_73866_w_(){int cx=field_146294_l/2,y=52;List<String>t=targets();for(int i=0;i<t.size();i++){String n=t.get(i);field_146292_n.add(new GuiButton(100+i,cx-100,y+i*24,200,20,n+": "+(manager.isOmitted(n)?"OMITTED":"INCLUDED")));}field_146292_n.add(new GuiButton(0,cx-100,Math.min(field_146295_m-28,y+t.size()*24+8),200,20,"Back"));}
 @Override public void func_73863_a(int x,int y,float p){OmenaUi.background(field_146294_l,field_146295_m);center("\u00A7d\u00A7lMystic Watcher Omissions",18);center("\u00A77Players in omitted lists do not appear in Mystic Watcher.",34);super.func_73863_a(x,y,p);}
 @Override protected void func_146284_a(GuiButton b){if(b.field_146127_k==0){field_146297_k.func_147108_a(parent);return;}int i=b.field_146127_k-100;List<String>t=targets();if(i>=0&&i<t.size()){String n=t.get(i);manager.setOmitted(n,!manager.isOmitted(n));field_146292_n.clear();func_73866_w_();}}
 private List<String>targets(){List<String>x=new ArrayList<String>();x.add("Blacklist");x.addAll(watcher.getAdditionalListManager().getListNames());return x;}private void center(String s,int y){field_146289_q.func_78276_b(s,(field_146294_l-field_146289_q.func_78256_a(s))/2,y,0xFFFFFF);}
}
