package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** Settings for exactly one Blacklist-style list. */
public class SettingsScreen extends GuiScreen {
    private static final int BUTTON_BACK = 0;
    private static final int BUTTON_HUD = 1;
    private static final int BUTTON_ALERTS = 2;
    private static final int BUTTON_COLOURS = 3;
    private static final int BUTTON_VOLUME = 4;
    private static final int BUTTON_SOUNDS = 5;
    private static final int BUTTON_ENCHANTS = 6;

    private final GuiScreen parent;
    private final LobbyWatcher watcher;
    private final FeatureSettingsManager features;
    private final String listName;

    public SettingsScreen(GuiScreen parent, LobbyWatcher watcher, String listName) {
        this.parent = parent;
        this.watcher = watcher;
        this.features = watcher.getFeatureSettingsManager();
        this.listName = normalize(listName);
    }

    @Override public void func_73866_w_() {
        int cx = this.field_146294_l / 2;
        int top = Math.max(45, this.field_146295_m / 2 - 92);
        this.field_146292_n.add(new GuiButton(BUTTON_HUD, cx - 100, top, 200, 20, hudLabel()));
        this.field_146292_n.add(new GuiButton(BUTTON_ALERTS, cx - 100, top + 28, 200, 20, "Alerts"));
        this.field_146292_n.add(new GuiButton(BUTTON_COLOURS, cx - 100, top + 56, 64, 20, "Colours"));
        this.field_146292_n.add(new GuiButton(BUTTON_VOLUME, cx - 32, top + 56, 64, 20, "Volume"));
        this.field_146292_n.add(new GuiButton(BUTTON_SOUNDS, cx + 36, top + 56, 64, 20, "Sounds"));
        this.field_146292_n.add(new GuiButton(BUTTON_ENCHANTS, cx - 100, top + 84, 200, 20, "Enchant Filters"));
        this.field_146292_n.add(new GuiButton(BUTTON_BACK, cx - 100, top + 116, 200, 20, "Back"));
    }

    @Override public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        OmenaUi.background(this.field_146294_l,this.field_146295_m);
        int cx=this.field_146294_l/2; int top=Math.max(45,this.field_146295_m/2-92);
        OmenaUi.panel(cx-116, top-42, cx+116, top+143);
        OmenaUi.pageTitle(this.field_146289_q,this.field_146294_l,listName+" Settings","Changes here only affect this list.",top-31);
        OmenaUi.divider(cx-98,cx+98,top-5);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override protected void func_146284_a(GuiButton button) {
        int id = button.field_146127_k;
        if (id == BUTTON_HUD) {
            setHudEnabled(!isHudEnabled());
            button.field_146126_j = hudLabel();
        } else if (id == BUTTON_ALERTS) {
            features.save(); this.field_146297_k.func_147108_a(new ListAlertsSettingsScreen(this, watcher, listName)); return;
        } else if (id == BUTTON_COLOURS) {
            features.save(); this.field_146297_k.func_147108_a(new ColourSettingsScreen(this, watcher, listName)); return;
        } else if (id == BUTTON_VOLUME) {
            features.save(); this.field_146297_k.func_147108_a(new VolumeSettingsScreen(this, watcher, listName)); return;
        } else if (id == BUTTON_SOUNDS) {
            features.save(); this.field_146297_k.func_147108_a(new SoundSettingsScreen(this, watcher, listName)); return;
        } else if (id == BUTTON_ENCHANTS) {
            features.save(); this.field_146297_k.func_147108_a(new EnchantFiltersScreen(this, watcher, listName)); return;
        } else if (id == BUTTON_BACK) {
            features.save(); this.field_146297_k.func_147108_a(parent); return;
        }
        features.save();
    }

    @Override public void func_146281_b() { features.save(); }
    private boolean isPrimary() { return "Blacklist".equalsIgnoreCase(listName); }
    private boolean isHudEnabled() { return isPrimary() ? watcher.isHudEnabled() : watcher.getAdditionalListManager().isHudEnabled(listName); }
    private void setHudEnabled(boolean enabled) { if (isPrimary()) watcher.setHudEnabled(enabled); else watcher.getAdditionalListManager().setHudEnabled(listName, enabled); }
    private String hudLabel() { return "HUD: " + onOff(isHudEnabled()); }
    private String onOff(boolean enabled) { return enabled ? "ON" : "OFF"; }
    private String normalize(String name) { if (name != null && !"Blacklist".equalsIgnoreCase(name) && watcher.getAdditionalListManager().containsList(name)) return name; return "Blacklist"; }
    private void drawCentered(String text, int y, int color) { int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2; this.field_146289_q.func_78276_b(text, x, y, color); }
}
