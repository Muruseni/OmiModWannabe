package com.example.blacklistedlobbywatcher;

import org.lwjgl.input.Keyboard;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

/** Global, client-only OmenaMod preferences. */
public class OverallSettingsManager {
    private static final long MAX_CONFIG_BYTES = 32L * 1024L;
    private static volatile float globalSoundMultiplier = 1.0F;

    private final File file;
    private int menuKeyCode = Keyboard.KEY_N;
    private int masterSoundPercent = 100;

    public OverallSettingsManager(File configDirectory) {
        this.file = new File(configDirectory, "omenamod_overall.properties");
    }

    public void load() {
        menuKeyCode = Keyboard.KEY_N;
        masterSoundPercent = 100;
        if (file.exists() && file.isFile() && file.length() <= MAX_CONFIG_BYTES) {
            FileInputStream in = null;
            try {
                Properties p = new Properties();
                in = new FileInputStream(file);
                p.load(in);
                menuKeyCode = safeKey(parseInt(p.getProperty("menuKey"), Keyboard.KEY_N));
                masterSoundPercent = clampPercent(parseInt(p.getProperty("masterSoundPercent"), 100));
            } catch (Exception ignored) {
                menuKeyCode = Keyboard.KEY_N;
                masterSoundPercent = 100;
            } finally {
                if (in != null) try { in.close(); } catch (Exception ignored) { }
            }
        }
        globalSoundMultiplier = masterSoundPercent / 100.0F;
    }

    public void save() {
        FileOutputStream out = null;
        File temp = new File(file.getParentFile(), file.getName() + ".tmp");
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return;
            Properties p = new Properties();
            p.setProperty("menuKey", Integer.toString(menuKeyCode));
            p.setProperty("masterSoundPercent", Integer.toString(masterSoundPercent));
            out = new FileOutputStream(temp);
            p.store(out, "OmenaMod overall client settings");
            out.flush(); out.close(); out = null;
            try { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ignored) { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) {
            temp.delete();
        } finally {
            if (out != null) try { out.close(); } catch (Exception ignored) { }
        }
    }

    public int getMenuKeyCode() { return menuKeyCode; }
    public String getMenuKeyName() {
        try {
            String n = Keyboard.getKeyName(menuKeyCode);
            return n == null || n.trim().isEmpty() ? "N" : n;
        } catch (Throwable ignored) { return "N"; }
    }
    public boolean setMenuKeyCode(int code) {
        if (code <= 0 || code == Keyboard.KEY_ESCAPE) return false;
        menuKeyCode = code;
        save();
        return true;
    }
    public boolean setMenuKeyByName(String name) {
        if (name == null || name.trim().isEmpty()) return false;
        try {
            int code = Keyboard.getKeyIndex(name.trim().toUpperCase(java.util.Locale.ROOT));
            return setMenuKeyCode(code);
        } catch (Throwable ignored) { return false; }
    }

    public int getMasterSoundPercent() { return masterSoundPercent; }
    public void setMasterSoundPercent(int percent) {
        masterSoundPercent = clampPercent(percent);
        globalSoundMultiplier = masterSoundPercent / 100.0F;
    }
    public static float applyGlobalVolume(float volume) {
        if (volume <= 0.0F) return 0.0F;
        return Math.max(0.0F, volume * globalSoundMultiplier);
    }

    private int parseInt(String s, int fallback) { try { return Integer.parseInt(s == null ? "" : s.trim()); } catch (Exception ignored) { return fallback; } }
    private int clampPercent(int v) { return Math.max(0, Math.min(100, v)); }
    private int safeKey(int code) { return code > 0 && code != Keyboard.KEY_ESCAPE ? code : Keyboard.KEY_N; }
}
