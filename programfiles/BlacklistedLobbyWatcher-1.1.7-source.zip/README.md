# Blacklisted Lobby Watcher 1.1.7

Minecraft 1.8.9 Forge/Lunar compatibility build, based on the known-good 1.1.3 detection code and the working 1.1.6 join/leave alerts.

## New: Settings -> Volume
Press **N**, then open **Settings**, then **Volume**.

You can independently change:
- **Blacklisted player detected / joined** ping volume
- **Blacklisted player left** ping volume

Each volume can be adjusted from **0% to 100%** in 10% steps. 0% mutes that specific alert. Clicking the center volume button previews the current sound. There is also a **Reset to defaults** button.

The settings are saved locally in:
`config/blacklisted_lobby_watcher_sound.properties`

The existing pitch difference is retained: detected/join alerts use the higher ping, while leave alerts use the lower-tone ping.

## Existing features retained
- Known-good 1.1.3 blacklist detection path
- Client-side join/detected and leave alert sounds from 1.1.6
- Draggable always-visible lobby HUD
- N-key main menu
- Scrollable/sortable blacklist with per-row X removal
- Client-side `/blw`, `/bl`, and `/blacklist` commands
- Security hardening and bounded server-provided TAB text

The sound system is client-side. Changing or previewing the volume does not send a command or custom packet to the server.
