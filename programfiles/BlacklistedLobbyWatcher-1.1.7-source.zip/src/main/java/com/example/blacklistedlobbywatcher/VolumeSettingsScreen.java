package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** Per-alert client-side ping volume controls. */
public class VolumeSettingsScreen extends GuiScreen {
    private final GuiScreen parent;
    private final LobbyWatcher lobbyWatcher;
    private final SoundSettingsManager soundSettings;
    private GuiButton joinValueButton;
    private GuiButton leaveValueButton;

    public VolumeSettingsScreen(GuiScreen parent, LobbyWatcher lobbyWatcher) {
        this.parent = parent;
        this.lobbyWatcher = lobbyWatcher;
        this.soundSettings = lobbyWatcher.getSoundSettingsManager();
    }

    @Override
    public void func_73866_w_() {
        int centerX = this.field_146294_l / 2;
        int top = this.field_146295_m / 2 - 55;

        this.field_146292_n.add(new GuiButton(10, centerX - 100, top + 22, 35, 20, "-"));
        joinValueButton = new GuiButton(11, centerX - 60, top + 22, 120, 20, joinLabel());
        this.field_146292_n.add(joinValueButton);
        this.field_146292_n.add(new GuiButton(12, centerX + 65, top + 22, 35, 20, "+"));

        this.field_146292_n.add(new GuiButton(20, centerX - 100, top + 67, 35, 20, "-"));
        leaveValueButton = new GuiButton(21, centerX - 60, top + 67, 120, 20, leaveLabel());
        this.field_146292_n.add(leaveValueButton);
        this.field_146292_n.add(new GuiButton(22, centerX + 65, top + 67, 35, 20, "+"));

        this.field_146292_n.add(new GuiButton(30, centerX - 100, top + 102, 200, 20, "Reset to defaults"));
        this.field_146292_n.add(new GuiButton(0, centerX - 100, top + 127, 200, 20, "Back"));
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        Gui.func_73734_a(0, 0, this.field_146294_l, this.field_146295_m, 0xD0101010);
        int centerX = this.field_146294_l / 2;
        int top = this.field_146295_m / 2 - 55;

        drawCentered("\u00A7c\u00A7lVolume", top - 30, 0xFFFFFF);
        drawCentered("\u00A77These sounds are local to your client.", top - 14, 0xFFFFFF);

        this.field_146289_q.func_78276_b("\u00A7fBlacklisted player detected / joined", centerX - 100, top + 8, 0xFFFFFF);
        this.field_146289_q.func_78276_b("\u00A7fBlacklisted player left", centerX - 100, top + 53, 0xFFFFFF);

        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        int id = button.field_146127_k;
        if (id == 10) {
            soundSettings.setJoinVolume(soundSettings.getJoinVolume() - 10);
            saveAndRefresh();
        } else if (id == 11) {
            lobbyWatcher.previewJoinPing();
        } else if (id == 12) {
            soundSettings.setJoinVolume(soundSettings.getJoinVolume() + 10);
            saveAndRefresh();
        } else if (id == 20) {
            soundSettings.setLeaveVolume(soundSettings.getLeaveVolume() - 10);
            saveAndRefresh();
        } else if (id == 21) {
            lobbyWatcher.previewLeavePing();
        } else if (id == 22) {
            soundSettings.setLeaveVolume(soundSettings.getLeaveVolume() + 10);
            saveAndRefresh();
        } else if (id == 30) {
            soundSettings.resetDefaults();
            saveAndRefresh();
        } else if (id == 0) {
            soundSettings.save();
            this.field_146297_k.func_147108_a(parent);
        }
    }

    @Override
    public void func_146281_b() {
        soundSettings.save();
    }

    private void saveAndRefresh() {
        soundSettings.save();
        if (joinValueButton != null) joinValueButton.field_146126_j = joinLabel();
        if (leaveValueButton != null) leaveValueButton.field_146126_j = leaveLabel();
    }

    private String joinLabel() {
        return "Join: " + soundSettings.getJoinVolume() + "%";
    }

    private String leaveLabel() {
        return "Leave: " + soundSettings.getLeaveVolume() + "%";
    }

    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
