package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

/** General settings hub. More settings can be added here later. */
public class SettingsScreen extends GuiScreen {
    private final GuiScreen parent;
    private final LobbyWatcher lobbyWatcher;

    public SettingsScreen(GuiScreen parent, LobbyWatcher lobbyWatcher) {
        this.parent = parent;
        this.lobbyWatcher = lobbyWatcher;
    }

    @Override
    public void func_73866_w_() {
        int centerX = this.field_146294_l / 2;
        int centerY = this.field_146295_m / 2;
        this.field_146292_n.add(new GuiButton(1, centerX - 100, centerY - 10, 200, 20, "Volume"));
        this.field_146292_n.add(new GuiButton(0, centerX - 100, centerY + 20, 200, 20, "Back"));
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        Gui.func_73734_a(0, 0, this.field_146294_l, this.field_146295_m, 0xD0101010);
        drawCentered("\u00A7c\u00A7lSettings", this.field_146295_m / 2 - 62, 0xFFFFFF);
        drawCentered("\u00A77Configure Blacklisted Lobby Watcher", this.field_146295_m / 2 - 45, 0xFFFFFF);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == 1) {
            this.field_146297_k.func_147108_a(new VolumeSettingsScreen(this, lobbyWatcher));
        } else if (button.field_146127_k == 0) {
            this.field_146297_k.func_147108_a(parent);
        }
    }

    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
