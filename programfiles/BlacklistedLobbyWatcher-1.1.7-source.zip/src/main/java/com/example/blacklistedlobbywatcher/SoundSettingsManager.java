package com.example.blacklistedlobbywatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/** Stores client-only alert sound volumes separately from blacklist/HUD data. */
public class SoundSettingsManager {
    private static final int DEFAULT_JOIN_VOLUME = 90;
    private static final int DEFAULT_LEAVE_VOLUME = 90;
    private static final long MAX_CONFIG_BYTES = 4096L;

    private final File file;
    private int joinVolume = DEFAULT_JOIN_VOLUME;
    private int leaveVolume = DEFAULT_LEAVE_VOLUME;

    public SoundSettingsManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher_sound.properties");
    }

    public void load() {
        joinVolume = DEFAULT_JOIN_VOLUME;
        leaveVolume = DEFAULT_LEAVE_VOLUME;
        if (!file.exists()) return;
        if (!file.isFile() || file.length() > MAX_CONFIG_BYTES) {
            System.err.println("[BlacklistedLobbyWatcher] Ignoring oversized or invalid sound config.");
            return;
        }

        FileInputStream input = null;
        try {
            Properties properties = new Properties();
            input = new FileInputStream(file);
            properties.load(input);
            joinVolume = parseVolume(properties.getProperty("joinVolume"), DEFAULT_JOIN_VOLUME);
            leaveVolume = parseVolume(properties.getProperty("leaveVolume"), DEFAULT_LEAVE_VOLUME);
        } catch (Exception e) {
            joinVolume = DEFAULT_JOIN_VOLUME;
            leaveVolume = DEFAULT_LEAVE_VOLUME;
            System.err.println("[BlacklistedLobbyWatcher] Could not parse sound config; using defaults.");
        } finally {
            if (input != null) {
                try { input.close(); } catch (Exception ignored) { }
            }
        }
    }

    public void save() {
        FileOutputStream output = null;
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                System.err.println("[BlacklistedLobbyWatcher] Could not create sound config directory.");
                return;
            }

            Properties properties = new Properties();
            properties.setProperty("joinVolume", Integer.toString(joinVolume));
            properties.setProperty("leaveVolume", Integer.toString(leaveVolume));

            output = new FileOutputStream(file);
            properties.store(output, "Blacklisted Lobby Watcher sound settings");
        } catch (Exception e) {
            System.err.println("[BlacklistedLobbyWatcher] Could not save sound config.");
        } finally {
            if (output != null) {
                try { output.close(); } catch (Exception ignored) { }
            }
        }
    }

    private int parseVolume(String value, int fallback) {
        if (value == null) return fallback;
        try {
            return clamp(Integer.parseInt(value.trim()));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private int clamp(int value) {
        if (value < 0) return 0;
        if (value > 100) return 100;
        return value;
    }

    public int getJoinVolume() {
        return joinVolume;
    }

    public int getLeaveVolume() {
        return leaveVolume;
    }

    public float getJoinVolumeFloat() {
        return joinVolume / 100.0F;
    }

    public float getLeaveVolumeFloat() {
        return leaveVolume / 100.0F;
    }

    public void setJoinVolume(int value) {
        joinVolume = clamp(value);
    }

    public void setLeaveVolume(int value) {
        leaveVolume = clamp(value);
    }

    public void resetDefaults() {
        joinVolume = DEFAULT_JOIN_VOLUME;
        leaveVolume = DEFAULT_LEAVE_VOLUME;
    }
}
