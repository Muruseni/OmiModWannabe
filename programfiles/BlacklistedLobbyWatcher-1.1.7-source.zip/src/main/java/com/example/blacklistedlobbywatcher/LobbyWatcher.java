package com.example.blacklistedlobbywatcher;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class LobbyWatcher {
    private static final int STATUS_UNKNOWN = 0;
    private static final int STATUS_EMPTY_BLACKLIST = 1;
    private static final int STATUS_EMPTY_LOBBY = 2;
    private static final int STATUS_CLEAR = 3;
    private static final int STATUS_DETECTED = 4;
    private static final int STATUS_DELAY_CHECKS = 8;
    private static final int MENU_KEY = Keyboard.KEY_N;

    /** Defensive limits for data originating from a multiplayer server. */
    private static final int MAX_TAB_PLAYERS_SCANNED = 1000;
    private static final int MAX_TAB_TEXT_CHARS = 128;
    private static final int MAX_HUD_ENTRIES = 32;
    private static final int MAX_COMMAND_LIST_ENTRIES = 20;
    private static final int MAX_STATUS_MATCHES = 32;
    private static final int MAX_CHAT_MESSAGE_CHARS = 512;

    private final Minecraft mc;
    private final BlacklistManager blacklistManager;
    private final HudPositionManager hudPositionManager;
    private final SoundSettingsManager soundSettingsManager;
    /** UUID -> sanitized formatted TAB-list text, including server prefix/suffix/color codes. */
    private final Map<UUID, String> detectedPlayers = new LinkedHashMap<UUID, String>();
    /** UUID -> profile name; only presence is used to avoid repeated alerts. */
    private final Map<UUID, String> previousPlayers = new LinkedHashMap<UUID, String>();
    private int tickCounter;
    private int connectedChecks;
    private int lastStatus = STATUS_UNKNOWN;
    private int lastLobbyPlayerCount = -1;
    private boolean menuKeyWasDown;
    /** Used only to recognize genuine world/lobby changes so alerts can fire again in a new lobby. */
    private WorldClient lastWorld;

    public LobbyWatcher(Minecraft mc, BlacklistManager blacklistManager) {
        this.mc = mc;
        this.blacklistManager = blacklistManager;
        this.hudPositionManager = new HudPositionManager(blacklistManager.getConfigDirectory());
        this.hudPositionManager.load();
        this.soundSettingsManager = new SoundSettingsManager(blacklistManager.getConfigDirectory());
        this.soundSettingsManager.load();
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event == null || event.phase != TickEvent.Phase.END) return;

        handleMenuKey();

        if (++tickCounter < 5) return;
        tickCounter = 0;

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            resetConnectionState();
            return;
        }

        // A fresh WorldClient is a strong client-side signal that we entered a new lobby/world.
        // Reset only the alert-presence state so blacklisted players can ping again in the new lobby.
        if (mc.field_71441_e != lastWorld) {
            beginNewLobby(mc.field_71441_e);
        }

        connectedChecks++;

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        lastLobbyPlayerCount = playerInfo == null ? 0 : playerInfo.size();

        if (blacklistManager.isEmpty()) {
            detectedPlayers.clear();
            previousPlayers.clear();
            announceStatus(STATUS_EMPTY_BLACKLIST,
                    "\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
            return;
        }

        Map<UUID, String> currentBlacklisted = new LinkedHashMap<UUID, String>();
        Map<UUID, String> currentProfileNames = new LinkedHashMap<UUID, String>();

        if (playerInfo == null || playerInfo.isEmpty()) {
            detectedPlayers.clear();
            previousPlayers.clear();
            announceStatus(STATUS_EMPTY_LOBBY,
                    "\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        int scanned = 0;
        for (NetworkPlayerInfo info : playerInfo) {
            if (++scanned > MAX_TAB_PLAYERS_SCANNED) break;
            if (info == null) continue;

            GameProfile profile;
            try {
                profile = info.func_178845_a();
            } catch (RuntimeException ignored) {
                continue;
            }
            if (profile == null) continue;

            UUID uuid = profile.getId();
            String name = profile.getName();
            if (uuid == null || !BlacklistManager.isValidPlayerName(name)) continue;

            if (blacklistManager.contains(name)) {
                String tabText = getFormattedTabText(info, profile);
                currentBlacklisted.put(uuid, tabText);
                currentProfileNames.put(uuid, name);
                if (!previousPlayers.containsKey(uuid)) alert(tabText);
            }
        }

        // Players that were blacklisted in the previous scan but are no longer in TAB have left.
        // Do not announce a removal caused by the user taking someone off the blacklist.
        for (Map.Entry<UUID, String> previous : previousPlayers.entrySet()) {
            UUID uuid = previous.getKey();
            String profileName = previous.getValue();
            if (!currentProfileNames.containsKey(uuid) && blacklistManager.contains(profileName)) {
                String oldTabText = detectedPlayers.get(uuid);
                alertLeft(oldTabText == null ? profileName : oldTabText);
            }
        }

        detectedPlayers.clear();
        detectedPlayers.putAll(currentBlacklisted);
        previousPlayers.clear();
        previousPlayers.putAll(currentProfileNames);

        if (currentBlacklisted.isEmpty()) {
            announceStatus(STATUS_CLEAR,
                    "\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
        } else {
            lastStatus = STATUS_DETECTED;
        }
    }

    private void handleMenuKey() {
        boolean down = Keyboard.isKeyDown(MENU_KEY);
        if (down && !menuKeyWasDown && mc.field_71439_g != null && mc.field_71462_r == null) {
            mc.func_147108_a(new BlacklistedLobbyMenu(blacklistManager, this));
        }
        menuKeyWasDown = down;
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
        if (mc.field_71439_g == null || mc.field_71466_p == null) return;
        if (mc.field_71462_r instanceof BlacklistedLobbyMenu) return;
        drawHud(mc.field_71466_p);
    }

    public void drawHud(FontRenderer font) {
        if (font == null) return;

        List<String> lines = getHudLines();
        int x = hudPositionManager.getX();
        int y = hudPositionManager.getY();
        int width = getHudContentWidth(font, lines);
        int height = getHudHeight(lines);

        Gui.func_73734_a(x - 4, y - 4, x + width + 5, y + height, 0x90000000);
        for (int i = 0; i < lines.size(); i++) {
            font.func_78276_b(lines.get(i), x, y + i * 10, 0xFFFFFF);
        }
    }

    public boolean isPointInsideHud(FontRenderer font, int mouseX, int mouseY) {
        if (font == null) return false;
        List<String> lines = getHudLines();
        int x = hudPositionManager.getX();
        int y = hudPositionManager.getY();
        int width = getHudContentWidth(font, lines);
        int height = getHudHeight(lines);
        return mouseX >= x - 4 && mouseX <= x + width + 5
                && mouseY >= y - 4 && mouseY <= y + height;
    }

    public void setHudPositionClamped(int x, int y, int screenWidth, int screenHeight, FontRenderer font) {
        if (font == null) return;
        List<String> lines = getHudLines();
        int width = getHudContentWidth(font, lines);
        int height = getHudHeight(lines);

        int minX = 4;
        int minY = 4;
        int maxX = Math.max(minX, screenWidth - width - 5);
        int maxY = Math.max(minY, screenHeight - height);

        int clampedX = Math.max(minX, Math.min(maxX, x));
        int clampedY = Math.max(minY, Math.min(maxY, y));
        hudPositionManager.setPosition(clampedX, clampedY);
    }

    public void clampHudToScreen(int screenWidth, int screenHeight, FontRenderer font) {
        setHudPositionClamped(hudPositionManager.getX(), hudPositionManager.getY(), screenWidth, screenHeight, font);
    }

    public void saveHudPosition() {
        hudPositionManager.save();
    }

    public int getHudX() {
        return hudPositionManager.getX();
    }

    public int getHudY() {
        return hudPositionManager.getY();
    }

    private List<String> getHudLines() {
        List<String> lines = new ArrayList<String>();
        lines.add("\u00A7c\u00A7lBlacklisted in Lobby \u00A77(" + detectedPlayers.size() + ")");

        if (blacklistManager.isEmpty()) {
            lines.add("\u00A7eNo players on blacklist");
        } else if (mc.func_147114_u() == null) {
            lines.add("\u00A77Not connected");
        } else if (lastLobbyPlayerCount == 0) {
            lines.add("\u00A7eNo players listed in lobby");
        } else if (detectedPlayers.isEmpty()) {
            lines.add("\u00A7aNone");
        } else {
            int shown = 0;
            for (String value : detectedPlayers.values()) {
                if (shown >= MAX_HUD_ENTRIES) break;
                lines.add(value);
                shown++;
            }
            int hidden = detectedPlayers.size() - shown;
            if (hidden > 0) {
                lines.add("\u00A77... and " + hidden + " more");
            }
        }
        return lines;
    }

    private int getHudContentWidth(FontRenderer font, List<String> lines) {
        int width = 0;
        for (String line : lines) {
            width = Math.max(width, font.func_78256_a(line));
        }
        return width;
    }

    private int getHudHeight(List<String> lines) {
        return lines.size() * 10 + 5;
    }

    private String getFormattedTabText(NetworkPlayerInfo info, GameProfile profile) {
        String fallback = profile == null ? "Unknown" : profile.getName();
        if (!BlacklistManager.isValidPlayerName(fallback)) fallback = "Unknown";

        try {
            IChatComponent displayName = info.func_178854_k();
            if (displayName != null) {
                String formatted = displayName.func_150254_d();
                if (formatted != null && !formatted.isEmpty()) {
                    return sanitizeServerText(formatted, fallback);
                }
            }
        } catch (RuntimeException ignored) { }

        try {
            ScorePlayerTeam team = info.func_178850_i();
            return sanitizeServerText(ScorePlayerTeam.func_96667_a(team, fallback), fallback);
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    /** Keeps normal Minecraft formatting codes but removes control characters/newlines and caps length. */
    private String sanitizeServerText(String input, String fallback) {
        if (input == null || input.isEmpty()) return fallback;
        StringBuilder out = new StringBuilder(Math.min(input.length(), MAX_TAB_TEXT_CHARS));
        for (int i = 0; i < input.length() && out.length() < MAX_TAB_TEXT_CHARS; i++) {
            char c = input.charAt(i);
            if (c < 32 || c == 127) continue;
            out.append(c);
        }
        if (out.length() == 0) return fallback;
        return out.toString();
    }

    public void handleCommand(String[] args) {
        if (args == null || args.length == 0) {
            showHelp();
            return;
        }

        String action = args[0].toLowerCase(Locale.ROOT);

        if ("add".equals(action)) {
            if (args.length != 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw add <name>");
                return;
            }
            String name = args[1];
            if (!BlacklistManager.isValidPlayerName(name)) {
                chat("\u00A7c[Blacklist] \u00A7fInvalid Minecraft username. Use 1-16 letters, numbers, or underscores.");
                return;
            }
            if (blacklistManager.contains(name)) {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f is already on the blacklist.");
                return;
            }
            if (blacklistManager.isAtCapacity()) {
                chat("\u00A7c[Blacklist] \u00A7fBlacklist limit reached (" + BlacklistManager.MAX_ENTRIES + ").");
                return;
            }
            if (blacklistManager.add(name)) {
                chat("\u00A7a[Blacklist] \u00A7fAdded \u00A7b" + name + "\u00A7f to the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7c[Blacklist] \u00A7fCould not add that player.");
            }
            return;
        }

        if ("remove".equals(action) || "del".equals(action) || "delete".equals(action)) {
            if (args.length != 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw remove <name>");
                return;
            }
            String name = args[1];
            if (!BlacklistManager.isValidPlayerName(name)) {
                chat("\u00A7c[Blacklist] \u00A7fInvalid Minecraft username.");
                return;
            }
            if (blacklistManager.remove(name)) {
                chat("\u00A7a[Blacklist] \u00A7fRemoved \u00A7b" + name + "\u00A7f from the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f was not on the blacklist.");
            }
            return;
        }

        if ("list".equals(action)) {
            showBlacklist();
            return;
        }

        if ("check".equals(action) || "status".equals(action)) {
            printCurrentStatus();
            return;
        }

        if ("clear".equals(action)) {
            if (blacklistManager.clear()) {
                chat("\u00A7a[Blacklist] \u00A7fCleared the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7fThe blacklist is already empty.");
            }
            return;
        }

        if ("help".equals(action)) {
            showHelp();
            return;
        }

        chat("\u00A7c[Blacklist] \u00A7fUnknown command. Use \u00A7b/blw help\u00A7f.");
    }

    private void showHelp() {
        chat("\u00A7b[Blacklist] \u00A7fCommands:");
        chat("\u00A77/blw add <name> \u00A7f- add a player");
        chat("\u00A77/blw remove <name> \u00A7f- remove a player");
        chat("\u00A77/blw list \u00A7f- show your blacklist");
        chat("\u00A77/blw check \u00A7f- check the current lobby");
        chat("\u00A77/blw clear \u00A7f- remove everyone from the blacklist");
        chat("\u00A77N \u00A7f- open the Blacklisted Lobby Watcher menu");
    }

    private void showBlacklist() {
        List<String> entries = blacklistManager.getEntries();
        if (entries.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist.");
            return;
        }

        int count = Math.min(entries.size(), MAX_COMMAND_LIST_ENTRIES);
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) builder.append("\u00A77, \u00A7b");
            builder.append(entries.get(i));
        }
        chat("\u00A7b[Blacklist] \u00A7f" + entries.size() + " player(s): \u00A7b" + builder.toString());
        if (entries.size() > count) {
            chat("\u00A77[Blacklist] " + (entries.size() - count) + " more saved. Press N -> Blacklist Settings to view them.");
        }
    }

    private void printCurrentStatus() {
        if (blacklistManager.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
            return;
        }

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            chat("\u00A7e[Blacklist] \u00A7fYou are not currently connected to a lobby.");
            return;
        }

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        if (playerInfo == null || playerInfo.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        List<String> matches = findMatches(playerInfo);
        if (matches.isEmpty()) {
            chat("\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
            return;
        }

        int count = Math.min(matches.size(), MAX_STATUS_MATCHES);
        for (int i = 0; i < count; i++) {
            chat("\u00A7c[Blacklist] \u00A7f" + matches.get(i) + "\u00A7c is in the lobby.");
        }
        if (matches.size() > count) {
            chat("\u00A77[Blacklist] " + (matches.size() - count) + " additional matches omitted from chat.");
        }
    }

    private List<String> findMatches(Collection<NetworkPlayerInfo> playerInfo) {
        List<String> matches = new ArrayList<String>();
        int scanned = 0;
        for (NetworkPlayerInfo info : playerInfo) {
            if (++scanned > MAX_TAB_PLAYERS_SCANNED) break;
            if (info == null) continue;
            try {
                GameProfile profile = info.func_178845_a();
                if (profile == null || !BlacklistManager.isValidPlayerName(profile.getName())) continue;
                if (blacklistManager.contains(profile.getName())) {
                    matches.add(getFormattedTabText(info, profile));
                }
            } catch (RuntimeException ignored) { }
        }
        return matches;
    }

    private void forceStatusRefresh() {
        lastStatus = STATUS_UNKNOWN;
        if (connectedChecks < STATUS_DELAY_CHECKS) {
            connectedChecks = STATUS_DELAY_CHECKS;
        }
    }

    private void announceStatus(int status, String message) {
        if (connectedChecks < STATUS_DELAY_CHECKS) return;
        if (lastStatus == status) return;
        lastStatus = status;
        chat(message);
    }

    private void beginNewLobby(WorldClient world) {
        lastWorld = world;
        detectedPlayers.clear();
        previousPlayers.clear();
        connectedChecks = 0;
        lastStatus = STATUS_UNKNOWN;
        lastLobbyPlayerCount = -1;
    }

    private void resetConnectionState() {
        detectedPlayers.clear();
        previousPlayers.clear();
        connectedChecks = 0;
        lastStatus = STATUS_UNKNOWN;
        lastLobbyPlayerCount = -1;
        lastWorld = null;
    }

    private void alert(String tabText) {
        playPing(soundSettingsManager.getJoinVolumeFloat(), 1.35F);
        chat("\u00A7c[Blacklist] \u00A7f" + tabText + "\u00A7c is in the lobby.");
    }

    private void alertLeft(String tabText) {
        playPing(soundSettingsManager.getLeaveVolumeFloat(), 0.65F);
        chat("\u00A7e[Blacklist] \u00A7f" + tabText + "\u00A7e left the lobby.");
    }

    /** Plays locally on the client; this does not send a command or custom packet to the server. */
    private void playPing(float volume, float pitch) {
        if (mc.field_71439_g == null || volume <= 0.0F) return;
        try {
            mc.field_71439_g.func_85030_a("note.pling", volume, pitch);
        } catch (RuntimeException ignored) { }
    }

    public SoundSettingsManager getSoundSettingsManager() {
        return soundSettingsManager;
    }

    public void previewJoinPing() {
        playPing(soundSettingsManager.getJoinVolumeFloat(), 1.35F);
    }

    public void previewLeavePing() {
        playPing(soundSettingsManager.getLeaveVolumeFloat(), 0.65F);
    }

    private void chat(String message) {
        if (mc.field_71439_g == null || message == null) return;
        String safe = sanitizeLocalChat(message);
        mc.field_71439_g.func_145747_a(new ChatComponentText(safe));
    }

    private String sanitizeLocalChat(String message) {
        StringBuilder out = new StringBuilder(Math.min(message.length(), MAX_CHAT_MESSAGE_CHARS));
        for (int i = 0; i < message.length() && out.length() < MAX_CHAT_MESSAGE_CHARS; i++) {
            char c = message.charAt(i);
            if (c < 32 || c == 127) continue;
            out.append(c);
        }
        return out.toString();
    }

    public List<String> getDetectedPlayers() {
        return Collections.unmodifiableList(new ArrayList<String>(detectedPlayers.values()));
    }
}
