# Blacklisted Lobby Watcher 1.0.6 compatibility baseline

This build intentionally focuses on a reliable Lunar/Forge 1.8.9 core before re-adding UI features.

## What works in this baseline
- Forge 1.8.9 lifecycle loading
- Creates/loads `config/blacklisted_lobby_watcher.json`
- Checks the TAB/player-info list every 5 client ticks
- Case-insensitive blacklist matching
- One chat alert when a blacklisted player appears; re-alerts after they leave and return

## Config format
```json
[
  "ExamplePlayer",
  "AnotherPlayer"
]
```

The GUI, B keybind, HUD and sound alert are temporarily omitted from 1.0.6 so the core can be verified on Lunar/Ichor first. They can be restored after this compatibility baseline loads successfully.
