package com.example.blacklistedlobbywatcher;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class LobbyWatcher {
    private final Minecraft mc;
    private final BlacklistManager blacklistManager;
    private final Map<UUID, String> detectedPlayers = new LinkedHashMap<UUID, String>();
    private final Map<UUID, String> previousPlayers = new LinkedHashMap<UUID, String>();
    private int tickCounter;

    public LobbyWatcher(Minecraft mc, BlacklistManager blacklistManager) {
        this.mc = mc;
        this.blacklistManager = blacklistManager;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (++tickCounter < 5) return;
        tickCounter = 0;

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            detectedPlayers.clear();
            previousPlayers.clear();
            return;
        }

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        Map<UUID, String> currentBlacklisted = new LinkedHashMap<UUID, String>();

        if (playerInfo != null) {
            for (NetworkPlayerInfo info : playerInfo) {
                if (info == null) continue;
                GameProfile profile = info.func_178845_a();
                if (profile == null) continue;

                UUID uuid = profile.getId();
                String name = profile.getName();
                if (uuid == null || name == null) continue;

                if (blacklistManager.contains(name)) {
                    currentBlacklisted.put(uuid, name);
                    if (!previousPlayers.containsKey(uuid)) alert(name);
                }
            }
        }

        detectedPlayers.clear();
        detectedPlayers.putAll(currentBlacklisted);
        previousPlayers.clear();
        previousPlayers.putAll(currentBlacklisted);
    }

    private void alert(String name) {
        if (mc.field_71439_g != null) {
            mc.field_71439_g.func_145747_a(
                    new ChatComponentText("\u00A7c[Blacklist] \u00A7f" + name + "\u00A7c is in the lobby.")
            );
        }
    }

    public List<String> getDetectedPlayers() {
        return Collections.unmodifiableList(new ArrayList<String>(detectedPlayers.values()));
    }
}
