package com.example.blacklistedlobbywatcher;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(
        modid = BlacklistedLobbyWatcher.MODID,
        name = BlacklistedLobbyWatcher.NAME,
        version = BlacklistedLobbyWatcher.VERSION,
        clientSideOnly = true
)
public class BlacklistedLobbyWatcher {
    public static final String MODID = "blacklistedlobbywatcher";
    public static final String NAME = "Blacklisted Lobby Watcher";
    public static final String VERSION = "1.1.2";

    private static BlacklistManager blacklistManager;
    private static LobbyWatcher lobbyWatcher;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        blacklistManager = new BlacklistManager(event.getModConfigurationDirectory());
        blacklistManager.load();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        Minecraft mc = Minecraft.func_71410_x();
        lobbyWatcher = new LobbyWatcher(mc, blacklistManager);
        MinecraftForge.EVENT_BUS.register(lobbyWatcher);
        ClientCommandHandler.instance.func_71560_a(new BlacklistCommand(lobbyWatcher));
    }

    public static BlacklistManager getBlacklistManager() {
        return blacklistManager;
    }

    public static LobbyWatcher getLobbyWatcher() {
        return lobbyWatcher;
    }
}
