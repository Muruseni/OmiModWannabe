package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class BlacklistedLobbyMenu extends GuiScreen {
    private final BlacklistManager blacklistManager;

    public BlacklistedLobbyMenu(BlacklistManager blacklistManager) {
        this.blacklistManager = blacklistManager;
    }

    @Override
    public void func_73866_w_() {
        int centerX = this.field_146294_l / 2;
        int centerY = this.field_146295_m / 2;
        this.field_146292_n.add(new GuiButton(1, centerX - 100, centerY - 10, 200, 20, "Blacklist Settings"));
        this.field_146292_n.add(new GuiButton(0, centerX - 100, centerY + 20, 200, 20, "Close"));
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        Gui.func_73734_a(0, 0, this.field_146294_l, this.field_146295_m, 0xD0101010);
        drawCentered("\u00A7c\u00A7lBlacklisted Lobby Watcher", this.field_146295_m / 2 - 55, 0xFFFFFF);
        drawCentered("\u00A77More tools can be added to this menu later.", this.field_146295_m / 2 - 38, 0xFFFFFF);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == 1) {
            this.field_146297_k.func_147108_a(new BlacklistSettingsScreen(this, blacklistManager));
        } else if (button.field_146127_k == 0) {
            this.field_146297_k.func_147108_a(null);
        }
    }

    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
