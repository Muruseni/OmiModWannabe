# Blacklisted Lobby Watcher 1.1.0

Minecraft 1.8.9 Forge/Lunar compatibility build.

## HUD
An always-visible in-game HUD shows the blacklisted players currently found in TAB. It uses the formatted TAB-list display string when available, so server prefixes/suffixes such as `[120] Muruseni_` are shown instead of only the raw profile name.

If there are no matches, the HUD shows a useful state such as no blacklist entries, no players listed in the lobby, or `None`.

## Menu
Press **N** while in game to open the Blacklisted Lobby Watcher menu.

The menu currently contains **Blacklist Settings**. That screen shows:
- the available `/blw` commands;
- the complete saved blacklist;
- Previous/Next pages when the blacklist is longer than one page.

## Local chat commands
- `/blw add <name>` - add a player
- `/blw remove <name>` - remove a player
- `/blw list` - list blacklisted players
- `/blw check` - manually check the current lobby
- `/blw clear` - clear the blacklist
- `/blw help` - show help

`/bl` and `/blacklist` can be used instead of `/blw`.

The list is saved to `config/blacklisted_lobby_watcher.json`.
