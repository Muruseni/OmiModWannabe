# Blacklisted Lobby Watcher 1.1.1

Minecraft 1.8.9 Forge/Lunar compatibility build.

## Draggable HUD
The always-visible HUD shows blacklisted players currently found in TAB, preserving the formatted TAB-list text where available (for example `[120] Muruseni_`).

Press **N** to open the Blacklisted Lobby Watcher menu. While that menu is open, click and drag the HUD box anywhere on screen. The HUD is kept inside the screen bounds and its position is saved when you release the mouse.

The HUD position is stored separately in `config/blacklisted_lobby_watcher_hud.properties`, so existing blacklist data remains compatible.

## Menu
Press **N** while in game to open the Blacklisted Lobby Watcher menu.

The menu contains **Blacklist Settings**, which shows the available `/blw` commands and the complete saved blacklist with Previous/Next pages.

## Local chat commands
- `/blw add <name>` - add a player
- `/blw remove <name>` - remove a player
- `/blw list` - list blacklisted players
- `/blw check` - manually check the current lobby
- `/blw clear` - clear the blacklist
- `/blw help` - show help

`/bl` and `/blacklist` can be used instead of `/blw`.

The blacklist remains saved to `config/blacklisted_lobby_watcher.json`.
