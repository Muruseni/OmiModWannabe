package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.util.List;

public class BlacklistSettingsScreen extends GuiScreen {
    private static final int PAGE_SIZE = 8;

    private final GuiScreen parent;
    private final BlacklistManager blacklistManager;
    private int page;

    public BlacklistSettingsScreen(GuiScreen parent, BlacklistManager blacklistManager) {
        this.parent = parent;
        this.blacklistManager = blacklistManager;
    }

    @Override
    public void func_73866_w_() {
        int bottom = this.field_146295_m - 28;
        int centerX = this.field_146294_l / 2;
        this.field_146292_n.add(new GuiButton(0, centerX - 145, bottom, 90, 20, "Back"));
        this.field_146292_n.add(new GuiButton(2, centerX - 45, bottom, 90, 20, "Previous"));
        this.field_146292_n.add(new GuiButton(3, centerX + 55, bottom, 90, 20, "Next"));
        clampPage();
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        Gui.func_73734_a(0, 0, this.field_146294_l, this.field_146295_m, 0xD0101010);
        drawCentered("\u00A7c\u00A7lBlacklist Settings", 18, 0xFFFFFF);

        int left = Math.max(18, this.field_146294_l / 2 - 145);
        int y = 42;
        this.field_146289_q.func_78276_b("\u00A7bCommands", left, y, 0xFFFFFF);
        y += 13;
        this.field_146289_q.func_78276_b("\u00A77/blw add <name> \u00A7f- add a player", left, y, 0xFFFFFF);
        y += 11;
        this.field_146289_q.func_78276_b("\u00A77/blw remove <name> \u00A7f- remove a player", left, y, 0xFFFFFF);
        y += 11;
        this.field_146289_q.func_78276_b("\u00A77/blw list \u00A7f- list saved players", left, y, 0xFFFFFF);
        y += 11;
        this.field_146289_q.func_78276_b("\u00A77/blw check \u00A7f- check this lobby", left, y, 0xFFFFFF);
        y += 11;
        this.field_146289_q.func_78276_b("\u00A77/blw clear \u00A7f- clear the blacklist", left, y, 0xFFFFFF);

        List<String> entries = blacklistManager.getEntries();
        int totalPages = getPageCount(entries.size());
        clampPage();
        y += 20;
        this.field_146289_q.func_78276_b(
                "\u00A7bCurrent blacklist \u00A77(" + entries.size() + ")  Page " + (page + 1) + "/" + totalPages,
                left, y, 0xFFFFFF);
        y += 14;

        if (entries.isEmpty()) {
            this.field_146289_q.func_78276_b("\u00A7eNo players are currently blacklisted.", left, y, 0xFFFFFF);
        } else {
            int start = page * PAGE_SIZE;
            int end = Math.min(entries.size(), start + PAGE_SIZE);
            for (int i = start; i < end; i++) {
                this.field_146289_q.func_78276_b("\u00A7f- \u00A7c" + entries.get(i), left, y, 0xFFFFFF);
                y += 10;
            }
        }

        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == 0) {
            this.field_146297_k.func_147108_a(parent);
            return;
        }

        int pageCount = getPageCount(blacklistManager.size());
        if (button.field_146127_k == 2 && page > 0) {
            page--;
        } else if (button.field_146127_k == 3 && page + 1 < pageCount) {
            page++;
        }
    }

    private void clampPage() {
        int maxPage = getPageCount(blacklistManager.size()) - 1;
        if (page > maxPage) page = maxPage;
        if (page < 0) page = 0;
    }

    private int getPageCount(int size) {
        return Math.max(1, (size + PAGE_SIZE - 1) / PAGE_SIZE);
    }

    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
