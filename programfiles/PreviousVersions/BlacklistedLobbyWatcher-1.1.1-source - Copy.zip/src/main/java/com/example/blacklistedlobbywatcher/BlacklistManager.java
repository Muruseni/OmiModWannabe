package com.example.blacklistedlobbywatcher;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class BlacklistManager {
    private final File file;
    private final List<String> blacklist = new ArrayList<String>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public BlacklistManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher.json");
    }

    public void load() {
        blacklist.clear();
        if (!file.exists()) {
            save();
            return;
        }

        FileReader reader = null;
        try {
            Type type = new TypeToken<List<String>>() { }.getType();
            reader = new FileReader(file);
            List<String> loaded = gson.fromJson(reader, type);
            if (loaded != null) {
                for (String name : loaded) {
                    addInternal(name, false);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try { reader.close(); } catch (Exception ignored) { }
            }
        }
    }

    public void save() {
        FileWriter writer = null;
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            writer = new FileWriter(file);
            gson.toJson(blacklist, writer);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try { writer.close(); } catch (Exception ignored) { }
            }
        }
    }

    public boolean contains(String name) {
        if (name == null) return false;
        String normalized = name.trim().toLowerCase(Locale.ROOT);
        for (String entry : blacklist) {
            if (entry.toLowerCase(Locale.ROOT).equals(normalized)) return true;
        }
        return false;
    }

    public boolean add(String name) {
        return addInternal(name, true);
    }

    private boolean addInternal(String name, boolean shouldSave) {
        if (name == null) return false;
        String cleaned = name.trim();
        if (cleaned.isEmpty() || contains(cleaned)) return false;
        blacklist.add(cleaned);
        if (shouldSave) save();
        return true;
    }

    public boolean remove(String name) {
        if (name == null) return false;
        String normalized = name.trim().toLowerCase(Locale.ROOT);
        boolean changed = false;
        for (int i = blacklist.size() - 1; i >= 0; i--) {
            if (blacklist.get(i).toLowerCase(Locale.ROOT).equals(normalized)) {
                blacklist.remove(i);
                changed = true;
            }
        }
        if (changed) save();
        return changed;
    }

    public boolean clear() {
        if (blacklist.isEmpty()) return false;
        blacklist.clear();
        save();
        return true;
    }

    public boolean isEmpty() {
        return blacklist.isEmpty();
    }

    public int size() {
        return blacklist.size();
    }

    public List<String> getEntries() {
        return Collections.unmodifiableList(new ArrayList<String>(blacklist));
    }

    public File getConfigDirectory() {
        return file.getParentFile();
    }
}
