package com.example.blacklistedlobbywatcher;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class LobbyWatcher {
    private static final int STATUS_UNKNOWN = 0;
    private static final int STATUS_EMPTY_BLACKLIST = 1;
    private static final int STATUS_EMPTY_LOBBY = 2;
    private static final int STATUS_CLEAR = 3;
    private static final int STATUS_DETECTED = 4;
    private static final int STATUS_DELAY_CHECKS = 8;
    private static final int MENU_KEY = Keyboard.KEY_N;

    private final Minecraft mc;
    private final BlacklistManager blacklistManager;
    private final HudPositionManager hudPositionManager;
    /** UUID -> formatted TAB-list text, including server prefix/suffix/color codes. */
    private final Map<UUID, String> detectedPlayers = new LinkedHashMap<UUID, String>();
    /** UUID -> profile name; only presence is used to avoid repeated alerts. */
    private final Map<UUID, String> previousPlayers = new LinkedHashMap<UUID, String>();
    private int tickCounter;
    private int connectedChecks;
    private int lastStatus = STATUS_UNKNOWN;
    private int lastLobbyPlayerCount = -1;
    private boolean menuKeyWasDown;

    public LobbyWatcher(Minecraft mc, BlacklistManager blacklistManager) {
        this.mc = mc;
        this.blacklistManager = blacklistManager;
        this.hudPositionManager = new HudPositionManager(blacklistManager.getConfigDirectory());
        this.hudPositionManager.load();
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        handleMenuKey();

        if (++tickCounter < 5) return;
        tickCounter = 0;

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            resetConnectionState();
            return;
        }

        connectedChecks++;

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        lastLobbyPlayerCount = playerInfo == null ? 0 : playerInfo.size();

        if (blacklistManager.isEmpty()) {
            detectedPlayers.clear();
            previousPlayers.clear();
            announceStatus(STATUS_EMPTY_BLACKLIST,
                    "\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
            return;
        }

        Map<UUID, String> currentBlacklisted = new LinkedHashMap<UUID, String>();
        Map<UUID, String> currentProfileNames = new LinkedHashMap<UUID, String>();

        if (playerInfo == null || playerInfo.isEmpty()) {
            detectedPlayers.clear();
            previousPlayers.clear();
            announceStatus(STATUS_EMPTY_LOBBY,
                    "\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        for (NetworkPlayerInfo info : playerInfo) {
            if (info == null) continue;
            GameProfile profile = info.func_178845_a();
            if (profile == null) continue;

            UUID uuid = profile.getId();
            String name = profile.getName();
            if (uuid == null || name == null) continue;

            if (blacklistManager.contains(name)) {
                String tabText = getFormattedTabText(info, profile);
                currentBlacklisted.put(uuid, tabText);
                currentProfileNames.put(uuid, name);
                if (!previousPlayers.containsKey(uuid)) alert(tabText);
            }
        }

        detectedPlayers.clear();
        detectedPlayers.putAll(currentBlacklisted);
        previousPlayers.clear();
        previousPlayers.putAll(currentProfileNames);

        if (currentBlacklisted.isEmpty()) {
            announceStatus(STATUS_CLEAR,
                    "\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
        } else {
            lastStatus = STATUS_DETECTED;
        }
    }

    private void handleMenuKey() {
        boolean down = Keyboard.isKeyDown(MENU_KEY);
        if (down && !menuKeyWasDown && mc.field_71439_g != null && mc.field_71462_r == null) {
            mc.func_147108_a(new BlacklistedLobbyMenu(blacklistManager, this));
        }
        menuKeyWasDown = down;
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
        if (mc.field_71439_g == null || mc.field_71466_p == null) return;
        if (mc.field_71462_r instanceof BlacklistedLobbyMenu) return;
        drawHud(mc.field_71466_p);
    }

    public void drawHud(FontRenderer font) {
        if (font == null) return;

        List<String> lines = getHudLines();
        int x = hudPositionManager.getX();
        int y = hudPositionManager.getY();
        int width = getHudContentWidth(font, lines);
        int height = getHudHeight(lines);

        Gui.func_73734_a(x - 4, y - 4, x + width + 5, y + height, 0x90000000);
        for (int i = 0; i < lines.size(); i++) {
            font.func_78276_b(lines.get(i), x, y + i * 10, 0xFFFFFF);
        }
    }

    public boolean isPointInsideHud(FontRenderer font, int mouseX, int mouseY) {
        if (font == null) return false;
        List<String> lines = getHudLines();
        int x = hudPositionManager.getX();
        int y = hudPositionManager.getY();
        int width = getHudContentWidth(font, lines);
        int height = getHudHeight(lines);
        return mouseX >= x - 4 && mouseX <= x + width + 5
                && mouseY >= y - 4 && mouseY <= y + height;
    }

    public void setHudPositionClamped(int x, int y, int screenWidth, int screenHeight, FontRenderer font) {
        List<String> lines = getHudLines();
        int width = getHudContentWidth(font, lines);
        int height = getHudHeight(lines);

        int minX = 4;
        int minY = 4;
        int maxX = Math.max(minX, screenWidth - width - 5);
        int maxY = Math.max(minY, screenHeight - height);

        int clampedX = Math.max(minX, Math.min(maxX, x));
        int clampedY = Math.max(minY, Math.min(maxY, y));
        hudPositionManager.setPosition(clampedX, clampedY);
    }

    public void clampHudToScreen(int screenWidth, int screenHeight, FontRenderer font) {
        setHudPositionClamped(hudPositionManager.getX(), hudPositionManager.getY(), screenWidth, screenHeight, font);
    }

    public void saveHudPosition() {
        hudPositionManager.save();
    }

    public int getHudX() {
        return hudPositionManager.getX();
    }

    public int getHudY() {
        return hudPositionManager.getY();
    }

    private List<String> getHudLines() {
        List<String> lines = new ArrayList<String>();
        lines.add("\u00A7c\u00A7lBlacklisted in Lobby \u00A77(" + detectedPlayers.size() + ")");

        if (blacklistManager.isEmpty()) {
            lines.add("\u00A7eNo players on blacklist");
        } else if (mc.func_147114_u() == null) {
            lines.add("\u00A77Not connected");
        } else if (lastLobbyPlayerCount == 0) {
            lines.add("\u00A7eNo players listed in lobby");
        } else if (detectedPlayers.isEmpty()) {
            lines.add("\u00A7aNone");
        } else {
            lines.addAll(detectedPlayers.values());
        }
        return lines;
    }

    private int getHudContentWidth(FontRenderer font, List<String> lines) {
        int width = 0;
        for (String line : lines) {
            width = Math.max(width, font.func_78256_a(line));
        }
        return width;
    }

    private int getHudHeight(List<String> lines) {
        return lines.size() * 10 + 5;
    }

    private String getFormattedTabText(NetworkPlayerInfo info, GameProfile profile) {
        IChatComponent displayName = info.func_178854_k();
        if (displayName != null) {
            String formatted = displayName.func_150254_d();
            if (formatted != null && !formatted.isEmpty()) return formatted;
        }

        ScorePlayerTeam team = info.func_178850_i();
        return ScorePlayerTeam.func_96667_a(team, profile.getName());
    }

    public void handleCommand(String[] args) {
        if (args == null || args.length == 0) {
            showHelp();
            return;
        }

        String action = args[0].toLowerCase(Locale.ROOT);

        if ("add".equals(action)) {
            if (args.length < 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw add <name>");
                return;
            }
            String name = args[1];
            if (blacklistManager.add(name)) {
                chat("\u00A7a[Blacklist] \u00A7fAdded \u00A7b" + name + "\u00A7f to the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f is already on the blacklist.");
            }
            return;
        }

        if ("remove".equals(action) || "del".equals(action) || "delete".equals(action)) {
            if (args.length < 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw remove <name>");
                return;
            }
            String name = args[1];
            if (blacklistManager.remove(name)) {
                chat("\u00A7a[Blacklist] \u00A7fRemoved \u00A7b" + name + "\u00A7f from the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f was not on the blacklist.");
            }
            return;
        }

        if ("list".equals(action)) {
            showBlacklist();
            return;
        }

        if ("check".equals(action) || "status".equals(action)) {
            printCurrentStatus();
            return;
        }

        if ("clear".equals(action)) {
            if (blacklistManager.clear()) {
                chat("\u00A7a[Blacklist] \u00A7fCleared the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7fThe blacklist is already empty.");
            }
            return;
        }

        if ("help".equals(action)) {
            showHelp();
            return;
        }

        chat("\u00A7c[Blacklist] \u00A7fUnknown command. Use \u00A7b/blw help\u00A7f.");
    }

    private void showHelp() {
        chat("\u00A7b[Blacklist] \u00A7fCommands:");
        chat("\u00A77/blw add <name> \u00A7f- add a player");
        chat("\u00A77/blw remove <name> \u00A7f- remove a player");
        chat("\u00A77/blw list \u00A7f- show your blacklist");
        chat("\u00A77/blw check \u00A7f- check the current lobby");
        chat("\u00A77/blw clear \u00A7f- remove everyone from the blacklist");
        chat("\u00A77N \u00A7f- open the Blacklisted Lobby Watcher menu");
    }

    private void showBlacklist() {
        List<String> entries = blacklistManager.getEntries();
        if (entries.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist.");
            return;
        }

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < entries.size(); i++) {
            if (i > 0) builder.append("\u00A77, \u00A7b");
            builder.append(entries.get(i));
        }
        chat("\u00A7b[Blacklist] \u00A7f" + entries.size() + " player(s): \u00A7b" + builder.toString());
    }

    private void printCurrentStatus() {
        if (blacklistManager.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
            return;
        }

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            chat("\u00A7e[Blacklist] \u00A7fYou are not currently connected to a lobby.");
            return;
        }

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        if (playerInfo == null || playerInfo.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        List<String> matches = findMatches(playerInfo);
        if (matches.isEmpty()) {
            chat("\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
            return;
        }

        for (String name : matches) {
            chat("\u00A7c[Blacklist] \u00A7f" + name + "\u00A7c is in the lobby.");
        }
    }

    private List<String> findMatches(Collection<NetworkPlayerInfo> playerInfo) {
        List<String> matches = new ArrayList<String>();
        for (NetworkPlayerInfo info : playerInfo) {
            if (info == null) continue;
            GameProfile profile = info.func_178845_a();
            if (profile == null || profile.getName() == null) continue;
            if (blacklistManager.contains(profile.getName())) {
                matches.add(getFormattedTabText(info, profile));
            }
        }
        return matches;
    }

    private void forceStatusRefresh() {
        lastStatus = STATUS_UNKNOWN;
        if (connectedChecks < STATUS_DELAY_CHECKS) {
            connectedChecks = STATUS_DELAY_CHECKS;
        }
    }

    private void announceStatus(int status, String message) {
        if (connectedChecks < STATUS_DELAY_CHECKS) return;
        if (lastStatus == status) return;
        lastStatus = status;
        chat(message);
    }

    private void resetConnectionState() {
        detectedPlayers.clear();
        previousPlayers.clear();
        connectedChecks = 0;
        lastStatus = STATUS_UNKNOWN;
        lastLobbyPlayerCount = -1;
    }

    private void alert(String tabText) {
        chat("\u00A7c[Blacklist] \u00A7f" + tabText + "\u00A7c is in the lobby.");
    }

    private void chat(String message) {
        if (mc.field_71439_g != null) {
            mc.field_71439_g.func_145747_a(new ChatComponentText(message));
        }
    }

    public List<String> getDetectedPlayers() {
        return Collections.unmodifiableList(new ArrayList<String>(detectedPlayers.values()));
    }
}
