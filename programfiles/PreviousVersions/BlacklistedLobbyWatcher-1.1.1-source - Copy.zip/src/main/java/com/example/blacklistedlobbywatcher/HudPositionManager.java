package com.example.blacklistedlobbywatcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/** Stores the HUD position separately from the blacklist JSON for backward compatibility. */
public class HudPositionManager {
    private static final int DEFAULT_X = 7;
    private static final int DEFAULT_Y = 7;

    private final File file;
    private int x = DEFAULT_X;
    private int y = DEFAULT_Y;

    public HudPositionManager(File configDirectory) {
        this.file = new File(configDirectory, "blacklisted_lobby_watcher_hud.properties");
    }

    public void load() {
        x = DEFAULT_X;
        y = DEFAULT_Y;
        if (!file.exists()) return;

        FileInputStream input = null;
        try {
            Properties properties = new Properties();
            input = new FileInputStream(file);
            properties.load(input);
            x = parseInt(properties.getProperty("x"), DEFAULT_X);
            y = parseInt(properties.getProperty("y"), DEFAULT_Y);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (input != null) {
                try { input.close(); } catch (Exception ignored) { }
            }
        }
    }

    public void save() {
        FileOutputStream output = null;
        try {
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();

            Properties properties = new Properties();
            properties.setProperty("x", Integer.toString(x));
            properties.setProperty("y", Integer.toString(y));

            output = new FileOutputStream(file);
            properties.store(output, "Blacklisted Lobby Watcher HUD position");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (output != null) {
                try { output.close(); } catch (Exception ignored) { }
            }
        }
    }

    private int parseInt(String value, int fallback) {
        if (value == null) return fallback;
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
