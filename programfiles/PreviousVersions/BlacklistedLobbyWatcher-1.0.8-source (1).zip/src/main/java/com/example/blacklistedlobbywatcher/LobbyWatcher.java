package com.example.blacklistedlobbywatcher;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class LobbyWatcher {
    private static final int STATUS_UNKNOWN = 0;
    private static final int STATUS_EMPTY_BLACKLIST = 1;
    private static final int STATUS_EMPTY_LOBBY = 2;
    private static final int STATUS_CLEAR = 3;
    private static final int STATUS_DETECTED = 4;
    private static final int STATUS_DELAY_CHECKS = 8; // about two seconds at 5 ticks per scan

    private final Minecraft mc;
    private final BlacklistManager blacklistManager;
    private final Map<UUID, String> detectedPlayers = new LinkedHashMap<UUID, String>();
    private final Map<UUID, String> previousPlayers = new LinkedHashMap<UUID, String>();
    private int tickCounter;
    private int connectedChecks;
    private int lastStatus = STATUS_UNKNOWN;

    public LobbyWatcher(Minecraft mc, BlacklistManager blacklistManager) {
        this.mc = mc;
        this.blacklistManager = blacklistManager;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (++tickCounter < 5) return;
        tickCounter = 0;

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            resetConnectionState();
            return;
        }

        connectedChecks++;

        if (blacklistManager.isEmpty()) {
            detectedPlayers.clear();
            previousPlayers.clear();
            announceStatus(STATUS_EMPTY_BLACKLIST,
                    "\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
            return;
        }

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        Map<UUID, String> currentBlacklisted = new LinkedHashMap<UUID, String>();

        if (playerInfo == null || playerInfo.isEmpty()) {
            detectedPlayers.clear();
            previousPlayers.clear();
            announceStatus(STATUS_EMPTY_LOBBY,
                    "\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        for (NetworkPlayerInfo info : playerInfo) {
            if (info == null) continue;
            GameProfile profile = info.func_178845_a();
            if (profile == null) continue;

            UUID uuid = profile.getId();
            String name = profile.getName();
            if (uuid == null || name == null) continue;

            if (blacklistManager.contains(name)) {
                currentBlacklisted.put(uuid, name);
                if (!previousPlayers.containsKey(uuid)) alert(name);
            }
        }

        detectedPlayers.clear();
        detectedPlayers.putAll(currentBlacklisted);
        previousPlayers.clear();
        previousPlayers.putAll(currentBlacklisted);

        if (currentBlacklisted.isEmpty()) {
            announceStatus(STATUS_CLEAR,
                    "\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
        } else {
            lastStatus = STATUS_DETECTED;
        }
    }

    public void handleCommand(String[] args) {
        if (args == null || args.length == 0) {
            showHelp();
            return;
        }

        String action = args[0].toLowerCase(Locale.ROOT);

        if ("add".equals(action)) {
            if (args.length < 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw add <name>");
                return;
            }
            String name = args[1];
            if (blacklistManager.add(name)) {
                chat("\u00A7a[Blacklist] \u00A7fAdded \u00A7b" + name + "\u00A7f to the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f is already on the blacklist.");
            }
            return;
        }

        if ("remove".equals(action) || "del".equals(action) || "delete".equals(action)) {
            if (args.length < 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw remove <name>");
                return;
            }
            String name = args[1];
            if (blacklistManager.remove(name)) {
                chat("\u00A7a[Blacklist] \u00A7fRemoved \u00A7b" + name + "\u00A7f from the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f was not on the blacklist.");
            }
            return;
        }

        if ("list".equals(action)) {
            showBlacklist();
            return;
        }

        if ("check".equals(action) || "status".equals(action)) {
            printCurrentStatus();
            return;
        }

        if ("clear".equals(action)) {
            if (blacklistManager.clear()) {
                chat("\u00A7a[Blacklist] \u00A7fCleared the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7fThe blacklist is already empty.");
            }
            return;
        }

        if ("help".equals(action)) {
            showHelp();
            return;
        }

        chat("\u00A7c[Blacklist] \u00A7fUnknown command. Use \u00A7b/blw help\u00A7f.");
    }

    private void showHelp() {
        chat("\u00A7b[Blacklist] \u00A7fCommands:");
        chat("\u00A77/blw add <name> \u00A7f- add a player");
        chat("\u00A77/blw remove <name> \u00A7f- remove a player");
        chat("\u00A77/blw list \u00A7f- show your blacklist");
        chat("\u00A77/blw check \u00A7f- check the current lobby");
        chat("\u00A77/blw clear \u00A7f- remove everyone from the blacklist");
    }

    private void showBlacklist() {
        List<String> entries = blacklistManager.getEntries();
        if (entries.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist.");
            return;
        }

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < entries.size(); i++) {
            if (i > 0) builder.append("\u00A77, \u00A7b");
            builder.append(entries.get(i));
        }
        chat("\u00A7b[Blacklist] \u00A7f" + entries.size() + " player(s): \u00A7b" + builder.toString());
    }

    private void printCurrentStatus() {
        if (blacklistManager.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
            return;
        }

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            chat("\u00A7e[Blacklist] \u00A7fYou are not currently connected to a lobby.");
            return;
        }

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        if (playerInfo == null || playerInfo.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        List<String> matches = findMatches(playerInfo);
        if (matches.isEmpty()) {
            chat("\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
            return;
        }

        for (String name : matches) {
            chat("\u00A7c[Blacklist] \u00A7f" + name + "\u00A7c is in the lobby.");
        }
    }

    private List<String> findMatches(Collection<NetworkPlayerInfo> playerInfo) {
        List<String> matches = new ArrayList<String>();
        for (NetworkPlayerInfo info : playerInfo) {
            if (info == null) continue;
            GameProfile profile = info.func_178845_a();
            if (profile == null || profile.getName() == null) continue;
            if (blacklistManager.contains(profile.getName())) {
                matches.add(profile.getName());
            }
        }
        return matches;
    }

    private void forceStatusRefresh() {
        lastStatus = STATUS_UNKNOWN;
        if (connectedChecks < STATUS_DELAY_CHECKS) {
            connectedChecks = STATUS_DELAY_CHECKS;
        }
    }

    private void announceStatus(int status, String message) {
        if (connectedChecks < STATUS_DELAY_CHECKS) return;
        if (lastStatus == status) return;
        lastStatus = status;
        chat(message);
    }

    private void resetConnectionState() {
        detectedPlayers.clear();
        previousPlayers.clear();
        connectedChecks = 0;
        lastStatus = STATUS_UNKNOWN;
    }

    private void alert(String name) {
        chat("\u00A7c[Blacklist] \u00A7f" + name + "\u00A7c is in the lobby.");
    }

    private void chat(String message) {
        if (mc.field_71439_g != null) {
            mc.field_71439_g.func_145747_a(new ChatComponentText(message));
        }
    }

    public List<String> getDetectedPlayers() {
        return Collections.unmodifiableList(new ArrayList<String>(detectedPlayers.values()));
    }
}
