# Blacklisted Lobby Watcher 1.0.8

Minecraft 1.8.9 Forge/Lunar compatibility build.

## Status messages
After joining a server/lobby, the mod waits briefly for the TAB list to populate and then reports one of these states in chat:
- no players are on your blacklist;
- no players are currently listed in the lobby;
- no blacklisted players are listed in the lobby;
- or an alert for each blacklisted player it detects.

Status messages are state-based so they do not spam chat. A new message is shown when the relevant state changes.

## Local chat commands
These are registered Forge client-side commands and are handled locally instead of being sent to the server:

- `/blw add <name>` - add a player
- `/blw remove <name>` - remove a player
- `/blw list` - list blacklisted players
- `/blw check` - manually check the current lobby
- `/blw clear` - clear the blacklist
- `/blw help` - show help

`/bl` and `/blacklist` can be used instead of `/blw`.

The list is saved to `config/blacklisted_lobby_watcher.json`.
