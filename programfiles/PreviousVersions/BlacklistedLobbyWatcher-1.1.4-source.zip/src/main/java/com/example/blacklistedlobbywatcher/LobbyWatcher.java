package com.example.blacklistedlobbywatcher;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.network.NetworkManager;
import net.minecraft.scoreboard.IScoreObjectiveCriteria;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.WorldSettings;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class LobbyWatcher {
    private static final int STATUS_UNKNOWN = 0;
    private static final int STATUS_EMPTY_BLACKLIST = 1;
    private static final int STATUS_EMPTY_LOBBY = 2;
    private static final int STATUS_CLEAR = 3;
    private static final int STATUS_DETECTED = 4;
    private static final int STATUS_DELAY_CHECKS = 8;
    private static final int MENU_KEY = Keyboard.KEY_N;

    /** Defensive limits for data originating from a multiplayer server. */
    private static final int MAX_TAB_PLAYERS_SCANNED = 1000;
    private static final int MAX_TAB_TEXT_CHARS = 128;
    private static final int MAX_HUD_ENTRIES = 32;
    private static final int MAX_COMMAND_LIST_ENTRIES = 20;
    private static final int MAX_STATUS_MATCHES = 32;
    private static final int MAX_CHAT_MESSAGE_CHARS = 512;

    /** Thin red outline drawn around only the blacklisted player's IGN in the vanilla TAB list. */
    private static final int TAB_OUTLINE_COLOR = 0xFFFF3030;
    private static final int VANILLA_TAB_LIMIT = 80;
    private static final int VANILLA_TAB_ROWS_PER_COLUMN = 20;
    private static final int VANILLA_TAB_ROW_HEIGHT = 9;
    private static final int VANILLA_FONT_HEIGHT = 9;

    private static Field tabHeaderField;
    private static boolean tabHeaderFieldResolved;

    private final Minecraft mc;
    private final BlacklistManager blacklistManager;
    private final HudPositionManager hudPositionManager;
    /** UUID -> sanitized formatted TAB-list text, including server prefix/suffix/color codes. */
    private final Map<UUID, String> detectedPlayers = new LinkedHashMap<UUID, String>();
    /** UUID -> profile name; only presence is used to avoid repeated alerts. */
    private final Map<UUID, String> previousPlayers = new LinkedHashMap<UUID, String>();
    private int tickCounter;
    private int connectedChecks;
    private int lastStatus = STATUS_UNKNOWN;
    private int lastLobbyPlayerCount = -1;
    private boolean menuKeyWasDown;

    public LobbyWatcher(Minecraft mc, BlacklistManager blacklistManager) {
        this.mc = mc;
        this.blacklistManager = blacklistManager;
        this.hudPositionManager = new HudPositionManager(blacklistManager.getConfigDirectory());
        this.hudPositionManager.load();
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event == null || event.phase != TickEvent.Phase.END) return;

        handleMenuKey();

        if (++tickCounter < 5) return;
        tickCounter = 0;

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            resetConnectionState();
            return;
        }

        connectedChecks++;

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        lastLobbyPlayerCount = playerInfo == null ? 0 : playerInfo.size();

        if (blacklistManager.isEmpty()) {
            detectedPlayers.clear();
            previousPlayers.clear();
            announceStatus(STATUS_EMPTY_BLACKLIST,
                    "\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
            return;
        }

        Map<UUID, String> currentBlacklisted = new LinkedHashMap<UUID, String>();
        Map<UUID, String> currentProfileNames = new LinkedHashMap<UUID, String>();

        if (playerInfo == null || playerInfo.isEmpty()) {
            detectedPlayers.clear();
            previousPlayers.clear();
            announceStatus(STATUS_EMPTY_LOBBY,
                    "\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        int scanned = 0;
        for (NetworkPlayerInfo info : playerInfo) {
            if (++scanned > MAX_TAB_PLAYERS_SCANNED) break;
            if (info == null) continue;

            GameProfile profile;
            try {
                profile = info.func_178845_a();
            } catch (RuntimeException ignored) {
                continue;
            }
            if (profile == null) continue;

            UUID uuid = profile.getId();
            String name = profile.getName();
            if (uuid == null || !BlacklistManager.isValidPlayerName(name)) continue;

            if (blacklistManager.contains(name)) {
                String tabText = getFormattedTabText(info, profile);
                currentBlacklisted.put(uuid, tabText);
                currentProfileNames.put(uuid, name);
                if (!previousPlayers.containsKey(uuid)) alert(tabText);
            }
        }

        detectedPlayers.clear();
        detectedPlayers.putAll(currentBlacklisted);
        previousPlayers.clear();
        previousPlayers.putAll(currentProfileNames);

        if (currentBlacklisted.isEmpty()) {
            announceStatus(STATUS_CLEAR,
                    "\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
        } else {
            lastStatus = STATUS_DETECTED;
        }
    }

    private void handleMenuKey() {
        boolean down = Keyboard.isKeyDown(MENU_KEY);
        if (down && !menuKeyWasDown && mc.field_71439_g != null && mc.field_71462_r == null) {
            mc.func_147108_a(new BlacklistedLobbyMenu(blacklistManager, this));
        }
        menuKeyWasDown = down;
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
        if (mc.field_71439_g == null || mc.field_71466_p == null) return;
        if (mc.field_71462_r instanceof BlacklistedLobbyMenu) return;
        drawHud(mc.field_71466_p);
    }

    /**
     * Forge fires PLAYER_LIST/Post immediately after vanilla draws TAB. Recreate vanilla's
     * layout coordinates and draw only a one-pixel red outline around the profile IGN.
     */
    @SubscribeEvent
    public void onRenderPlayerList(RenderGameOverlayEvent.Post event) {
        if (event == null || event.type != RenderGameOverlayEvent.ElementType.PLAYER_LIST) return;
        if (blacklistManager.isEmpty() || mc.field_71439_g == null || mc.field_71466_p == null) return;
        if (mc.func_147114_u() == null || event.resolution == null) return;

        try {
            drawTabBlacklistOutlines(event.resolution.func_78326_a(), mc.field_71466_p);
        } catch (RuntimeException ignored) {
            // A modified TAB implementation should never be allowed to take down the client.
        }
    }

    private void drawTabBlacklistOutlines(int screenWidth, FontRenderer font) {
        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        if (playerInfo == null || playerInfo.isEmpty()) return;

        GuiPlayerTabOverlay tabOverlay = null;
        try {
            if (mc.field_71456_v != null) tabOverlay = mc.field_71456_v.func_175181_h();
        } catch (RuntimeException ignored) { }
        if (tabOverlay == null) return;

        List<NetworkPlayerInfo> players = new ArrayList<NetworkPlayerInfo>();
        int accepted = 0;
        for (NetworkPlayerInfo info : playerInfo) {
            if (accepted >= MAX_TAB_PLAYERS_SCANNED) break;
            if (info == null) continue;
            try {
                GameProfile profile = info.func_178845_a();
                if (profile == null || profile.getName() == null) continue;
                players.add(info);
                accepted++;
            } catch (RuntimeException ignored) { }
        }
        if (players.isEmpty()) return;

        Collections.sort(players, new Comparator<NetworkPlayerInfo>() {
            @Override
            public int compare(NetworkPlayerInfo a, NetworkPlayerInfo b) {
                try {
                    boolean aNormal = a.func_178848_b() != WorldSettings.GameType.SPECTATOR;
                    boolean bNormal = b.func_178848_b() != WorldSettings.GameType.SPECTATOR;
                    if (aNormal != bNormal) return aNormal ? -1 : 1;

                    ScorePlayerTeam aTeam = a.func_178850_i();
                    ScorePlayerTeam bTeam = b.func_178850_i();
                    String aTeamName = aTeam == null ? "" : aTeam.func_96661_b();
                    String bTeamName = bTeam == null ? "" : bTeam.func_96661_b();
                    int teamCompare = aTeamName.compareTo(bTeamName);
                    if (teamCompare != 0) return teamCompare;

                    String aName = a.func_178845_a().getName();
                    String bName = b.func_178845_a().getName();
                    return aName.compareTo(bName);
                } catch (RuntimeException ignored) {
                    return 0;
                }
            }
        });

        Scoreboard scoreboard = null;
        ScoreObjective objective = null;
        try {
            if (mc.field_71441_e != null) {
                scoreboard = mc.field_71441_e.func_96441_U();
                if (scoreboard != null) objective = scoreboard.func_96539_a(0);
            }
        } catch (RuntimeException ignored) {
            scoreboard = null;
            objective = null;
        }

        int maxNameWidth = 0;
        int maxScoreWidth = 0;
        for (NetworkPlayerInfo info : players) {
            try {
                String display = tabOverlay.func_175243_a(info);
                if (display != null) maxNameWidth = Math.max(maxNameWidth, font.func_78256_a(display));

                if (objective != null && scoreboard != null
                        && objective.func_178766_e() != IScoreObjectiveCriteria.EnumRenderType.HEARTS) {
                    Score score = scoreboard.func_96529_a(info.func_178845_a().getName(), objective);
                    if (score != null) {
                        maxScoreWidth = Math.max(maxScoreWidth,
                                font.func_78256_a(" " + score.func_96652_c()));
                    }
                }
            } catch (RuntimeException ignored) { }
        }

        if (players.size() > VANILLA_TAB_LIMIT) {
            players = new ArrayList<NetworkPlayerInfo>(players.subList(0, VANILLA_TAB_LIMIT));
        }

        int playerCount = players.size();
        int rows = playerCount;
        int columns = 1;
        while (rows > VANILLA_TAB_ROWS_PER_COLUMN) {
            columns++;
            rows = (playerCount + columns - 1) / columns;
        }

        boolean drawSkins = false;
        try {
            NetworkManager network = mc.func_147114_u().func_147298_b();
            drawSkins = mc.func_71387_A() || (network != null && network.func_179292_f());
        } catch (RuntimeException ignored) { }

        int scoreWidth = 0;
        if (objective != null) {
            try {
                scoreWidth = objective.func_178766_e() == IScoreObjectiveCriteria.EnumRenderType.HEARTS
                        ? 90 : maxScoreWidth;
            } catch (RuntimeException ignored) {
                scoreWidth = maxScoreWidth;
            }
        }

        int columnWidth = Math.min(columns * ((drawSkins ? 9 : 0) + maxNameWidth + scoreWidth + 13),
                screenWidth - 50) / columns;
        int left = screenWidth / 2 - (columnWidth * columns + (columns - 1) * 5) / 2;
        int top = 10;

        IChatComponent header = getTabHeader(tabOverlay);
        if (header != null) {
            try {
                List<String> headerLines = font.func_78271_c(header.func_150254_d(), screenWidth - 50);
                if (headerLines != null) top += headerLines.size() * VANILLA_FONT_HEIGHT + 1;
            } catch (RuntimeException ignored) { }
        }

        for (int index = 0; index < playerCount; index++) {
            NetworkPlayerInfo info = players.get(index);
            GameProfile profile;
            try {
                profile = info.func_178845_a();
            } catch (RuntimeException ignored) {
                continue;
            }
            if (profile == null || !BlacklistManager.isValidPlayerName(profile.getName())) continue;
            if (!blacklistManager.contains(profile.getName())) continue;

            String display;
            try {
                display = tabOverlay.func_175243_a(info);
            } catch (RuntimeException ignored) {
                continue;
            }
            if (display == null || display.isEmpty()) continue;

            int[] span = findVisibleNameSpan(display, profile.getName());
            if (span == null) continue;

            int column = index / rows;
            int row = index % rows;
            int textX = left + column * columnWidth + column * 5 + (drawSkins ? 9 : 0);
            int textY = top + row * VANILLA_TAB_ROW_HEIGHT;

            int prefixWidth = font.func_78256_a(display.substring(0, span[0]));
            int throughNameWidth = font.func_78256_a(display.substring(0, span[1]));
            int nameLeft = textX + prefixWidth;
            int nameRight = textX + throughNameWidth;

            if (nameRight > nameLeft) drawNameOutline(nameLeft, textY, nameRight);
        }
    }

    private IChatComponent getTabHeader(GuiPlayerTabOverlay overlay) {
        if (overlay == null) return null;
        if (!tabHeaderFieldResolved) {
            tabHeaderFieldResolved = true;
            String[] names = new String[] {"field_175256_i", "header"};
            for (String name : names) {
                try {
                    Field field = GuiPlayerTabOverlay.class.getDeclaredField(name);
                    field.setAccessible(true);
                    tabHeaderField = field;
                    break;
                } catch (Exception ignored) { }
            }
        }
        if (tabHeaderField == null) return null;
        try {
            Object value = tabHeaderField.get(overlay);
            return value instanceof IChatComponent ? (IChatComponent)value : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    /** Returns raw-string [start,end) indices for the visible IGN, ignoring Minecraft formatting codes. */
    private int[] findVisibleNameSpan(String formatted, String playerName) {
        if (formatted == null || playerName == null) return null;

        StringBuilder plain = new StringBuilder(formatted.length());
        List<Integer> rawStarts = new ArrayList<Integer>();
        List<Integer> rawEnds = new ArrayList<Integer>();
        for (int i = 0; i < formatted.length();) {
            char c = formatted.charAt(i);
            if (c == '\u00A7' && i + 1 < formatted.length()) {
                i += 2;
                continue;
            }
            plain.append(c);
            rawStarts.add(i);
            rawEnds.add(i + 1);
            i++;
        }

        String lowerPlain = plain.toString().toLowerCase(Locale.ROOT);
        String lowerName = playerName.toLowerCase(Locale.ROOT);
        int visibleStart = lowerPlain.lastIndexOf(lowerName);
        if (visibleStart < 0) return null;
        int visibleEnd = visibleStart + playerName.length();
        if (visibleEnd > rawEnds.size()) return null;

        return new int[] {rawStarts.get(visibleStart), rawEnds.get(visibleEnd - 1)};
    }

    private void drawNameOutline(int left, int top, int right) {
        int x1 = left - 1;
        int x2 = right + 1;
        int y1 = top - 1;
        int y2 = top + VANILLA_FONT_HEIGHT;

        Gui.func_73734_a(x1, y1, x2, y1 + 1, TAB_OUTLINE_COLOR);
        Gui.func_73734_a(x1, y2 - 1, x2, y2, TAB_OUTLINE_COLOR);
        Gui.func_73734_a(x1, y1 + 1, x1 + 1, y2 - 1, TAB_OUTLINE_COLOR);
        Gui.func_73734_a(x2 - 1, y1 + 1, x2, y2 - 1, TAB_OUTLINE_COLOR);
    }

    public void drawHud(FontRenderer font) {
        if (font == null) return;

        List<String> lines = getHudLines();
        int x = hudPositionManager.getX();
        int y = hudPositionManager.getY();
        int width = getHudContentWidth(font, lines);
        int height = getHudHeight(lines);

        Gui.func_73734_a(x - 4, y - 4, x + width + 5, y + height, 0x90000000);
        for (int i = 0; i < lines.size(); i++) {
            font.func_78276_b(lines.get(i), x, y + i * 10, 0xFFFFFF);
        }
    }

    public boolean isPointInsideHud(FontRenderer font, int mouseX, int mouseY) {
        if (font == null) return false;
        List<String> lines = getHudLines();
        int x = hudPositionManager.getX();
        int y = hudPositionManager.getY();
        int width = getHudContentWidth(font, lines);
        int height = getHudHeight(lines);
        return mouseX >= x - 4 && mouseX <= x + width + 5
                && mouseY >= y - 4 && mouseY <= y + height;
    }

    public void setHudPositionClamped(int x, int y, int screenWidth, int screenHeight, FontRenderer font) {
        if (font == null) return;
        List<String> lines = getHudLines();
        int width = getHudContentWidth(font, lines);
        int height = getHudHeight(lines);

        int minX = 4;
        int minY = 4;
        int maxX = Math.max(minX, screenWidth - width - 5);
        int maxY = Math.max(minY, screenHeight - height);

        int clampedX = Math.max(minX, Math.min(maxX, x));
        int clampedY = Math.max(minY, Math.min(maxY, y));
        hudPositionManager.setPosition(clampedX, clampedY);
    }

    public void clampHudToScreen(int screenWidth, int screenHeight, FontRenderer font) {
        setHudPositionClamped(hudPositionManager.getX(), hudPositionManager.getY(), screenWidth, screenHeight, font);
    }

    public void saveHudPosition() {
        hudPositionManager.save();
    }

    public int getHudX() {
        return hudPositionManager.getX();
    }

    public int getHudY() {
        return hudPositionManager.getY();
    }

    private List<String> getHudLines() {
        List<String> lines = new ArrayList<String>();
        lines.add("\u00A7c\u00A7lBlacklisted in Lobby \u00A77(" + detectedPlayers.size() + ")");

        if (blacklistManager.isEmpty()) {
            lines.add("\u00A7eNo players on blacklist");
        } else if (mc.func_147114_u() == null) {
            lines.add("\u00A77Not connected");
        } else if (lastLobbyPlayerCount == 0) {
            lines.add("\u00A7eNo players listed in lobby");
        } else if (detectedPlayers.isEmpty()) {
            lines.add("\u00A7aNone");
        } else {
            int shown = 0;
            for (String value : detectedPlayers.values()) {
                if (shown >= MAX_HUD_ENTRIES) break;
                lines.add(value);
                shown++;
            }
            int hidden = detectedPlayers.size() - shown;
            if (hidden > 0) {
                lines.add("\u00A77... and " + hidden + " more");
            }
        }
        return lines;
    }

    private int getHudContentWidth(FontRenderer font, List<String> lines) {
        int width = 0;
        for (String line : lines) {
            width = Math.max(width, font.func_78256_a(line));
        }
        return width;
    }

    private int getHudHeight(List<String> lines) {
        return lines.size() * 10 + 5;
    }

    private String getFormattedTabText(NetworkPlayerInfo info, GameProfile profile) {
        String fallback = profile == null ? "Unknown" : profile.getName();
        if (!BlacklistManager.isValidPlayerName(fallback)) fallback = "Unknown";

        try {
            IChatComponent displayName = info.func_178854_k();
            if (displayName != null) {
                String formatted = displayName.func_150254_d();
                if (formatted != null && !formatted.isEmpty()) {
                    return sanitizeServerText(formatted, fallback);
                }
            }
        } catch (RuntimeException ignored) { }

        try {
            ScorePlayerTeam team = info.func_178850_i();
            return sanitizeServerText(ScorePlayerTeam.func_96667_a(team, fallback), fallback);
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    /** Keeps normal Minecraft formatting codes but removes control characters/newlines and caps length. */
    private String sanitizeServerText(String input, String fallback) {
        if (input == null || input.isEmpty()) return fallback;
        StringBuilder out = new StringBuilder(Math.min(input.length(), MAX_TAB_TEXT_CHARS));
        for (int i = 0; i < input.length() && out.length() < MAX_TAB_TEXT_CHARS; i++) {
            char c = input.charAt(i);
            if (c < 32 || c == 127) continue;
            out.append(c);
        }
        if (out.length() == 0) return fallback;
        return out.toString();
    }

    public void handleCommand(String[] args) {
        if (args == null || args.length == 0) {
            showHelp();
            return;
        }

        String action = args[0].toLowerCase(Locale.ROOT);

        if ("add".equals(action)) {
            if (args.length != 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw add <name>");
                return;
            }
            String name = args[1];
            if (!BlacklistManager.isValidPlayerName(name)) {
                chat("\u00A7c[Blacklist] \u00A7fInvalid Minecraft username. Use 1-16 letters, numbers, or underscores.");
                return;
            }
            if (blacklistManager.contains(name)) {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f is already on the blacklist.");
                return;
            }
            if (blacklistManager.isAtCapacity()) {
                chat("\u00A7c[Blacklist] \u00A7fBlacklist limit reached (" + BlacklistManager.MAX_ENTRIES + ").");
                return;
            }
            if (blacklistManager.add(name)) {
                chat("\u00A7a[Blacklist] \u00A7fAdded \u00A7b" + name + "\u00A7f to the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7c[Blacklist] \u00A7fCould not add that player.");
            }
            return;
        }

        if ("remove".equals(action) || "del".equals(action) || "delete".equals(action)) {
            if (args.length != 2) {
                chat("\u00A7e[Blacklist] \u00A7fUsage: \u00A7b/blw remove <name>");
                return;
            }
            String name = args[1];
            if (!BlacklistManager.isValidPlayerName(name)) {
                chat("\u00A7c[Blacklist] \u00A7fInvalid Minecraft username.");
                return;
            }
            if (blacklistManager.remove(name)) {
                chat("\u00A7a[Blacklist] \u00A7fRemoved \u00A7b" + name + "\u00A7f from the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7b" + name + "\u00A7f was not on the blacklist.");
            }
            return;
        }

        if ("list".equals(action)) {
            showBlacklist();
            return;
        }

        if ("check".equals(action) || "status".equals(action)) {
            printCurrentStatus();
            return;
        }

        if ("clear".equals(action)) {
            if (blacklistManager.clear()) {
                chat("\u00A7a[Blacklist] \u00A7fCleared the blacklist.");
                forceStatusRefresh();
            } else {
                chat("\u00A7e[Blacklist] \u00A7fThe blacklist is already empty.");
            }
            return;
        }

        if ("help".equals(action)) {
            showHelp();
            return;
        }

        chat("\u00A7c[Blacklist] \u00A7fUnknown command. Use \u00A7b/blw help\u00A7f.");
    }

    private void showHelp() {
        chat("\u00A7b[Blacklist] \u00A7fCommands:");
        chat("\u00A77/blw add <name> \u00A7f- add a player");
        chat("\u00A77/blw remove <name> \u00A7f- remove a player");
        chat("\u00A77/blw list \u00A7f- show your blacklist");
        chat("\u00A77/blw check \u00A7f- check the current lobby");
        chat("\u00A77/blw clear \u00A7f- remove everyone from the blacklist");
        chat("\u00A77N \u00A7f- open the Blacklisted Lobby Watcher menu");
    }

    private void showBlacklist() {
        List<String> entries = blacklistManager.getEntries();
        if (entries.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist.");
            return;
        }

        int count = Math.min(entries.size(), MAX_COMMAND_LIST_ENTRIES);
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) builder.append("\u00A77, \u00A7b");
            builder.append(entries.get(i));
        }
        chat("\u00A7b[Blacklist] \u00A7f" + entries.size() + " player(s): \u00A7b" + builder.toString());
        if (entries.size() > count) {
            chat("\u00A77[Blacklist] " + (entries.size() - count) + " more saved. Press N -> Blacklist Settings to view them.");
        }
    }

    private void printCurrentStatus() {
        if (blacklistManager.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are on your blacklist. Use \u00A7b/blw add <name>\u00A7f.");
            return;
        }

        if (mc.field_71439_g == null || mc.func_147114_u() == null) {
            chat("\u00A7e[Blacklist] \u00A7fYou are not currently connected to a lobby.");
            return;
        }

        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        if (playerInfo == null || playerInfo.isEmpty()) {
            chat("\u00A7e[Blacklist] \u00A7fNo players are currently listed in this lobby.");
            return;
        }

        List<String> matches = findMatches(playerInfo);
        if (matches.isEmpty()) {
            chat("\u00A7a[Blacklist] \u00A7fNo blacklisted players are listed in this lobby.");
            return;
        }

        int count = Math.min(matches.size(), MAX_STATUS_MATCHES);
        for (int i = 0; i < count; i++) {
            chat("\u00A7c[Blacklist] \u00A7f" + matches.get(i) + "\u00A7c is in the lobby.");
        }
        if (matches.size() > count) {
            chat("\u00A77[Blacklist] " + (matches.size() - count) + " additional matches omitted from chat.");
        }
    }

    private List<String> findMatches(Collection<NetworkPlayerInfo> playerInfo) {
        List<String> matches = new ArrayList<String>();
        int scanned = 0;
        for (NetworkPlayerInfo info : playerInfo) {
            if (++scanned > MAX_TAB_PLAYERS_SCANNED) break;
            if (info == null) continue;
            try {
                GameProfile profile = info.func_178845_a();
                if (profile == null || !BlacklistManager.isValidPlayerName(profile.getName())) continue;
                if (blacklistManager.contains(profile.getName())) {
                    matches.add(getFormattedTabText(info, profile));
                }
            } catch (RuntimeException ignored) { }
        }
        return matches;
    }

    private void forceStatusRefresh() {
        lastStatus = STATUS_UNKNOWN;
        if (connectedChecks < STATUS_DELAY_CHECKS) {
            connectedChecks = STATUS_DELAY_CHECKS;
        }
    }

    private void announceStatus(int status, String message) {
        if (connectedChecks < STATUS_DELAY_CHECKS) return;
        if (lastStatus == status) return;
        lastStatus = status;
        chat(message);
    }

    private void resetConnectionState() {
        detectedPlayers.clear();
        previousPlayers.clear();
        connectedChecks = 0;
        lastStatus = STATUS_UNKNOWN;
        lastLobbyPlayerCount = -1;
    }

    private void alert(String tabText) {
        chat("\u00A7c[Blacklist] \u00A7f" + tabText + "\u00A7c is in the lobby.");
    }

    private void chat(String message) {
        if (mc.field_71439_g == null || message == null) return;
        String safe = sanitizeLocalChat(message);
        mc.field_71439_g.func_145747_a(new ChatComponentText(safe));
    }

    private String sanitizeLocalChat(String message) {
        StringBuilder out = new StringBuilder(Math.min(message.length(), MAX_CHAT_MESSAGE_CHARS));
        for (int i = 0; i < message.length() && out.length() < MAX_CHAT_MESSAGE_CHARS; i++) {
            char c = message.charAt(i);
            if (c < 32 || c == 127) continue;
            out.append(c);
        }
        return out.toString();
    }

    public List<String> getDetectedPlayers() {
        return Collections.unmodifiableList(new ArrayList<String>(detectedPlayers.values()));
    }
}
