package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class BlacklistSettingsScreen extends GuiScreen {
    private static final int BUTTON_BACK = 0;
    private static final int BUTTON_SORT = 4;

    private static final int SORT_A_TO_Z = 0;
    private static final int SORT_Z_TO_A = 1;
    private static final int SORT_ADDED_OLDEST = 2;
    private static final int SORT_ADDED_NEWEST = 3;
    private static final int SORT_MODE_COUNT = 4;

    private static final int LIST_WIDTH = 290;
    private static final int ROW_HEIGHT = 14;
    private static final int REMOVE_AREA_WIDTH = 20;
    private static final int SCROLLBAR_WIDTH = 5;
    private static final int WHEEL_ROWS = 3;

    private final GuiScreen parent;
    private final BlacklistManager blacklistManager;

    private int sortMode = SORT_A_TO_Z;
    private int scrollRow;
    private boolean draggingScrollbar;
    private int scrollbarGrabOffset;

    public BlacklistSettingsScreen(GuiScreen parent, BlacklistManager blacklistManager) {
        this.parent = parent;
        this.blacklistManager = blacklistManager;
    }

    @Override
    public void func_73866_w_() {
        int centerX = this.field_146294_l / 2;
        int bottom = this.field_146295_m - 28;
        int left = getListLeft();

        this.field_146292_n.add(new GuiButton(BUTTON_BACK, centerX - 50, bottom, 100, 20, "Back"));
        this.field_146292_n.add(new GuiButton(BUTTON_SORT, left, getSortButtonY(), 150, 20, getSortLabel()));
        clampScroll();
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        if (draggingScrollbar) {
            updateScrollbarDrag(mouseY);
        }

        Gui.func_73734_a(0, 0, this.field_146294_l, this.field_146295_m, 0xD0101010);
        drawCentered("\u00A7c\u00A7lBlacklist Settings", 16, 0xFFFFFF);

        int left = getListLeft();
        int y = 38;
        this.field_146289_q.func_78276_b("\u00A7bCommands", left, y, 0xFFFFFF);
        y += 12;
        this.field_146289_q.func_78276_b("\u00A77/blw add <name> \u00A7f- add a player", left, y, 0xFFFFFF);
        y += 10;
        this.field_146289_q.func_78276_b("\u00A77/blw remove <name> \u00A7f- remove a player", left, y, 0xFFFFFF);
        y += 10;
        this.field_146289_q.func_78276_b("\u00A77/blw list \u00A7f- list saved players", left, y, 0xFFFFFF);
        y += 10;
        this.field_146289_q.func_78276_b("\u00A77/blw check \u00A7f- check this lobby", left, y, 0xFFFFFF);
        y += 10;
        this.field_146289_q.func_78276_b("\u00A77/blw clear \u00A7f- clear the blacklist", left, y, 0xFFFFFF);

        List<String> entries = getSortedEntries();
        clampScroll(entries.size());

        int titleY = getListTitleY();
        this.field_146289_q.func_78276_b(
                "\u00A7bCurrent blacklist \u00A77(" + entries.size() + ")",
                left, titleY, 0xFFFFFF);
        this.field_146289_q.func_78276_b(
                "\u00A77Scroll to browse  \u00A78|  \u00A7cX \u00A77removes",
                left + 145, titleY, 0xFFFFFF);

        drawList(entries, mouseX, mouseY);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    private void drawList(List<String> entries, int mouseX, int mouseY) {
        int left = getListLeft();
        int right = left + LIST_WIDTH;
        int top = getListTop();
        int bottom = getListBottom();

        Gui.func_73734_a(left, top, right, bottom, 0x80000000);

        if (entries.isEmpty()) {
            this.field_146289_q.func_78276_b("\u00A7eNo players are currently blacklisted.", left + 7, top + 8, 0xFFFFFF);
            return;
        }

        int visibleRows = getVisibleRows();
        int end = Math.min(entries.size(), scrollRow + visibleRows);

        for (int index = scrollRow; index < end; index++) {
            int visibleIndex = index - scrollRow;
            int rowTop = top + visibleIndex * ROW_HEIGHT;
            int rowBottom = Math.min(bottom, rowTop + ROW_HEIGHT);
            boolean hovered = mouseX >= left && mouseX < right - SCROLLBAR_WIDTH
                    && mouseY >= rowTop && mouseY < rowBottom;

            if (hovered) {
                Gui.func_73734_a(left + 1, rowTop, right - SCROLLBAR_WIDTH - 1, rowBottom, 0x403F3F3F);
            }

            String name = entries.get(index);
            this.field_146289_q.func_78276_b("\u00A7c" + name, left + 7, rowTop + 3, 0xFFFFFF);

            int removeLeft = getRemoveLeft();
            boolean removeHovered = mouseX >= removeLeft && mouseX < getRemoveRight()
                    && mouseY >= rowTop && mouseY < rowBottom;
            if (removeHovered) {
                Gui.func_73734_a(removeLeft, rowTop + 1, getRemoveRight(), rowBottom - 1, 0x60AA0000);
            }
            this.field_146289_q.func_78276_b(removeHovered ? "\u00A7f\u00A7lX" : "\u00A7c\u00A7lX",
                    removeLeft + 6, rowTop + 3, 0xFFFFFF);
        }

        drawScrollbar(entries.size());
    }

    private void drawScrollbar(int entryCount) {
        int visibleRows = getVisibleRows();
        if (entryCount <= visibleRows) return;

        int trackLeft = getScrollbarLeft();
        int trackTop = getListTop();
        int trackBottom = getListBottom();
        Gui.func_73734_a(trackLeft, trackTop, trackLeft + SCROLLBAR_WIDTH, trackBottom, 0x80444444);

        int thumbTop = getScrollbarThumbTop(entryCount);
        int thumbHeight = getScrollbarThumbHeight(entryCount);
        Gui.func_73734_a(trackLeft, thumbTop, trackLeft + SCROLLBAR_WIDTH, thumbTop + thumbHeight, 0xFFAAAAAA);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0) {
            List<String> entries = getSortedEntries();
            clampScroll(entries.size());

            if (isInsideList(mouseX, mouseY)) {
                int row = (mouseY - getListTop()) / ROW_HEIGHT;
                int index = scrollRow + row;
                if (mouseX >= getRemoveLeft() && mouseX < getRemoveRight() && index >= 0 && index < entries.size()) {
                    blacklistManager.remove(entries.get(index));
                    clampScroll();
                    return;
                }
            }

            if (entries.size() > getVisibleRows()
                    && mouseX >= getScrollbarLeft()
                    && mouseX < getScrollbarLeft() + SCROLLBAR_WIDTH
                    && mouseY >= getListTop()
                    && mouseY < getListBottom()) {
                int thumbTop = getScrollbarThumbTop(entries.size());
                int thumbHeight = getScrollbarThumbHeight(entries.size());
                draggingScrollbar = true;
                if (mouseY >= thumbTop && mouseY < thumbTop + thumbHeight) {
                    scrollbarGrabOffset = mouseY - thumbTop;
                } else {
                    scrollbarGrabOffset = thumbHeight / 2;
                    updateScrollbarDrag(mouseY);
                }
                return;
            }
        }

        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (draggingScrollbar && clickedMouseButton == 0) {
            updateScrollbarDrag(mouseY);
            return;
        }
        super.func_146273_a(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
    }

    @Override
    protected void func_146286_b(int mouseX, int mouseY, int state) {
        if (draggingScrollbar && state == 0) {
            updateScrollbarDrag(mouseY);
            draggingScrollbar = false;
            return;
        }
        super.func_146286_b(mouseX, mouseY, state);
    }

    @Override
    public void func_146274_d() {
        super.func_146274_d();
        int wheel = Mouse.getEventDWheel();
        if (wheel == 0) return;

        if (wheel > 0) {
            scrollRow -= WHEEL_ROWS;
        } else {
            scrollRow += WHEEL_ROWS;
        }
        clampScroll();
    }

    @Override
    public void func_146281_b() {
        draggingScrollbar = false;
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == BUTTON_BACK) {
            this.field_146297_k.func_147108_a(parent);
            return;
        }

        if (button.field_146127_k == BUTTON_SORT) {
            sortMode = (sortMode + 1) % SORT_MODE_COUNT;
            scrollRow = 0;
            button.field_146126_j = getSortLabel();
        }
    }

    private List<String> getSortedEntries() {
        List<String> entries = new ArrayList<String>(blacklistManager.getEntries());
        if (sortMode == SORT_A_TO_Z) {
            Collections.sort(entries, String.CASE_INSENSITIVE_ORDER);
        } else if (sortMode == SORT_Z_TO_A) {
            Collections.sort(entries, Collections.reverseOrder(String.CASE_INSENSITIVE_ORDER));
        } else if (sortMode == SORT_ADDED_NEWEST) {
            Collections.reverse(entries);
        }
        return entries;
    }

    private String getSortLabel() {
        if (sortMode == SORT_Z_TO_A) return "Sort by: Z-A";
        if (sortMode == SORT_ADDED_OLDEST) return "Sort by: Added oldest";
        if (sortMode == SORT_ADDED_NEWEST) return "Sort by: Added newest";
        return "Sort by: A-Z";
    }

    private void updateScrollbarDrag(int mouseY) {
        int entryCount = blacklistManager.size();
        int visibleRows = getVisibleRows();
        int maxScroll = Math.max(0, entryCount - visibleRows);
        if (maxScroll <= 0) {
            scrollRow = 0;
            return;
        }

        int thumbHeight = getScrollbarThumbHeight(entryCount);
        int trackTop = getListTop();
        int travel = Math.max(1, (getListBottom() - trackTop) - thumbHeight);
        int desiredTop = mouseY - scrollbarGrabOffset;
        int relative = Math.max(0, Math.min(travel, desiredTop - trackTop));
        scrollRow = Math.round((relative / (float) travel) * maxScroll);
        clampScroll(entryCount);
    }

    private int getScrollbarThumbTop(int entryCount) {
        int visibleRows = getVisibleRows();
        int maxScroll = Math.max(1, entryCount - visibleRows);
        int thumbHeight = getScrollbarThumbHeight(entryCount);
        int travel = Math.max(1, (getListBottom() - getListTop()) - thumbHeight);
        return getListTop() + Math.round((scrollRow / (float) maxScroll) * travel);
    }

    private int getScrollbarThumbHeight(int entryCount) {
        int trackHeight = Math.max(1, getListBottom() - getListTop());
        int visibleRows = getVisibleRows();
        int calculated = Math.round(trackHeight * (visibleRows / (float) Math.max(1, entryCount)));
        return Math.max(12, Math.min(trackHeight, calculated));
    }

    private void clampScroll() {
        clampScroll(blacklistManager.size());
    }

    private void clampScroll(int entryCount) {
        int maxScroll = Math.max(0, entryCount - getVisibleRows());
        if (scrollRow < 0) scrollRow = 0;
        if (scrollRow > maxScroll) scrollRow = maxScroll;
    }

    private int getListLeft() {
        return Math.max(10, this.field_146294_l / 2 - LIST_WIDTH / 2);
    }

    private int getSortButtonY() {
        return 101;
    }

    private int getListTitleY() {
        return 126;
    }

    private int getListTop() {
        return 139;
    }

    private int getListBottom() {
        return Math.max(getListTop() + ROW_HEIGHT, this.field_146295_m - 36);
    }

    private int getVisibleRows() {
        return Math.max(1, (getListBottom() - getListTop()) / ROW_HEIGHT);
    }

    private int getRemoveLeft() {
        return getListLeft() + LIST_WIDTH - SCROLLBAR_WIDTH - REMOVE_AREA_WIDTH;
    }

    private int getRemoveRight() {
        return getListLeft() + LIST_WIDTH - SCROLLBAR_WIDTH;
    }

    private int getScrollbarLeft() {
        return getListLeft() + LIST_WIDTH - SCROLLBAR_WIDTH;
    }

    private boolean isInsideList(int mouseX, int mouseY) {
        return mouseX >= getListLeft()
                && mouseX < getScrollbarLeft()
                && mouseY >= getListTop()
                && mouseY < getListBottom();
    }

    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
