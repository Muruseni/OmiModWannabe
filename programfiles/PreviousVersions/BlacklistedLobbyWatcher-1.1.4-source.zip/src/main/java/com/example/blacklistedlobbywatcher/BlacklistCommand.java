package com.example.blacklistedlobbywatcher;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;

import java.util.Arrays;
import java.util.List;

/**
 * Lunar/Ichor 1.8.9 loads Minecraft members by their SRG/runtime names.
 * These method names are therefore intentionally SRG rather than MCP names:
 * func_71517_b = getCommandName
 * func_71518_a = getCommandUsage
 * func_71515_b = processCommand
 * func_71514_a = getCommandAliases
 * func_71519_b = canCommandSenderUseCommand
 */
public class BlacklistCommand extends CommandBase {
    private final LobbyWatcher watcher;

    public BlacklistCommand(LobbyWatcher watcher) {
        this.watcher = watcher;
    }

    @Override
    public String func_71517_b() {
        return "blw";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "/blw help";
    }

    @Override
    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
        watcher.handleCommand(args);
    }

    @Override
    public List<String> func_71514_a() {
        return Arrays.asList("bl", "blacklist");
    }

    @Override
    public boolean func_71519_b(ICommandSender sender) {
        return true;
    }
}
