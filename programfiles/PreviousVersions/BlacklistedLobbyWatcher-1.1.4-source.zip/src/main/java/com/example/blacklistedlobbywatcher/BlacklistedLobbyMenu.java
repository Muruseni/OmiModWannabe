package com.example.blacklistedlobbywatcher;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class BlacklistedLobbyMenu extends GuiScreen {
    private final BlacklistManager blacklistManager;
    private final LobbyWatcher lobbyWatcher;
    private boolean draggingHud;
    private int dragOffsetX;
    private int dragOffsetY;

    public BlacklistedLobbyMenu(BlacklistManager blacklistManager, LobbyWatcher lobbyWatcher) {
        this.blacklistManager = blacklistManager;
        this.lobbyWatcher = lobbyWatcher;
    }

    @Override
    public void func_73866_w_() {
        int centerX = this.field_146294_l / 2;
        int centerY = this.field_146295_m / 2;
        this.field_146292_n.add(new GuiButton(1, centerX - 100, centerY - 10, 200, 20, "Blacklist Settings"));
        this.field_146292_n.add(new GuiButton(0, centerX - 100, centerY + 20, 200, 20, "Close"));
        lobbyWatcher.clampHudToScreen(this.field_146294_l, this.field_146295_m, this.field_146289_q);
        lobbyWatcher.saveHudPosition();
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        if (draggingHud) {
            lobbyWatcher.setHudPositionClamped(
                    mouseX - dragOffsetX,
                    mouseY - dragOffsetY,
                    this.field_146294_l,
                    this.field_146295_m,
                    this.field_146289_q);
        }

        Gui.func_73734_a(0, 0, this.field_146294_l, this.field_146295_m, 0xD0101010);
        drawCentered("\u00A7c\u00A7lBlacklisted Lobby Watcher", this.field_146295_m / 2 - 70, 0xFFFFFF);
        drawCentered("\u00A7eClick and drag the blacklist HUD to move it", this.field_146295_m / 2 - 53, 0xFFFFFF);
        drawCentered("\u00A77Its position is saved when you release the mouse.", this.field_146295_m / 2 - 40, 0xFFFFFF);

        super.func_73863_a(mouseX, mouseY, partialTicks);
        lobbyWatcher.drawHud(this.field_146289_q);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && lobbyWatcher.isPointInsideHud(this.field_146289_q, mouseX, mouseY)) {
            draggingHud = true;
            dragOffsetX = mouseX - lobbyWatcher.getHudX();
            dragOffsetY = mouseY - lobbyWatcher.getHudY();
            return;
        }
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (draggingHud && clickedMouseButton == 0) {
            lobbyWatcher.setHudPositionClamped(
                    mouseX - dragOffsetX,
                    mouseY - dragOffsetY,
                    this.field_146294_l,
                    this.field_146295_m,
                    this.field_146289_q);
            return;
        }
        super.func_146273_a(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
    }

    @Override
    protected void func_146286_b(int mouseX, int mouseY, int state) {
        if (draggingHud && state == 0) {
            lobbyWatcher.setHudPositionClamped(
                    mouseX - dragOffsetX,
                    mouseY - dragOffsetY,
                    this.field_146294_l,
                    this.field_146295_m,
                    this.field_146289_q);
            draggingHud = false;
            lobbyWatcher.saveHudPosition();
            return;
        }
        super.func_146286_b(mouseX, mouseY, state);
    }

    @Override
    public void func_146281_b() {
        draggingHud = false;
        lobbyWatcher.saveHudPosition();
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == 1) {
            this.field_146297_k.func_147108_a(new BlacklistSettingsScreen(this, blacklistManager));
        } else if (button.field_146127_k == 0) {
            this.field_146297_k.func_147108_a(null);
        }
    }

    private void drawCentered(String text, int y, int color) {
        int x = (this.field_146294_l - this.field_146289_q.func_78256_a(text)) / 2;
        this.field_146289_q.func_78276_b(text, x, y, color);
    }
}
