# Blacklisted Lobby Watcher 1.1.4

Minecraft 1.8.9 Forge/Lunar compatibility build.

## Draggable lobby HUD
The always-visible HUD shows blacklisted players currently found in TAB, preserving the formatted TAB-list text where available (for example `[120] Muruseni_`).

Press **N** to open the Blacklisted Lobby Watcher menu. While that menu is open, click and drag the HUD box anywhere on screen. Its position is saved locally.

## Blacklist settings
Press **N**, then open **Blacklist Settings**.

The settings screen now includes:
- A scrollable blacklist. Use the mouse wheel or drag the scrollbar.
- A red **X** beside every saved IGN. Click it to remove that player immediately.
- A **Sort by** button directly above the list.
- Sort modes: **A-Z**, **Z-A**, **Added oldest**, and **Added newest**.
- The existing command reference remains visible above the list.

The list UI is structured so the same behavior can be reused for a whitelist later.

## Local chat commands
- `/blw add <name>` - add a player
- `/blw remove <name>` - remove a player
- `/blw list` - list blacklisted players
- `/blw check` - manually check the current lobby
- `/blw clear` - clear the blacklist
- `/blw help` - show help

`/bl` and `/blacklist` can be used instead of `/blw`.

## Security hardening retained from 1.1.2
- Validates Minecraft usernames (1-16 letters, digits, or underscores).
- Caps the saved blacklist at 1000 entries.
- Rejects oversized/malformed config files safely.
- Uses temporary-file replacement when saving the blacklist.
- Sanitizes and limits server-provided TAB text before rendering it.
- Bounds TAB scanning and HUD/chat output.

Blacklist data remains in `config/blacklisted_lobby_watcher.json` and the HUD position remains in `config/blacklisted_lobby_watcher_hud.properties`.


## TAB blacklist outline (1.1.4)
When the vanilla TAB player list is open, a blacklisted player's actual IGN is surrounded by a thin red outline. Team/rank/level prefixes and suffixes are not boxed. The overlay follows vanilla 1.8.9 TAB columns, skin spacing and header height and is rendered after the normal player list.
