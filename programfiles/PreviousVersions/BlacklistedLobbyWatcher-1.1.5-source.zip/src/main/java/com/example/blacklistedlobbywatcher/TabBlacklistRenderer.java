package com.example.blacklistedlobbywatcher;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.network.NetworkManager;
import net.minecraft.scoreboard.IScoreObjectiveCriteria;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.WorldSettings;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Visual-only TAB overlay. Kept separate from LobbyWatcher so rendering failures or
 * Lunar-specific TAB quirks cannot interfere with blacklist detection/chat/HUD state.
 */
public final class TabBlacklistRenderer {
    private static final int TAB_OUTLINE_COLOR = 0xFFFF3030;
    private static final int MAX_TAB_PLAYERS_SCANNED = 1000;
    private static final int MAX_TAB_TEXT_CHARS = 128;
    private static final int VANILLA_TAB_LIMIT = 80;
    private static final int VANILLA_TAB_ROWS_PER_COLUMN = 20;
    private static final int VANILLA_TAB_ROW_HEIGHT = 9;
    private static final int VANILLA_FONT_HEIGHT = 9;

    private static Field tabHeaderField;
    private static boolean tabHeaderFieldResolved;

    private final Minecraft mc;
    private final BlacklistManager blacklistManager;
    private final LobbyWatcher lobbyWatcher;

    public TabBlacklistRenderer(Minecraft mc, BlacklistManager blacklistManager, LobbyWatcher lobbyWatcher) {
        this.mc = mc;
        this.blacklistManager = blacklistManager;
        this.lobbyWatcher = lobbyWatcher;
    }

    @SubscribeEvent
    public void onRenderPlayerList(RenderGameOverlayEvent.Post event) {
        if (event == null || event.type != RenderGameOverlayEvent.ElementType.PLAYER_LIST) return;
        if (blacklistManager.isEmpty() || mc.field_71439_g == null || mc.field_71466_p == null) return;
        if (mc.func_147114_u() == null || event.resolution == null) return;

        try {
            drawTabBlacklistOutlines(event.resolution.func_78326_a(), mc.field_71466_p);
        } catch (Throwable ignored) {
            // Visual decoration must never be able to disrupt the actual lobby watcher.
        }
    }

    private void drawTabBlacklistOutlines(int screenWidth, FontRenderer font) {
        Collection<NetworkPlayerInfo> playerInfo = mc.func_147114_u().func_175106_d();
        if (playerInfo == null || playerInfo.isEmpty()) return;

        GuiPlayerTabOverlay tabOverlay = null;
        try {
            if (mc.field_71456_v != null) tabOverlay = mc.field_71456_v.func_175181_h();
        } catch (Throwable ignored) { }
        if (tabOverlay == null) return;

        List<NetworkPlayerInfo> players = new ArrayList<NetworkPlayerInfo>();
        int accepted = 0;
        for (NetworkPlayerInfo info : playerInfo) {
            if (accepted >= MAX_TAB_PLAYERS_SCANNED) break;
            if (info == null) continue;
            try {
                GameProfile profile = info.func_178845_a();
                if (profile == null || profile.getName() == null) continue;
                players.add(info);
                accepted++;
            } catch (Throwable ignored) { }
        }
        if (players.isEmpty()) return;

        Collections.sort(players, new Comparator<NetworkPlayerInfo>() {
            @Override
            public int compare(NetworkPlayerInfo a, NetworkPlayerInfo b) {
                try {
                    boolean aNormal = a.func_178848_b() != WorldSettings.GameType.SPECTATOR;
                    boolean bNormal = b.func_178848_b() != WorldSettings.GameType.SPECTATOR;
                    if (aNormal != bNormal) return aNormal ? -1 : 1;

                    ScorePlayerTeam aTeam = a.func_178850_i();
                    ScorePlayerTeam bTeam = b.func_178850_i();
                    String aTeamName = aTeam == null ? "" : aTeam.func_96661_b();
                    String bTeamName = bTeam == null ? "" : bTeam.func_96661_b();
                    int teamCompare = aTeamName.compareTo(bTeamName);
                    if (teamCompare != 0) return teamCompare;

                    String aName = a.func_178845_a().getName();
                    String bName = b.func_178845_a().getName();
                    return aName.compareTo(bName);
                } catch (Throwable ignored) {
                    return 0;
                }
            }
        });

        Scoreboard scoreboard = null;
        ScoreObjective objective = null;
        try {
            if (mc.field_71441_e != null) {
                scoreboard = mc.field_71441_e.func_96441_U();
                if (scoreboard != null) objective = scoreboard.func_96539_a(0);
            }
        } catch (Throwable ignored) {
            scoreboard = null;
            objective = null;
        }

        int maxNameWidth = 0;
        int maxScoreWidth = 0;
        for (NetworkPlayerInfo info : players) {
            try {
                String display = sanitizeDisplay(tabOverlay.func_175243_a(info));
                if (display != null) maxNameWidth = Math.max(maxNameWidth, font.func_78256_a(display));

                if (objective != null && scoreboard != null
                        && objective.func_178766_e() != IScoreObjectiveCriteria.EnumRenderType.HEARTS) {
                    Score score = scoreboard.func_96529_a(info.func_178845_a().getName(), objective);
                    if (score != null) {
                        maxScoreWidth = Math.max(maxScoreWidth,
                                font.func_78256_a(" " + score.func_96652_c()));
                    }
                }
            } catch (Throwable ignored) { }
        }

        if (players.size() > VANILLA_TAB_LIMIT) {
            players = new ArrayList<NetworkPlayerInfo>(players.subList(0, VANILLA_TAB_LIMIT));
        }

        int playerCount = players.size();
        int rows = playerCount;
        int columns = 1;
        while (rows > VANILLA_TAB_ROWS_PER_COLUMN) {
            columns++;
            rows = (playerCount + columns - 1) / columns;
        }

        boolean drawSkins = false;
        try {
            NetworkManager network = mc.func_147114_u().func_147298_b();
            drawSkins = mc.func_71387_A() || (network != null && network.func_179292_f());
        } catch (Throwable ignored) { }

        int scoreWidth = 0;
        if (objective != null) {
            try {
                scoreWidth = objective.func_178766_e() == IScoreObjectiveCriteria.EnumRenderType.HEARTS
                        ? 90 : maxScoreWidth;
            } catch (Throwable ignored) {
                scoreWidth = maxScoreWidth;
            }
        }

        int columnWidth = Math.min(columns * ((drawSkins ? 9 : 0) + maxNameWidth + scoreWidth + 13),
                screenWidth - 50) / columns;
        int left = screenWidth / 2 - (columnWidth * columns + (columns - 1) * 5) / 2;
        int top = 10;

        IChatComponent header = getTabHeader(tabOverlay);
        if (header != null) {
            try {
                String headerText = sanitizeDisplay(header.func_150254_d());
                List<String> headerLines = font.func_78271_c(headerText, screenWidth - 50);
                if (headerLines != null) top += headerLines.size() * VANILLA_FONT_HEIGHT + 1;
            } catch (Throwable ignored) { }
        }

        for (int index = 0; index < playerCount; index++) {
            NetworkPlayerInfo info = players.get(index);
            GameProfile profile;
            try {
                profile = info.func_178845_a();
            } catch (Throwable ignored) {
                continue;
            }

            String matchedName = lobbyWatcher.findBlacklistedName(info, profile);
            if (matchedName == null) continue;

            String display;
            try {
                display = sanitizeDisplay(tabOverlay.func_175243_a(info));
            } catch (Throwable ignored) {
                continue;
            }
            if (display == null || display.isEmpty()) continue;

            int[] span = findVisibleNameSpan(display, matchedName);
            if (span == null) continue;

            int column = index / rows;
            int row = index % rows;
            int textX = left + column * columnWidth + column * 5 + (drawSkins ? 9 : 0);
            int textY = top + row * VANILLA_TAB_ROW_HEIGHT;

            int prefixWidth = font.func_78256_a(display.substring(0, span[0]));
            int throughNameWidth = font.func_78256_a(display.substring(0, span[1]));
            int nameLeft = textX + prefixWidth;
            int nameRight = textX + throughNameWidth;

            if (nameRight > nameLeft) drawNameOutline(nameLeft, textY, nameRight);
        }
    }

    private String sanitizeDisplay(String input) {
        if (input == null || input.isEmpty()) return "";
        StringBuilder out = new StringBuilder(Math.min(input.length(), MAX_TAB_TEXT_CHARS));
        for (int i = 0; i < input.length() && out.length() < MAX_TAB_TEXT_CHARS; i++) {
            char c = input.charAt(i);
            if (c < 32 || c == 127) continue;
            out.append(c);
        }
        return out.toString();
    }

    private IChatComponent getTabHeader(GuiPlayerTabOverlay overlay) {
        if (overlay == null) return null;
        if (!tabHeaderFieldResolved) {
            tabHeaderFieldResolved = true;
            String[] names = new String[] {"field_175256_i", "header"};
            for (String name : names) {
                try {
                    Field field = GuiPlayerTabOverlay.class.getDeclaredField(name);
                    field.setAccessible(true);
                    tabHeaderField = field;
                    break;
                } catch (Throwable ignored) { }
            }
        }
        if (tabHeaderField == null) return null;
        try {
            Object value = tabHeaderField.get(overlay);
            return value instanceof IChatComponent ? (IChatComponent)value : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private int[] findVisibleNameSpan(String formatted, String playerName) {
        if (formatted == null || playerName == null) return null;

        StringBuilder plain = new StringBuilder(formatted.length());
        List<Integer> rawStarts = new ArrayList<Integer>();
        List<Integer> rawEnds = new ArrayList<Integer>();
        for (int i = 0; i < formatted.length();) {
            char c = formatted.charAt(i);
            if (c == '\u00A7' && i + 1 < formatted.length()) {
                i += 2;
                continue;
            }
            plain.append(c);
            rawStarts.add(i);
            rawEnds.add(i + 1);
            i++;
        }

        String lowerPlain = plain.toString().toLowerCase(Locale.ROOT);
        String lowerName = playerName.toLowerCase(Locale.ROOT);
        int visibleStart = lowerPlain.lastIndexOf(lowerName);
        if (visibleStart < 0) return null;
        int visibleEnd = visibleStart + playerName.length();
        if (visibleEnd > rawEnds.size()) return null;

        return new int[] {rawStarts.get(visibleStart), rawEnds.get(visibleEnd - 1)};
    }

    private void drawNameOutline(int left, int top, int right) {
        int x1 = left - 1;
        int x2 = right + 1;
        int y1 = top - 1;
        int y2 = top + VANILLA_FONT_HEIGHT;

        Gui.func_73734_a(x1, y1, x2, y1 + 1, TAB_OUTLINE_COLOR);
        Gui.func_73734_a(x1, y2 - 1, x2, y2, TAB_OUTLINE_COLOR);
        Gui.func_73734_a(x1, y1 + 1, x1 + 1, y2 - 1, TAB_OUTLINE_COLOR);
        Gui.func_73734_a(x2 - 1, y1 + 1, x2, y2 - 1, TAB_OUTLINE_COLOR);
    }
}
