# Build notes

This source targets Minecraft 1.8.9 + Forge 11.15.1.2318 and Java 8.

Fixes applied to the supplied source:
- Added the missing `PositionedSoundRecord` import.
- Changed the HUD background call to `Gui.drawRect(...)`, which is the valid 1.8.9 API call.
- Aligned source/build version to 1.0.4.

The accompanying `*-fixed.jar` reuses the supplied Java 8-compatible compiled classes and fixes its mod metadata (`mcmod.info`) so it identifies itself as version 1.0.4 for Minecraft 1.8.9.

Install the fixed JAR in the normal Forge/Lunar Forge mods directory. The default keybind is B.
